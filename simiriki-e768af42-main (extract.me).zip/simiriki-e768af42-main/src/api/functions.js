import { base44 } from './base44Client';


export const tallyWebhookReceiver = base44.functions.tallyWebhookReceiver;

export const sendGuideEmail = base44.functions.sendGuideEmail;

export const hubspotWebhookReceiver = base44.functions.hubspotWebhookReceiver;

export const activateClient = base44.functions.activateClient;

export const aiAssistant = base44.functions.aiAssistant;

export const getMetricsData = base44.functions.getMetricsData;

export const marketingAutomation = base44.functions.marketingAutomation;

export const leadCreateFromChat = base44.functions.leadCreateFromChat;

export const createStripeCheckout = base44.functions.createStripeCheckout;

export const stripeWebhookReceiver = base44.functions.stripeWebhookReceiver;

export const simirikiChat = base44.functions.simirikiChat;

export const triggerNotification = base44.functions.triggerNotification;

export const syncToHubspot = base44.functions.syncToHubspot;

