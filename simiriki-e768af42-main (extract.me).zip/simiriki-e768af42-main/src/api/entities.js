import { base44 } from './base44Client';


export const BlogPost = base44.entities.BlogPost;

export const Testimonial = base44.entities.Testimonial;

export const Project = base44.entities.Project;

export const ProjectMilestone = base44.entities.ProjectMilestone;

export const ClientMessage = base44.entities.ClientMessage;

export const MarketingSequence = base44.entities.MarketingSequence;

export const ScheduledEmail = base44.entities.ScheduledEmail;



// auth sdk:
export const User = base44.auth;