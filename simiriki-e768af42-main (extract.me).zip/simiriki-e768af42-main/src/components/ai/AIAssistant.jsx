
import React, { useState, useRef, useEffect } from 'react';
import { X, Send, Calendar, Phone, Loader, Bot } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { aiAssistant } from '@/api/functions';

export default function AIAssistant({ isOpen, onClose }) {
  const [conversation, setConversation] = useState([]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [leadCreated, setLeadCreated] = useState(false);
  const [leadEmail, setLeadEmail] = useState(null); // Para mantener el hilo de la conversación
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    if (isOpen && conversation.length === 0) {
      setConversation([
        {
          role: 'assistant',
          content: '¡Hola! 👋 Soy el asistente de IA de Simiriki. Estoy aquí para ayudarte a descubrir cómo la automatización puede transformar tu negocio. ¿En qué tipo de empresa trabajas?',
          timestamp: new Date()
        }
      ]);
    }
  }, [isOpen, conversation.length]);

  useEffect(() => {
    scrollToBottom();
  }, [conversation]);

  const sendMessage = async () => {
    if (!currentMessage.trim() || isLoading) return;

    const userMessage = {
      role: 'user',
      content: currentMessage,
      timestamp: new Date()
    };

    setConversation(prev => [...prev, userMessage]);
    const tempMessage = currentMessage;
    setCurrentMessage('');
    setIsLoading(true);

    try {
      const response = await aiAssistant({
        message: tempMessage,
        conversation: [...conversation, userMessage].map(msg => ({
          role: msg.role,
          content: msg.content
        })),
        leadEmail: leadEmail // Enviar el email si ya lo tenemos
      });

      const aiResponse = response.data;
      const aiMessage = {
        role: 'assistant',
        content: aiResponse.message,
        timestamp: new Date()
      };

      setConversation(prev => [...prev, aiMessage]);
      
      // Manejar la creación de leads
      if (aiResponse.leadCreated) {
        if (!leadEmail) { // Only update leadEmail if it hasn't been set yet for a lead
          setLeadEmail(aiResponse.leadData.email); // Guardar el email del nuevo lead
        }
        setLeadCreated(true);
        // Mostrar mensaje de confirmación
        setTimeout(() => {
          const confirmationMessage = {
            role: 'assistant',
            content: '✅ ¡Perfecto! He registrado tus datos. Un especialista de Simiriki se pondrá en contacto contigo pronto. ¿Te gustaría agendar una consulta inmediata?',
            timestamp: new Date()
          };
          setConversation(prev => [...prev, confirmationMessage]);
          setShowCalendar(true);
        }, 1000);
      }
      
      if (aiResponse.shouldShowCalendar) {
        setShowCalendar(true);
      }

      // Tracking mejorado
      if (window.hsTrackEvent) {
        window.hsTrackEvent('ai_chat_interaction', {
          user_message: tempMessage,
          ai_response: aiResponse.message,
          lead_created: aiResponse.leadCreated || false,
          conversation_length: conversation.length
        });
      }

      // Tracking de Google Analytics
      if (window.trackGAEvent && aiResponse.leadCreated) {
        window.trackGAEvent('generate_lead', {
          method: 'ai_chat',
          lead_source: 'chat_widget',
          conversion_type: 'ai_qualified_lead'
        });
      }

    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage = {
        role: 'assistant',
        content: 'Lo siento, tuve un problema técnico. ¿Podrías contactarnos directamente por WhatsApp o teléfono al +52 813 467 5514?',
        timestamp: new Date()
      };
      setConversation(prev => [...prev, errorMessage]);
    }

    setIsLoading(false);
  };
  
  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('es-MX', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-4 z-[9999] sm:bottom-6 sm:right-6 sm:top-auto sm:left-auto sm:w-96 sm:h-[500px] max-w-[calc(100vw-2rem)] sm:max-w-none animate-in fade-in slide-in-from-bottom-5">
      <Card className="h-full bg-white/95 backdrop-blur-sm border border-gray-200 shadow-2xl flex flex-col">
        <CardHeader className="bg-gradient-to-br from-purple-500 to-blue-500 text-white rounded-t-lg p-3 sm:p-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2 sm:space-x-3">
              <div className="w-8 h-8 sm:w-10 sm:h-10 bg-white/20 rounded-full flex items-center justify-center">
                <Bot className="w-4 h-4 sm:w-5 sm:h-5" />
              </div>
              <div>
                <CardTitle className="text-base sm:text-lg">Asistente IA Simiriki</CardTitle>
                <div className="text-xs sm:text-sm opacity-90">
                  {leadCreated ? '✅ Datos registrados • En línea' : 'En línea • Respuesta inmediata'}
                </div>
              </div>
            </div>
            <Button
              onClick={onClose}
              variant="ghost"
              size="sm"
              className="text-white hover:bg-white/20 p-1 sm:p-2"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent className="p-0 flex-1 flex flex-col min-h-0">
          <div className="flex-1 overflow-y-auto p-3 sm:p-4 space-y-3 sm:space-y-4" data-testid="chat-message-list">
            {conversation.map((msg, index) => (
              <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                <div className={`max-w-[85%] sm:max-w-[80%] p-2 sm:p-3 rounded-lg ${
                  msg.role === 'user' 
                    ? 'bg-gradient-to-br from-green-500 to-emerald-500 text-white' 
                    : 'bg-gray-100 text-gray-800'
                }`}>
                  <div className="text-sm" style={{ wordBreak: 'break-word' }}>{msg.content}</div>
                  <div className={`text-xs mt-1 opacity-70 ${
                    msg.role === 'user' ? 'text-white' : 'text-gray-500'
                  }`}>
                    {formatTime(msg.timestamp)}
                  </div>
                </div>
              </div>
            ))}
            
            {isLoading && (
              <div className="flex justify-start">
                <div className="bg-gray-100 p-2 sm:p-3 rounded-lg">
                  <div className="flex items-center space-x-2">
                    <Loader className="w-4 h-4 animate-spin text-purple-500" />
                    <span className="text-sm text-gray-600">Escribiendo...</span>
                  </div>
                </div>
              </div>
            )}

            {showCalendar && (
              <div className="bg-blue-50 p-3 sm:p-4 rounded-lg border border-blue-200">
                <div className="text-sm text-blue-800 mb-3 font-medium">¿Te gustaría agendar una consulta gratuita?</div>
                <div className="flex flex-col sm:flex-row gap-2">
                  <a href="https://meetings.hubspot.com/jjdlr/simiriki-consulta" target="_blank" rel="noopener noreferrer" className="flex-1">
                    <Button size="sm" className="bg-blue-500 hover:bg-blue-600 text-white w-full">
                      <Calendar className="w-4 h-4 mr-2" />
                      Agendar Consulta
                    </Button>
                  </a>
                  <a href="tel:+528134675514" className="flex-1">
                    <Button size="sm" variant="outline" className="border-blue-300 text-blue-600 w-full">
                      <Phone className="w-4 h-4 mr-2" />
                      Llamar Ahora
                    </Button>
                  </a>
                </div>
              </div>
            )}
            
            <div ref={messagesEndRef} />
          </div>

          <div className="p-3 sm:p-4 border-t border-gray-200 bg-white/80 flex-shrink-0">
            <div className="flex items-center space-x-2">
              <Input
                value={currentMessage}
                onChange={(e) => setCurrentMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Escribe tu pregunta..."
                className="flex-1 text-sm sm:text-base"
                disabled={isLoading}
                data-testid="chat-input"
              />
              <Button 
                onClick={sendMessage} 
                disabled={isLoading || !currentMessage.trim()}
                className="bg-gradient-to-br from-purple-500 to-blue-500 hover:from-purple-600 hover:to-blue-600 flex-shrink-0 p-2 sm:p-3"
                data-testid="chat-send-button"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <div className="text-xs text-gray-500 mt-2 text-center">
              Asistente IA • Respuestas instantáneas sobre automatización
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
