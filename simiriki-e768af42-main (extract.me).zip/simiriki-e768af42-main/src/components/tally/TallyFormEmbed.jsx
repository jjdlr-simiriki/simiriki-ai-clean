import React, { useEffect } from 'react';

// Este es el ID de tu formulario de Tally.
// Lo tomé de la configuración que me proporcionaste anteriormente.
const TALLY_FORM_ID = "abc123456"; 

export default function TallyFormEmbed() {
  useEffect(() => {
    // Cargar el script de Tally si aún no está presente
    if (!document.querySelector('script[src="https://tally.so/widgets/embed.js"]')) {
      const script = document.createElement('script');
      script.src = "https://tally.so/widgets/embed.js";
      script.async = true;
      script.onload = () => {
        if (window.Tally) {
          window.Tally.loadEmbeds();
        }
      };
      document.body.appendChild(script);
    }
  }, []);

  return (
    <iframe
      data-tally-src={`https://tally.so/embed/${TALLY_FORM_ID}?alignLeft=1&hideTitle=1&transparentBackground=1&dynamicHeight=1`}
      loading="lazy"
      width="100%"
      height="300" // Se ajustará dinámicamente
      frameBorder="0"
      marginHeight="0"
      marginWidth="0"
      title="Formulario de Contacto"
      style={{
        width: '100%',
        minHeight: '400px', // Altura mínima para una buena experiencia
        border: 'none',
        colorScheme: 'dark',
      }}
    ></iframe>
  );
}