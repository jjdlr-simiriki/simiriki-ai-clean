import React, { useEffect } from "react";

export default function HubSpotTracking({ portalId }) {
  useEffect(() => {
    // Initialize HubSpot tracking queue
    if (!window._hsq) {
      window._hsq = window._hsq || [];
    }

    // Check if tracking script already exists
    if (document.getElementById(`hs-analytics-${portalId}`)) {
      return;
    }

    const script = document.createElement("script");
    script.id = `hs-analytics-${portalId}`;
    script.src = `//js.hs-analytics.net/analytics/${new Date().getFullYear()}/${portalId}.js`;
    script.type = "text/javascript";
    script.async = true;
    
    document.head.appendChild(script);
    
    // Set up tracking functions
    window.hsTrackEvent = (eventName, properties = {}) => {
      if (window._hsq) {
        window._hsq.push(['trackEvent', {
          id: eventName,
          ...properties
        }]);
      }
    };

    window.hsIdentify = (email, properties = {}) => {
      if (window._hsq) {
        window._hsq.push(['identify', {
          email,
          ...properties
        }]);
      }
    };
    
    // CRITICAL: Disable HubSpot's automatic chat widget loading
    window.hsConversationsSettings = {
      loadImmediately: false,
      enableWelcomeMessage: false,
      disableAttachment: true
    };
    
    return () => {
      const existingScript = document.getElementById(`hs-analytics-${portalId}`);
      if (existingScript) {
        document.head.removeChild(existingScript);
      }
    };
  }, [portalId]);

  return null;
}