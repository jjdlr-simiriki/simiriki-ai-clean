import React from "react";

export default function HubSpotMeeting({ meetingUrl, width = "100%", height = "600px" }) {
  return (
    <div className="hubspot-meeting-container">
      <iframe
        src={meetingUrl}
        width={width}
        height={height}
        frameBorder="0"
        style={{
          border: 'none',
          borderRadius: '8px'
        }}
        title="Calendario de HubSpot"
      />
    </div>
  );
}