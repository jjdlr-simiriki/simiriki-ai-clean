import React from "react";
import HubSpotForm from "./HubSpotForm";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Users, Clock } from "lucide-react";

export default function HubSpotFormWrapper({ 
  title = "Descarga tu Guía Gratuita",
  description = "Completa el formulario y recibe la guía en tu email instantáneamente.",
  portalId,
  formId,
  showBenefits = true 
}) {
  const benefits = [
    { icon: Download, text: "Descarga inmediata" },
    { icon: Users, text: "Casos de éxito reales" },
    { icon: Clock, text: "Solo 15 minutos de lectura" }
  ];

  return (
    <Card className="bg-white/5 backdrop-blur-sm border-white/10">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-white">{title}</CardTitle>
        <p className="text-gray-300">{description}</p>
      </CardHeader>
      
      <CardContent>
        {showBenefits && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            {benefits.map((benefit, index) => (
              <div key={index} className="flex items-center space-x-2 text-sm text-gray-300">
                <benefit.icon className="w-4 h-4 text-green-400" />
                <span>{benefit.text}</span>
              </div>
            ))}
          </div>
        )}
        
        <HubSpotForm portalId={portalId} formId={formId} />
        
        <p className="text-xs text-gray-500 text-center mt-4">
          🔒 Tu información está segura. No enviamos spam.
        </p>
      </CardContent>
    </Card>
  );
}