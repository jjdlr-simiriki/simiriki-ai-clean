import React, { useEffect } from "react";

export default function HubSpotChat({ portalId }) {
  useEffect(() => {
    // Check if script already exists
    if (document.getElementById(`hs-script-${portalId}`)) {
      return;
    }

    const script = document.createElement("script");
    script.id = `hs-script-${portalId}`;
    script.src = `//js.hs-scripts.com/${portalId}.js`;
    script.type = "text/javascript";
    script.async = true;
    script.defer = true;
    
    document.head.appendChild(script);
    
    return () => {
      // Cleanup on unmount
      const existingScript = document.getElementById(`hs-script-${portalId}`);
      if (existingScript) {
        document.head.removeChild(existingScript);
      }
    };
  }, [portalId]);

  return null; // This component doesn't render anything visible
}