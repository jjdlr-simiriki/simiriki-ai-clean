
import React, { useState, useEffect } from 'react';
import { BlogPost } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Calendar, Clock, ArrowRight } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

export default function BlogPreview() {
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchPosts = async () => {
      setIsLoading(true);
      try {
        const publishedPosts = await BlogPost.filter({ status: 'published' }, '-published_date', 3);
        setPosts(publishedPosts);
      } catch (error) {
        console.error("Error fetching blog posts:", error);
      }
      setIsLoading(false);
    };
    fetchPosts();
  }, []);

  if (isLoading || posts.length === 0) {
    return null; // Don't render if loading or no posts
  }

  return (
    <section className="py-20" id="blog">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Directo de nuestra <span className="gradient-text">Biblioteca de Crecimiento</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Estrategias y tácticas que puedes aplicar hoy para automatizar tu negocio.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 mb-12">
          {posts.map(post => (
            <Link to={createPageUrl(`BlogPost?slug=${post.slug}`)} key={post.id} className="block group">
              <Card className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 hover:border-green-400/30 transition-all duration-300 h-full flex flex-col overflow-hidden">
                {post.featured_image && (
                  <div className="aspect-video overflow-hidden">
                    <img
                      src={post.featured_image}
                      alt={post.title}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      loading="lazy"
                    />
                  </div>
                )}
                <CardContent className="p-6 flex-grow flex flex-col">
                  <h3 className="text-xl font-bold text-white mb-2 flex-grow group-hover:text-green-400 transition-colors">{post.title}</h3>
                  <div className="flex justify-between items-center text-xs text-gray-400 mt-auto pt-4 border-t border-white/10">
                    <div className="flex items-center space-x-2">
                      <Calendar className="w-3 h-3" />
                      <span>{format(new Date(post.published_date), "d MMM, yyyy", { locale: es })}</span>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Clock className="w-3 h-3" />
                      <span>{post.read_time} min</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        <div className="text-center">
          <a
            href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="lg" variant="outline" className="text-purple-300 border-purple-400/80 hover:bg-purple-500/20 hover:border-purple-400 hover:text-white transition-colors group">
              Visitar el Blog
              <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
}
