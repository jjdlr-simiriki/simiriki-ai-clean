
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { ArrowRight, Sparkles, Zap, Play, CheckCircle, Phone, Calendar } from "lucide-react";

export default function HeroSection() {
  return (
    <section className="relative py-20 lg:py-32">
      {/* Subtle Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-80 h-80 bg-purple-500/10 rounded-full blur-3xl"></div>
      </div>
      
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Column - Content */}
          <div className="space-y-8 text-center lg:text-left mobile-padding">
            {/* -- CORREGIDO: Mensaje de urgencia reemplazado por prueba social -- */}
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-medium">
              <CheckCircle className="w-4 h-4 mr-2" />
              Resultados Comprobados: +200 PYMES Transformadas
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight hero-title" style={{ textShadow: '0 2px 4px rgba(0,0,0,0.3)' }}>
              Automatización Inteligente para PYMEs: <span className="gradient-text">Vende 340% Más</span>
            </h1>
            
            <p className="text-xl text-gray-300 mb-8 max-w-xl mx-auto lg:mx-0 hero-subtitle" style={{ textShadow: '0 1px 3px rgba(0,0,0,0.3)' }}>
              Transformamos tu negocio con IA y flujos de trabajo automáticos. Descubre por qué somos la plataforma líder para PYMEs en México y Latinoamérica.
            </p>

            <div className="glass-effect sophisticated-border rounded-2xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4 mobile-text-center">✅ Resultados comprobados con +200 PYMEs:</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {[
                  { icon: "🎯", text: "300% más leads calificados automáticamente" },
                  { icon: "💬", text: "Respuestas 24/7 sin contratar personal" }, 
                  { icon: "📈", text: "80% menos trabajo manual repetitivo" },
                  { icon: "📊", text: "ROI visible en los primeros 30 días" }
                ].map((benefit, index) => (
                  <div key={index} className="text-gray-300 text-sm flex items-center mobile-text-center">
                    <span className="text-lg mr-3" role="img" aria-label="icon">{benefit.icon}</span>
                    {benefit.text}
                  </div>
                ))}
              </div>
            </div>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start mobile-stack">
              <a href="tel:+528134675514" className="block mobile-full-width">
                <Button size="lg" className="gradient-bg text-white hover:opacity-90 transition-opacity w-full sm:w-auto">
                  <Phone className="w-5 h-5 mr-2" />
                  Llamar Ahora: +52 813 467 5514
                </Button>
              </a>
              
              <a 
                href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
                target="_blank"
                rel="noopener noreferrer"
                className="block mobile-full-width"
              >
                <Button size="lg" variant="outline" className="text-purple-300 border-purple-400/50 hover:bg-purple-500/20 hover:border-purple-400 hover:text-white transition-colors w-full sm:w-auto">
                  <Calendar className="w-5 h-5 mr-2" />
                  Reservar Consulta Gratuita
                </Button>
              </a>
            </div>

            {/* Risk Reversal */}
            <div className="bg-green-500/10 border border-green-500/20 rounded-lg p-4">
              <div className="flex items-center space-x-2 justify-center lg:justify-start mobile-text-center">
                <CheckCircle className="w-5 h-5 text-green-400" />
                <span className="text-green-400 font-semibold">Garantía de 30 días o te devolvemos tu dinero</span>
              </div>
              <p className="text-gray-300 text-sm mt-1 mobile-text-center">Sin riesgo. Sin compromisos largos. Solo resultados.</p>
            </div>
          </div>
          
          {/* Right Column - Testimonial Video Placeholder */}
          <div className="relative">
            <div className="glass-effect sophisticated-border rounded-3xl p-8 mb-6">
              <div className="aspect-video bg-gradient-to-br from-emerald-500/20 to-purple-500/20 rounded-2xl flex items-center justify-center mb-4">
                <div className="text-center">
                  <Play className="w-16 h-16 text-white mx-auto mb-4" />
                  <p className="text-white font-semibold">Ve cómo María aumentó sus ventas 340%</p>
                  <p className="text-gray-300 text-sm">Video testimonial - 2 minutos</p>
                </div>
              </div>
              
              <blockquote className="text-white italic text-center">
                "En 60 días pasamos de generar 15 leads mensuales a 102 leads calificados. 
                Simiriki cambió completamente nuestro negocio."
              </blockquote>
              <p className="text-center mt-3 text-emerald-400 font-semibold">
                - María Elena Vásquez, CEO Números Exactos
              </p>
            </div>

            {/* Trust Indicators */}
            <div className="grid grid-cols-2 gap-4">
              <div className="glass-effect rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-emerald-400">4.9/5</div>
                <div className="text-sm text-gray-400">Rating de clientes</div>
              </div>
              <div className="glass-effect rounded-lg p-4 text-center">
                <div className="text-2xl font-bold text-purple-400">90 días</div>
                <div className="text-sm text-gray-400">Garantía de resultados</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
