
import React, { useState } from 'react';
import { ChevronDown, ChevronUp } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button'; // Assuming Button component path
import { Link } from 'react-router-dom'; // Assuming react-router-dom for Link

// Dummy createPageUrl function - replace with your actual implementation if different
const createPageUrl = (pageName) => {
  switch (pageName) {
    case "FAQ":
      return "/faq"; // Or whatever your FAQ page route is
    // Add other cases as needed
    default:
      return `/${pageName.toLowerCase()}`;
  }
};

const faqs = [
  {
    question: "¿Para qué tipo de empresas son sus servicios?",
    answer: "Nos especializamos en PYMEs de 10 a 200 empleados en cualquier sector que busque digitalizar y automatizar sus procesos. Desde despachos contables hasta tiendas de retail, clínicas dentales y agencias de marketing."
  },
  {
    question: "¿Cuánto tiempo tarda en ver resultados?",
    answer: "Aunque varía por proyecto, el 85% de nuestros clientes ven mejoras significativas en eficiencia y generación de leads en los primeros 30-60 días. Los resultados completos se materializan en 90 días."
  },
  {
    question: "¿La consulta realmente es gratuita?",
    answer: "Completamente gratuita y sin compromiso. Te daremos valor real en esos 30 minutos, incluyendo 3 ideas específicas para automatizar tu negocio, sin importar si decides trabajar con nosotros o no."
  },
  {
    question: "¿Qué incluye la garantía de 30 días?",
    answer: "Si después de 30 días no estás satisfecho con el progreso o no ves el valor prometido, te devolvemos el 100% de tu inversión. Sin preguntas, sin letra pequeña."
  },
  {
    question: "¿Necesito conocimientos técnicos para usar las automatizaciones?",
    answer: "Para nada. Diseñamos todas las automatizaciones para que sean súper fáciles de usar. Además, capacitamos a tu equipo y proporcionamos soporte continuo."
  },
  {
    question: "¿Trabajan con empresas fuera de México?",
    answer: "Sí, atendemos empresas en toda América Latina de forma remota. Nuestro horario se adapta a diferentes zonas horarias para brindar el mejor servicio."
  }
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(null);

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section className="py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Preguntas <span className="gradient-text">Frecuentes</span>
          </h2>
          <p className="text-xl text-gray-300">
            Resolvemos las dudas más comunes de empresarios como tú
          </p>
        </div>

        <div className="space-y-4">
          {faqs.slice(0, 4).map((faq, index) => ( // Show only first 4 FAQs
            <Card key={index} className="bg-white/5 backdrop-blur-sm border-white/10 hover:border-white/20 transition-all duration-300">
              <CardContent className="p-0">
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full text-left p-6 flex items-center justify-between"
                >
                  <h3 className="text-lg font-semibold text-white pr-4">
                    {faq.question}
                  </h3>
                  {openIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  )}
                </button>
                {openIndex === index && (
                  <div className="px-6 pb-6">
                    <p className="text-gray-300 leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-gray-400 mb-4">
            ¿Tienes otra pregunta? Contáctanos directamente.
          </p>
          <a 
            href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button variant="outline" className="text-emerald-400 border-emerald-400/50 hover:bg-emerald-500/10 hover:text-emerald-300">
              Agendar Consulta Gratuita
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
}
