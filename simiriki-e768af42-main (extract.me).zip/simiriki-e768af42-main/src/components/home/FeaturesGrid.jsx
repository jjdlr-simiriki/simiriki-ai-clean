import React from "react";
import { Zap, Bot, TrendingUp, Shield, Clock, Sparkles } from "lucide-react";

const features = [
  {
    icon: Zap,
    title: "Automatización Inteligente",
    description: "Workflows que se ejecutan solos, liberando tu tiempo para lo que realmente importa.",
    color: "emerald"
  },
  {
    icon: Bot,
    title: "IA Conversacional",
    description: "Asistentes virtuales que atienden clientes 24/7 con respuestas personalizadas.",
    color: "purple"
  },
  {
    icon: TrendingUp,
    title: "Generación de Leads",
    description: "Sistemas que identifican y capturan prospectos de forma automática.",
    color: "blue"
  },
  {
    icon: Shield,
    title: "Seguridad Empresarial",
    description: "Protección de datos y cumplimiento normativo garantizado.",
    color: "emerald"
  },
  {
    icon: Clock,
    title: "Disponibilidad 24/7",
    description: "Tus sistemas trabajando mientras duermes, sin interrupciones.",
    color: "purple"
  },
  {
    icon: Sparkles,
    title: "Escalabilidad Sin Límites",
    description: "Crece 10x sin contratar más personal ni aumentar gastos operativos.",
    color: "blue"
  }
];

export default function FeaturesGrid() {
  return (
    <section className="py-20 relative">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            ¿Por qué elegir <span className="gradient-text">simiriki</span>?
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Combinamos tecnología de vanguardia con experiencia local para impulsar tu negocio al siguiente nivel.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group glass-effect sophisticated-border rounded-2xl p-6 hover:scale-105 transition-all duration-300"
            >
              <div className={`w-14 h-14 bg-gradient-to-br from-${feature.color}-400 to-${feature.color}-600 rounded-xl flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                <feature.icon className="w-7 h-7 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white mb-2 group-hover:text-emerald-400 transition-colors">{feature.title}</h3>
              <p className="text-gray-300 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}