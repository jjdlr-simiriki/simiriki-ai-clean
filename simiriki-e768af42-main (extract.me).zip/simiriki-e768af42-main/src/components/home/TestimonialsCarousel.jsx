
import React, { useState, useEffect } from "react";
import { Testimonial } from "@/api/entities";
import { ChevronLeft, ChevronRight, Star, Quote } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function TestimonialsCarousel() {
  const [testimonials, setTestimonials] = useState([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadTestimonials();
  }, []);

  const loadTestimonials = async () => {
    try {
      const data = await Testimonial.filter({ status: "active" }, "-created_date", 10);
      setTestimonials(data);
    } catch (error) {
      console.error("Error loading testimonials:", error);
    }
    setIsLoading(false);
  };

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  if (isLoading || testimonials.length === 0) {
    return (
      <section className="py-20" id="testimonios">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Lo que Dicen Nuestros <span className="gradient-text">Clientes</span>
            </h2>
            <p className="text-gray-300">Cargando testimonios...</p>
          </div>
        </div>
      </section>
    );
  }

  const currentTestimonial = testimonials[currentIndex];

  return (
    <section className="py-20" id="testimonios">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Lo que Dicen Nuestros <span className="gradient-text">Clientes</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Casos reales de empresas que han transformado su negocio con simiriki.
          </p>
        </div>
        
        <div className="relative max-w-4xl mx-auto">
          {/* Main Testimonial Card */}
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 md:p-12 border border-white/10 relative">
            <Quote className="w-16 h-16 text-green-400/30 absolute top-6 left-6" />
            
            <div className="relative z-10">
              {/* Stars */}
              <div className="flex items-center justify-center mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`w-6 h-6 ${
                      i < currentTestimonial.rating
                        ? "text-yellow-400 fill-yellow-400"
                        : "text-gray-400"
                    }`}
                  />
                ))}
              </div>
              
              {/* Testimonial Text */}
              <blockquote className="text-xl md:text-2xl text-white text-center mb-8 leading-relaxed">
                "{currentTestimonial.testimonial}"
              </blockquote>
              
              {/* Results */}
              {currentTestimonial.results_achieved && (
                <div className="bg-green-500/10 rounded-lg p-4 mb-8 border border-green-500/20">
                  <div className="text-center">
                    <div className="text-sm text-green-400 font-medium mb-1">Resultados Obtenidos</div>
                    <div className="text-white font-semibold">{currentTestimonial.results_achieved}</div>
                  </div>
                </div>
              )}
              
              {/* Client Info */}
              <div className="flex items-center justify-center space-x-4">
                <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-purple-400 rounded-full flex items-center justify-center overflow-hidden">
                  {currentTestimonial.company_logo_url ? (
                    <img src={currentTestimonial.company_logo_url} alt={`${currentTestimonial.company} logo`} className="w-full h-full object-cover" />
                  ) : (
                    <span className="text-white font-bold text-xl">
                      {currentTestimonial.company.charAt(0)}
                    </span>
                  )}
                </div>
                <div className="text-center">
                  <div className="text-white font-semibold text-lg">{currentTestimonial.client_name}</div>
                  <div className="text-gray-300">{currentTestimonial.client_title}</div>
                  <div className="text-green-400 font-medium">{currentTestimonial.company}</div>
                </div>
              </div>
            </div>
          </div>
          
          {/* Navigation */}
          <div className="flex items-center justify-center space-x-4 mt-8">
            <Button
              variant="outline"
              size="icon"
              onClick={prevTestimonial}
              className="text-purple-300 border-purple-400/80 hover:bg-purple-500/20 hover:border-purple-400 hover:text-white transition-colors"
              aria-label="Testimonio anterior"
            >
              <ChevronLeft className="w-5 h-5" />
            </Button>
            
            {/* Indicators */}
            <div className="flex space-x-2">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => setCurrentIndex(index)}
                  className={`w-3 h-3 rounded-full transition-colors ${
                    index === currentIndex ? "bg-green-400" : "bg-white/20"
                  }`}
                  aria-label={`Ir al testimonio ${index + 1}`}
                />
              ))}
            </div>
            
            <Button
              variant="outline"
              size="icon"
              onClick={nextTestimonial}
              className="text-purple-300 border-purple-400/80 hover:bg-purple-500/20 hover:border-purple-400 hover:text-white transition-colors"
              aria-label="Siguiente testimonio"
            >
              <ChevronRight className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
}
