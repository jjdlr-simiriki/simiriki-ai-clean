
import React from "react";
import { Link } from "react-router-dom"; // Importar Link
import { createPageUrl } from "@/utils"; // Importar createPageUrl
import { Button } from "@/components/ui/button";
import { ArrowRight, Download, Calendar, CheckCircle } from "lucide-react";

export default function CTASection() {
  return (
    <section className="py-20 bg-gradient-to-br from-green-900/20 via-purple-900/20 to-blue-900/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-5xl font-bold text-white mb-6">
            ¿Listo para <span className="gradient-text">dejar de operar</span> y empezar a dirigir?
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Únete a los negocios que ya están automatizando sus procesos y multiplicando sus resultados con nosotros.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 gap-8 max-w-5xl mx-auto">
          {/* Free Guide CTA */}
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10 hover:border-green-400/30 transition-all duration-300 group">
            <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Download className="w-8 h-8 text-white" />
            </div>
            
            <h3 className="text-2xl font-bold text-white mb-4">Guía de Crecimiento</h3>
            <p className="text-gray-300 mb-6">
              Descarga nuestro plan: "5 Pasos para Automatizar tu PYME y Aumentar Ventas 300%"
            </p>
            
            <ul className="space-y-2 mb-6">
              {[
                "Estrategias de automatización probadas",
                "Casos de éxito reales",
                "Checklist de implementación",
                "Plantillas listas para usar"
              ].map((item, index) => (
                <li key={index} className="flex items-center text-gray-300">
                  <CheckCircle className="w-4 h-4 text-green-400 mr-2" />
                  {item}
                </li>
              ))}
            </ul>
            
            {/* -- CORREGIDO: El enlace ahora lleva a la página del cuestionario -- */}
            <Link to={createPageUrl("FreeGuide")}>
              <Button size="lg" className="w-full gradient-bg text-white hover:opacity-90 group">
                Descargar Guía Ahora
                <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </Link>
          </div>
          
          {/* Consultation CTA */}
          <div className="bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10 hover:border-purple-400/30 transition-all duration-300 group">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Calendar className="w-8 h-8 text-white" />
            </div>
            
            <h3 className="text-2xl font-bold text-white mb-4">Consulta Estratégica</h3>
            <p className="text-gray-300 mb-6">
              Agenda una llamada digital de 15 min. y te daremos 3 ideas para automatizar tu negocio, gratis.
            </p>
            
            <ul className="space-y-2 mb-6">
              {[
                "Análisis rápido de tu negocio",
                "Identificación de oportunidades",
                "Plan de acción inmediato",
                "Sin compromiso"
              ].map((item, index) => (
                <li key={index} className="flex items-center text-gray-300">
                  <CheckCircle className="w-4 h-4 text-purple-400 mr-2" />
                  {item}
                </li>
              ))}
            </ul>
            
            <a 
              href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button size="lg" variant="outline" className="w-full text-white border-white/20 hover:bg-white/10 group">
                Agendar mi llamada digital de 15 min
                <Calendar className="w-5 h-5 ml-2 group-hover:scale-110 transition-transform" />
              </Button>
            </a>
          </div>
        </div>
        
        <div className="text-center mt-12">
          <p className="text-gray-400 text-sm">
            🔒 Sin spam, solo soluciones reales.
          </p>
        </div>
      </div>
    </section>
  );
}
