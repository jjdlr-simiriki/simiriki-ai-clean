
import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, Users, Bot, BarChart3 } from "lucide-react";

const services = [
  {
    icon: Zap,
    title: "Automatización de Procesos",
    description: "Elimina tareas repetitivas que consumen horas de tu equipo. Workflows inteligentes que operan sin supervisión.",
    color: "from-green-400 to-green-600"
  },
  {
    icon: Users,
    title: "Generación de Leads Inteligente",
    description: "Sistema que identifica, captura y califica prospectos automáticamente. Solo hablas con clientes listos para comprar.",
    color: "from-purple-400 to-purple-600"
  },
  {
    icon: Bot,
    title: "IA para Atención al Cliente",
    description: "Chatbots que resuelven 80% de consultas al instante. Tus clientes contentos, tu equipo libre para vender más.",
    color: "from-blue-400 to-blue-600"
  },
  {
    icon: BarChart3,
    title: "Dashboards en Tiempo Real",
    description: "Visualiza el pulso de tu negocio al instante. Toma decisiones basadas en datos, no en intuición.",
    color: "from-orange-400 to-orange-600"
  }
];

export default function ServicesPreview() {
  return (
    <section className="py-20" id="servicios">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Soluciones para <span className="gradient-text">Crecer sin Límites</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Un ecosistema de herramientas para que vendas más, con menos esfuerzo.
          </p>
        </div>
        
        <div className="grid lg:grid-cols-2 gap-8 mb-12">
          {services.map((service, index) => (
            <div
              key={index}
              className="group bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10 hover:border-white/20 transition-all duration-300"
            >
              <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                <service.icon className="w-8 h-8 text-white" />
              </div>
              
              <h3 className="text-2xl font-bold text-white mb-4">{service.title}</h3>
              <p className="text-gray-300 leading-relaxed">{service.description}</p>
            </div>
          ))}
        </div>
        
        <div className="text-center">
          <a 
            href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
            target="_blank"
            rel="noopener noreferrer"
          >
            <Button size="lg" className="gradient-bg text-white hover:opacity-90">
              Ver Todos los Servicios
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </a>
        </div>
      </div>
    </section>
  );
}
