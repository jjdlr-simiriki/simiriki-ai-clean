import React, { useState, useEffect } from 'react';
import { CheckCircle, X } from 'lucide-react';

const notifications = [
  { name: "María", city: "CDMX", action: "descargó la guía de automatización" },
  { name: "Carlos", city: "Guadalajara", action: "agendó una consulta gratuita" },
  { name: "Ana", city: "Monterrey", action: "se registró para el webinar" },
  { name: "Roberto", city: "Tijuana", action: "descargó la calculadora de ROI" },
  { name: "Sofia", city: "Mérida", action: "solicitó una demo personalizada" },
  { name: "Diego", city: "Puebla", action: "se suscribió al newsletter" }
];

export default function SocialProofNotifications() {
  const [currentNotification, setCurrentNotification] = useState(null);
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    const showNotification = () => {
      const randomNotification = notifications[Math.floor(Math.random() * notifications.length)];
      setCurrentNotification(randomNotification);
      setIsVisible(true);

      // Hide after 4 seconds
      setTimeout(() => {
        setIsVisible(false);
      }, 4000);
    };

    // Show first notification after 3 seconds
    const initialTimeout = setTimeout(showNotification, 3000);

    // Then show notifications every 15-25 seconds
    const interval = setInterval(() => {
      const randomDelay = Math.random() * 10000 + 15000; // 15-25 seconds
      setTimeout(showNotification, randomDelay);
    }, 25000);

    return () => {
      clearTimeout(initialTimeout);
      clearInterval(interval);
    };
  }, []);

  if (!isVisible || !currentNotification) return null;

  return (
    <div className="fixed bottom-6 left-6 z-50 max-w-sm">
      <div className="bg-white/10 backdrop-blur-md rounded-lg border border-white/20 p-4 shadow-lg animate-in slide-in-from-left duration-300">
        <div className="flex items-start space-x-3">
          <div className="w-8 h-8 bg-emerald-500/20 rounded-full flex items-center justify-center flex-shrink-0">
            <CheckCircle className="w-4 h-4 text-emerald-400" />
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-white text-sm font-medium">
              <span className="font-semibold">{currentNotification.name}</span> de {currentNotification.city}
            </p>
            <p className="text-gray-300 text-xs">
              {currentNotification.action}
            </p>
            <p className="text-emerald-400 text-xs font-medium mt-1">
              Hace {Math.floor(Math.random() * 10) + 1} minutos
            </p>
          </div>
          <button
            onClick={() => setIsVisible(false)}
            className="text-gray-400 hover:text-white transition-colors flex-shrink-0"
            aria-label="Cerrar notificación"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}