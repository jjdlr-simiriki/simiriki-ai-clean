
import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Quote, ArrowRight } from 'lucide-react';

export default function FounderIntro() {
  return (
    <section className="py-20 bg-slate-900" id="fundador">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="relative">
            <img 
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/founder_photo.jpeg" // Placeholder image
              alt="JJ de la Rocha, Fundador de Simiriki"
              className="rounded-3xl shadow-2xl w-full h-auto object-cover"
              width="500"
              height="600"
              loading="lazy"
            />
            <div className="absolute -bottom-4 -right-4 w-24 h-24 bg-gradient-to-br from-green-400 to-purple-500 rounded-full flex items-center justify-center">
              <Quote className="w-12 h-12 text-white" />
            </div>
          </div>
          <div className="space-y-6">
            <p className="text-lg font-semibold gradient-text">Un Mensaje del Fundador</p>
            <h2 className="text-3xl md:text-4xl font-bold text-white">
              Nacimos para liberar a las PYMES de la operación diaria.
            </h2>
            <blockquote className="text-xl text-gray-300 italic leading-relaxed border-l-4 border-green-400 pl-6">
              "Vi a demasiados dueños de negocio talentosos atrapados en tareas repetitivas, incapaces de enfocarse en el crecimiento. Simiriki es la solución que yo hubiera querido tener: un socio tecnológico que automatiza lo aburrido para que puedas volver a hacer lo que amas."
            </blockquote>
            <div>
              <p className="text-white font-semibold">JJ de la Rocha</p>
              <p className="text-gray-400">Fundador de Simiriki</p>
            </div>
            <a 
              href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
              target="_blank"
              rel="noopener noreferrer"
            >
              <Button variant="outline" className="text-purple-300 border-purple-400/80 hover:bg-purple-500/20 hover:border-purple-400 hover:text-white transition-colors group">
                Nuestra Historia
                <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
              </Button>
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
