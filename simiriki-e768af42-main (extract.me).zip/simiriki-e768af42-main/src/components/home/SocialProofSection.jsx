
import React from 'react';
import { Star, Quote, CheckCircle } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';

const testimonials = [
  {
    quote: "Simiriki transformó completamente nuestra operación. Ahora somos una firma de consultoría estratégica, no solo 'hacedores de reportes'.",
    author: "María Elena Vásquez",
    position: "Socia Fundadora",
    company: "Números Exactos",
    rating: 5,
    logo_bg: "bg-blue-600",
  },
  {
    quote: "Es como tener un equipo de 10 personas trabajando 24/7 calificando leads por nosotros. Los prospectos llegan pre-calificados y listos para comprar.",
    author: "Roberto Sánchez",
    position: "Director Comercial", 
    company: "Hogar Ideal",
    rating: 5,
    logo_bg: "bg-green-600",
  },
  {
    quote: "No puedo creer que ahora estoy vendiendo mientras duermo. El chatbot conoce mi inventario mejor que yo misma.",
    author: "Sofía Herrera",
    position: "Propietaria",
    company: "Estilo Verde",
    rating: 5,
    logo_bg: "bg-purple-600",
  }
];

export default function SocialProofSection() {
  return (
    <section className="py-20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Trusted By Section - Using text-based logos for reliability */}
        <div className="text-center mb-20">
          <h3 className="text-2xl font-bold text-white mb-8">
            Integrado con las <span className="gradient-text">mejores herramientas</span> del mercado
          </h3>
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10">
            <div className="flex flex-wrap justify-center items-center gap-8 lg:gap-12">
              {[
                { name: "HubSpot", color: "text-orange-400" },
                { name: "Google Cloud", color: "text-blue-400" },
                { name: "Microsoft", color: "text-cyan-400" },
                { name: "Zapier", color: "text-orange-300" },
                { name: "OpenAI", color: "text-green-400" }
              ].map((partner, index) => (
                <div key={index} className="flex items-center justify-center group">
                  <div className={`text-xl font-bold ${partner.color} group-hover:scale-110 transition-all duration-300 px-4 py-2 rounded-lg bg-white/5 border border-white/10 group-hover:border-white/30`}>
                    {partner.name}
                  </div>
                </div>
              ))}
            </div>
            <p className="text-gray-400 text-sm mt-6">
              Conectamos tu negocio con las plataformas líderes para crear un ecosistema integrado
            </p>
          </div>
        </div>

        {/* Main Testimonials */}
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Lo que Dicen <span className="gradient-text">Nuestros Clientes</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Casos reales de empresas que han transformado su negocio con Simiriki.
          </p>
        </div>
        
        <div className="grid md:grid-cols-3 gap-8 mb-16">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 hover:border-green-400/30 transition-all duration-300">
              <CardContent className="p-6">
                <Quote className="w-8 h-8 text-green-400/30 mb-4" />
                
                {/* Stars */}
                <div 
                  className="flex items-center mb-4"
                  role="img" 
                  aria-label={`${testimonial.rating} de 5 estrellas`}
                >
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                </div>
                
                {/* Quote */}
                <blockquote className="text-gray-300 mb-6 leading-relaxed">
                  "{testimonial.quote}"
                </blockquote>
                
                {/* Author with Logo */}
                <div className="flex items-center space-x-3">
                  <div className={`w-12 h-12 rounded-full ${testimonial.logo_bg} flex items-center justify-center font-bold text-white text-xl`}>
                    {testimonial.company.charAt(0)}
                  </div>
                  <div>
                    <div className="text-white font-semibold">{testimonial.author}</div>
                    <div className="text-gray-400 text-sm">{testimonial.position}</div>
                    <div className="text-green-400 text-sm font-medium">{testimonial.company}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Results Banner */}
        <Card className="bg-gradient-to-br from-green-500/10 to-purple-500/10 rounded-2xl p-8 border border-white/10 mb-16">
          <div className="grid md:grid-cols-4 gap-8 text-center">
            <div>
              <div className="text-3xl font-bold text-green-400 mb-2">200+</div>
              <div className="text-gray-300">Empresas Transformadas</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-purple-400 mb-2">300%</div>
              <div className="text-gray-300">ROI Promedio</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-blue-400 mb-2">85%</div>
              <div className="text-gray-300">Tiempo Ahorrado</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-yellow-400 mb-2">98%</div>
              <div className="text-gray-300">Satisfacción Cliente</div>
            </div>
          </div>
        </Card>
      </div>
    </section>
  );
}
