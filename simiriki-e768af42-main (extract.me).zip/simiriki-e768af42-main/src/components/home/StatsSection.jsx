
import React from "react";
import { TrendingUp, Users, Clock, Award } from "lucide-react";

const stats = [
  {
    icon: Users,
    number: "200+",
    label: "Empresas Transformadas",
    description: "PYMES que han escalado con nuestras soluciones"
  },
  {
    icon: TrendingUp,
    number: "300%",
    label: "ROI Promedio",
    description: "Retorno de inversión en los primeros 6 meses"
  },
  {
    icon: Clock,
    number: "85%",
    label: "Tiempo Ahorrado",
    description: "Reducción en tareas operativas manuales"
  },
  {
    icon: Award,
    number: "98%",
    label: "Satisfacción del Cliente",
    description: "Clientes que recomiendan nuestros servicios"
  }
];

export default function StatsSection() {
  return (
    <section className="py-20 bg-gradient-to-br from-green-900/20 to-purple-900/20">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Triplicamos tus leads mientras <span className="gradient-text">reduces 80% del trabajo manual</span>
          </h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Nuestros clientes no solo crecen, sino que transforman completamente la forma en que operan para enfocarse en la estrategia.
          </p>
        </div>
        
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-8">
          {stats.map((stat, index) => (
            <div
              key={index}
              className="text-center group"
            >
              <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-purple-400 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform">
                <stat.icon className="w-10 h-10 text-white" />
              </div>
              <div className="text-4xl md:text-5xl font-bold text-white mb-2">{stat.number}</div>
              <div className="text-xl font-semibold text-green-400 mb-2">{stat.label}</div>
              <p className="text-gray-300 text-sm leading-relaxed">{stat.description}</p>
            </div>
          ))}
        </div>
        
        <div className="mt-16 text-center">
          <div className="inline-flex items-center px-6 py-3 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
            <span className="text-gray-300 mr-2">Tu inversión, recuperada en 60 días.</span>
            <span className="text-green-400 font-bold ml-1">Garantizado.</span>
          </div>
        </div>
      </div>
    </section>
  );
}
