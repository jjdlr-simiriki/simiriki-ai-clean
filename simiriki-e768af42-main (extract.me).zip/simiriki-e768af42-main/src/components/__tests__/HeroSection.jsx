
import { describe, test, expect } from 'vitest';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import HeroSection from '../home/HeroSection';

const TestWrapper = ({ children }) => (
  <BrowserRouter>
    {children}
  </BrowserRouter>
);

describe('HeroSection', () => {
  test('renders hero heading', () => {
    render(<HeroSection />, { wrapper: TestWrapper });
    
    const heading = screen.getByText(/Automatización Inteligente para PYMEs/i);
    expect(heading).toBeInTheDocument();
  });

  test('renders CTA buttons', () => {
    render(<HeroSection />, { wrapper: TestWrapper });
    
    const callButton = screen.getByText(/Llamar Ahora/i);
    const consultButton = screen.getByText(/Reservar Consulta Gratuita/i);
    
    expect(callButton).toBeInTheDocument();
    expect(consultButton).toBeInTheDocument();
  });

  test('displays testimonial quote', () => {
    render(<HeroSection />, { wrapper: TestWrapper });
    
    const quote = screen.getByText(/En 60 días pasamos de generar 15 leads mensuales/i);
    expect(quote).toBeInTheDocument();
  });

  test('shows guarantee message', () => {
    render(<HeroSection />, { wrapper: TestWrapper });
    
    const guarantee = screen.getByText(/Garantía de 30 días o te devolvemos tu dinero/i);
    expect(guarantee).toBeInTheDocument();
  });
});
