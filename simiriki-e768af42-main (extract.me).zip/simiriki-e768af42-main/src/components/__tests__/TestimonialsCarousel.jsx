import { describe, test, expect, vi, beforeEach } from 'vitest';
import { render, screen } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import TestimonialsCarousel from '../home/TestimonialsCarousel';

// Mock de la entidad Testimonial usando Vitest
vi.mock('@/api/entities', () => ({
  Testimonial: {
    filter: vi.fn().mockResolvedValue([
      {
        id: '1',
        client_name: 'María Elena Vásquez',
        client_title: 'CEO',
        company: 'Números Exactos',
        testimonial: 'Simiriki transformó completamente nuestra operación.',
        rating: 5,
        results_achieved: 'Aumentamos leads en 300%',
        status: 'active'
      },
      {
        id: '2',
        client_name: 'Roberto Sánchez',
        client_title: 'Director Comercial',
        company: 'Hogar Ideal',
        testimonial: 'Es como tener un equipo trabajando 24/7.',
        rating: 5,
        results_achieved: 'ROI del 250%',
        status: 'active'
      }
    ])
  }
}));

// Wrapper para proveer context de router
const TestWrapper = ({ children }) => (
  <BrowserRouter>
    {children}
  </BrowserRouter>
);

describe('TestimonialsCarousel', () => {
  test('renders TestimonialsCarousel heading', async () => {
    render(<TestimonialsCarousel />, { wrapper: TestWrapper });
    
    const heading = await screen.findByText(/Lo que Dicen Nuestros Clientes/i);
    expect(heading).toBeInTheDocument();
  });

  test('renders testimonial content when data loads', async () => {
    render(<TestimonialsCarousel />, { wrapper: TestWrapper });
    
    // Esperar que el contenido del primer testimonial aparezca
    const testimonialText = await screen.findByText(/Simiriki transformó completamente nuestra operación/i);
    expect(testimonialText).toBeInTheDocument();
  });

  test('displays star ratings', async () => {
    render(<TestimonialsCarousel />, { wrapper: TestWrapper });
    
    // Verificar que se muestran las estrellas (usando aria-label)
    const starRating = await screen.findByLabelText(/5 de 5 estrellas/i);
    expect(starRating).toBeInTheDocument();
  });

  test('shows navigation controls', async () => {
    render(<TestimonialsCarousel />, { wrapper: TestWrapper });
    
    const prevButton = await screen.findByLabelText(/Testimonio anterior/i);
    const nextButton = await screen.findByLabelText(/Siguiente testimonio/i);
    
    expect(prevButton).toBeInTheDocument();
    expect(nextButton).toBeInTheDocument();
  });
});