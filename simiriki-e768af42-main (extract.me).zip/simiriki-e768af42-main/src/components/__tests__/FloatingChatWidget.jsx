import { describe, test, expect, vi } from 'vitest';
import { render, screen, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import FloatingChatWidget from '../shared/FloatingChatWidget';

// Mock del componente AIAssistant usando Vitest
vi.mock('../ai/AIAssistant', () => ({
  default: function MockAIAssistant({ isOpen, onClose }) {
    return isOpen ? (
      <div data-testid="ai-assistant-modal">
        <button onClick={onClose}>Cerrar</button>
        AI Assistant Modal
      </div>
    ) : null;
  }
}));

const TestWrapper = ({ children }) => (
  <BrowserRouter>
    {children}
  </BrowserRouter>
);

describe('FloatingChatWidget', () => {
  test('renders chat button', () => {
    render(<FloatingChatWidget />, { wrapper: TestWrapper });
    
    const chatButton = screen.getByTestId('chat-widget-button');
    expect(chatButton).toBeInTheDocument();
  });

  test('opens AI assistant when clicked', () => {
    render(<FloatingChatWidget />, { wrapper: TestWrapper });
    
    const chatButton = screen.getByTestId('chat-widget-button');
    fireEvent.click(chatButton);
    
    const modal = screen.getByTestId('ai-assistant-modal');
    expect(modal).toBeInTheDocument();
  });

  test('closes AI assistant when close button is clicked', () => {
    render(<FloatingChatWidget />, { wrapper: TestWrapper });
    
    // Abrir el chat
    const chatButton = screen.getByTestId('chat-widget-button');
    fireEvent.click(chatButton);
    
    // Cerrar el chat
    const closeButton = screen.getByText('Cerrar');
    fireEvent.click(closeButton);
    
    const modal = screen.queryByTestId('ai-assistant-modal');
    expect(modal).not.toBeInTheDocument();
  });
});