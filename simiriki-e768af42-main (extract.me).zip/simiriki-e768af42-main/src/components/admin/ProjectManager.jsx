import React from 'react';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Eye, Pencil } from 'lucide-react';

const statusColors = {
  discovery: "bg-gray-200 text-gray-800",
  planning: "bg-blue-100 text-blue-800",
  development: "bg-purple-100 text-purple-800",
  testing: "bg-yellow-100 text-yellow-800",
  deployment: "bg-orange-100 text-orange-800",
  completed: "bg-green-100 text-green-800",
  on_hold: "bg-red-100 text-red-800",
};

export default function ProjectManager({ projects }) {
  if (!projects || projects.length === 0) {
    return (
      <div className="text-center py-12 bg-white rounded-lg shadow-sm">
        <h3 className="text-lg font-medium text-gray-800">No hay proyectos activos</h3>
        <p className="text-gray-500 mt-2">Cuando se active un nuevo cliente, su proyecto aparecerá aquí.</p>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm overflow-hidden">
      <Table>
        <TableHeader className="bg-gray-50">
          <TableRow>
            <TableHead className="w-[250px] text-gray-600">Nombre del Proyecto</TableHead>
            <TableHead className="text-gray-600">Cliente</TableHead>
            <TableHead className="text-gray-600">Estado</TableHead>
            <TableHead className="text-gray-600">Progreso</TableHead>
            <TableHead className="text-right text-gray-600">Acciones</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {projects.map((project) => (
            <TableRow key={project.id}>
              <TableCell className="font-medium text-gray-800">{project.project_name}</TableCell>
              <TableCell className="text-gray-600">{project.client_email}</TableCell>
              <TableCell>
                <Badge className={`${statusColors[project.status]} hover:${statusColors[project.status]}`}>
                  {project.status.replace('_', ' ')}
                </Badge>
              </TableCell>
              <TableCell>
                <div className="flex items-center space-x-2">
                  <Progress value={project.progress_percentage} className="w-[60%]" />
                  <span className="text-sm text-gray-500">{project.progress_percentage}%</span>
                </div>
              </TableCell>
              <TableCell className="text-right">
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-800">
                  <Eye className="w-4 h-4 mr-2" />
                  Ver
                </Button>
                <Button variant="ghost" size="sm" className="text-gray-500 hover:text-gray-800">
                  <Pencil className="w-4 h-4 mr-2" />
                  Editar
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}