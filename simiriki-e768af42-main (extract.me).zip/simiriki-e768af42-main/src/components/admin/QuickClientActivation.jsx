
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { UserPlus, Loader, CheckCircle, AlertCircle } from 'lucide-react';
import { activateClient } from '@/api/functions';

export default function QuickClientActivation() {
  const [formData, setFormData] = useState({
    clientEmail: '',
    clientName: '',
    projectName: '',
    serviceType: '',
    totalValue: '',
    startDate: new Date().toISOString().split('T')[0]
  });
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [result, setResult] = useState(null);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    setResult(null);

    try {
      const response = await activateClient(formData);
      
      if (response.data.success) {
        setResult({
          type: 'success',
          message: 'Cliente activado exitosamente',
          details: response.data
        });
        
        // Reset form
        setFormData({
          clientEmail: '',
          clientName: '',
          projectName: '',
          serviceType: '',
          totalValue: '',
          startDate: new Date().toISOString().split('T')[0]
        });
      } else {
        setResult({
          type: 'error',
          message: 'Error al activar cliente',
          details: response.data
        });
      }
    } catch (error) {
      setResult({
        type: 'error',
        message: 'Error de conexión',
        details: { error: error.message }
      });
    }

    setIsSubmitting(false);
  };

  return (
    <Card className="bg-white rounded-xl shadow-sm">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2 text-gray-800">
          <UserPlus className="w-5 h-5" />
          <span>Activación Rápida de Cliente</span>
        </CardTitle>
        <p className="text-gray-500">
          Activa un nuevo cliente y crea su proyecto automáticamente
        </p>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1 text-gray-700">Email del Cliente *</label>
              <Input
                type="email"
                value={formData.clientEmail}
                onChange={(e) => setFormData({...formData, clientEmail: e.target.value})}
                placeholder="cliente@empresa.com"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-1 text-gray-700">Nombre del Cliente *</label>
              <Input
                value={formData.clientName}
                onChange={(e) => setFormData({...formData, clientName: e.target.value})}
                placeholder="Juan Pérez"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">Nombre del Proyecto</label>
            <Input
              value={formData.projectName}
              onChange={(e) => setFormData({...formData, projectName: e.target.value})}
              placeholder="Automatización de Ventas para Empresa XYZ"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium mb-1 text-gray-700">Tipo de Servicio *</label>
              <Select
                value={formData.serviceType}
                onValueChange={(value) => setFormData({...formData, serviceType: value})}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Seleccionar servicio" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="automation">Automatización de Procesos</SelectItem>
                  <SelectItem value="lead_generation">Generación de Leads</SelectItem>
                  <SelectItem value="ai_implementation">Implementación de IA</SelectItem>
                  <SelectItem value="digital_transformation">Transformación Digital</SelectItem>
                  <SelectItem value="custom">Proyecto Personalizado</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium mb-1 text-gray-700">Valor Total (USD) *</label>
              <Input
                type="number"
                value={formData.totalValue}
                onChange={(e) => setFormData({...formData, totalValue: e.target.value})}
                placeholder="5000"
                required
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium mb-1 text-gray-700">Fecha de Inicio</label>
            <Input
              type="date"
              value={formData.startDate}
              onChange={(e) => setFormData({...formData, startDate: e.target.value})}
            />
          </div>

          <Button
            type="submit"
            className="w-full bg-emerald-600 hover:bg-emerald-700 text-white"
            disabled={isSubmitting || !formData.clientEmail || !formData.clientName || !formData.serviceType || !formData.totalValue}
          >
            {isSubmitting ? (
              <>
                <Loader className="w-4 h-4 mr-2 animate-spin" />
                Activando Cliente...
              </>
            ) : (
              <>
                <UserPlus className="w-4 h-4 mr-2" />
                Activar Cliente
              </>
            )}
          </Button>
        </form>

        {result && (
          <div className={`mt-4 p-4 rounded-lg border ${
            result.type === 'success' 
              ? 'bg-green-50 border-green-200 text-green-800' 
              : 'bg-red-50 border-red-200 text-red-800'
          }`}>
            <div className="flex items-center space-x-2">
              {result.type === 'success' ? (
                <CheckCircle className="w-5 h-5" />
              ) : (
                <AlertCircle className="w-5 h-5" />
              )}
              <span className="font-medium">{result.message}</span>
            </div>
            
            {result.type === 'success' && result.details.next_steps && (
              <div className="mt-2">
                <p className="font-medium">Próximos pasos:</p>
                <ul className="list-disc list-inside text-sm space-y-1">
                  {result.details.next_steps.map((step, index) => (
                    <li key={index}>{step}</li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
