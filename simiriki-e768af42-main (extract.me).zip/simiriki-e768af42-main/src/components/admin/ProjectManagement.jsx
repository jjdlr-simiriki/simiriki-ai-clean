
import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Eye, 
  Pencil, 
  MessageSquare, 
  DollarSign,
  Calendar,
  Clock,
  AlertTriangle,
  CheckCircle,
  Play,
  Pause,
  Filter,
  Search,
  MoreHorizontal,
  Paperclip, 
  Send      
} from 'lucide-react';
import { Project } from '@/api/entities';
import { ProjectMilestone } from '@/api/entities';
import { ClientMessage } from '@/api/entities';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function ProjectManagement() {
  const [projects, setProjects] = useState([]);
  const [filteredProjects, setFilteredProjects] = useState([]);
  const [selectedProject, setSelectedProject] = useState(null);
  const [projectMilestones, setProjectMilestones] = useState([]);
  const [projectMessages, setProjectMessages] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('overview');

  useEffect(() => {
    loadProjects();
  }, []);

  useEffect(() => {
    filterProjects();
  }, [projects, searchTerm, statusFilter]);

  useEffect(() => {
    if (selectedProject) {
      loadProjectDetails(selectedProject.id);
    }
  }, [selectedProject]);

  const loadProjects = async () => {
    try {
      const fetchedProjects = await Project.list('-created_date', 100);
      setProjects(fetchedProjects);
    } catch (error) {
      console.error('Error loading projects:', error);
    }
    setIsLoading(false);
  };

  const loadProjectDetails = async (projectId) => {
    try {
      const [milestones, messages] = await Promise.all([
        ProjectMilestone.filter({ project_id: projectId }, 'order_index'),
        ClientMessage.filter({ project_id: projectId }, '-created_date', 20)
      ]);
      
      setProjectMilestones(milestones);
      setProjectMessages(messages);
    } catch (error) {
      console.error('Error loading project details:', error);
    }
  };

  const filterProjects = () => {
    let filtered = projects;

    if (searchTerm) {
      filtered = filtered.filter(project => 
        project.project_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        project.client_email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (statusFilter !== 'all') {
      filtered = filtered.filter(project => project.status === statusFilter);
    }

    setFilteredProjects(filtered);
  };

  const updateProjectStatus = async (projectId, newStatus) => {
    try {
      await Project.update(projectId, { status: newStatus });
      loadProjects();
      
      if (selectedProject && selectedProject.id === projectId) {
        setSelectedProject({ ...selectedProject, status: newStatus });
      }
    } catch (error) {
      console.error('Error updating project status:', error);
      alert('Error actualizando el estado del proyecto');
    }
  };

  const updateProjectProgress = async (projectId, newProgress) => {
    try {
      await Project.update(projectId, { progress_percentage: newProgress });
      loadProjects();
      
      if (selectedProject && selectedProject.id === projectId) {
        setSelectedProject({ ...selectedProject, progress_percentage: newProgress });
      }
    } catch (error) {
      console.error('Error updating project progress:', error);
      alert('Error actualizando el progreso del proyecto');
    }
  };

  const getStatusConfig = (status) => {
    const configs = {
      discovery: { label: "Descubrimiento", color: "bg-blue-100 text-blue-800", icon: Search },
      planning: { label: "Planificación", color: "bg-yellow-100 text-yellow-800", icon: Calendar },
      development: { label: "Desarrollo", color: "bg-purple-100 text-purple-800", icon: Play },
      testing: { label: "Pruebas", color: "bg-orange-100 text-orange-800", icon: CheckCircle },
      deployment: { label: "Implementación", color: "bg-indigo-100 text-indigo-800", icon: Play },
      completed: { label: "Completado", color: "bg-green-100 text-green-800", icon: CheckCircle },
      on_hold: { label: "En Pausa", color: "bg-gray-100 text-gray-800", icon: Pause }
    };
    return configs[status] || configs.discovery;
  };

  const getProjectHealth = (project) => {
    const daysUntilDeadline = project.estimated_completion ? 
      Math.floor((new Date(project.estimated_completion) - new Date()) / (1000 * 60 * 60 * 24)) : null;
    
    if (project.status === 'completed') return 'success';
    if (project.status === 'on_hold') return 'warning';
    if (daysUntilDeadline && daysUntilDeadline < 7) return 'danger';
    if (project.progress_percentage < 25) return 'warning';
    return 'success';
  };

  const getHealthColor = (health) => {
    const colors = {
      success: 'text-green-600',
      warning: 'text-yellow-600',
      danger: 'text-red-600'
    };
    return colors[health] || 'text-gray-600';
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header y Controles */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Gestión de Proyectos</h2>
          <p className="text-gray-600">Controla todos los proyectos activos y su progreso</p>
        </div>
        
        <div className="flex gap-3">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
            <Input
              placeholder="Buscar proyectos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 border border-gray-300 rounded-md text-sm"
          >
            <option value="all">Todos los Estados</option>
            <option value="discovery">Descubrimiento</option>
            <option value="planning">Planificación</option>
            <option value="development">Desarrollo</option>
            <option value="testing">Pruebas</option>
            <option value="deployment">Implementación</option>
            <option value="completed">Completado</option>
            <option value="on_hold">En Pausa</option>
          </select>
        </div>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Lista de Proyectos */}
        <div className="lg:col-span-1 space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Proyectos ({filteredProjects.length})</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
              <div className="max-h-96 overflow-y-auto">
                {filteredProjects.map((project) => {
                  const statusConfig = getStatusConfig(project.status);
                  const health = getProjectHealth(project);
                  const StatusIcon = statusConfig.icon;
                  
                  return (
                    <div
                      key={project.id}
                      onClick={() => setSelectedProject(project)}
                      className={`p-4 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                        selectedProject?.id === project.id ? 'bg-emerald-50 border-emerald-200' : ''
                      }`}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-gray-800 truncate">{project.project_name}</h3>
                          <p className="text-sm text-gray-500 truncate">{project.client_email}</p>
                        </div>
                        <div className={`w-3 h-3 rounded-full ${getHealthColor(health)} bg-current opacity-60`}></div>
                      </div>
                      
                      <div className="flex items-center justify-between mb-2">
                        <Badge className={`${statusConfig.color} text-xs`}>
                          <StatusIcon className="w-3 h-3 mr-1" />
                          {statusConfig.label}
                        </Badge>
                        <span className="text-xs text-gray-500">
                          ${project.total_value?.toLocaleString() || '0'}
                        </span>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex justify-between text-xs text-gray-500">
                          <span>Progreso</span>
                          <span>{project.progress_percentage || 0}%</span>
                        </div>
                        <Progress 
                          value={project.progress_percentage || 0} 
                          className="h-2"
                        />
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Panel de Detalles del Proyecto */}
        <div className="lg:col-span-2">
          {selectedProject ? (
            <ProjectDetailPanel
              project={selectedProject}
              milestones={projectMilestones}
              messages={projectMessages}
              onStatusUpdate={updateProjectStatus}
              onProgressUpdate={updateProjectProgress}
              onReload={() => loadProjectDetails(selectedProject.id)}
            />
          ) : (
            <Card>
              <CardContent className="flex items-center justify-center py-16">
                <div className="text-center text-gray-500">
                  <Eye className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                  <p>Selecciona un proyecto para ver los detalles</p>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>
    </div>
  );
}

// Componente del Panel de Detalles
function ProjectDetailPanel({ project, milestones, messages, onStatusUpdate, onProgressUpdate, onReload }) {
  const [activeTab, setActiveTab] = useState('overview');
  const [isEditing, setIsEditing] = useState(false);
  const [editedProgress, setEditedProgress] = useState(project.progress_percentage || 0);
  
  const statusConfig = {
    discovery: { label: "Descubrimiento", color: "bg-blue-100 text-blue-800" },
    planning: { label: "Planificación", color: "bg-yellow-100 text-yellow-800" },
    development: { label: "Desarrollo", color: "bg-purple-100 text-purple-800" },
    testing: { label: "Pruebas", color: "bg-orange-100 text-orange-800" },
    deployment: { label: "Implementación", color: "bg-indigo-100 text-indigo-800" },
    completed: { label: "Completado", color: "bg-green-100 text-green-800" },
    on_hold: { label: "En Pausa", color: "bg-gray-100 text-gray-800" }
  };

  const serviceTypeLabels = {
    automation: "Automatización de Procesos",
    lead_generation: "Generación de Leads",
    ai_implementation: "Implementación de IA",
    digital_transformation: "Transformación Digital",
    custom: "Proyecto Personalizado"
  };

  const handleProgressSave = () => {
    onProgressUpdate(project.id, editedProgress);
    setIsEditing(false);
  };

  const unreadMessages = messages.filter(msg => !msg.is_read && msg.sender_role === 'client').length;

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle className="text-xl text-gray-800">{project.project_name}</CardTitle>
            <p className="text-gray-600 mt-1">{serviceTypeLabels[project.service_type] || project.service_type}</p>
            <p className="text-sm text-gray-500 mt-1">Cliente: {project.client_email}</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge className={statusConfig[project.status]?.color || "bg-gray-100 text-gray-800"}>
              {statusConfig[project.status]?.label || project.status}
            </Badge>
            <select
              value={project.status}
              onChange={(e) => onStatusUpdate(project.id, e.target.value)}
              className="text-sm border border-gray-300 rounded-md px-2 py-1"
            >
              <option value="discovery">Descubrimiento</option>
              <option value="planning">Planificación</option>
              <option value="development">Desarrollo</option>
              <option value="testing">Pruebas</option>
              <option value="deployment">Implementación</option>
              <option value="completed">Completado</option>
              <option value="on_hold">En Pausa</option>
            </select>
          </div>
        </div>
      </CardHeader>
      
      <CardContent>
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Resumen</TabsTrigger>
            <TabsTrigger value="milestones">Hitos</TabsTrigger>
            <TabsTrigger value="messages" className="relative">
              Mensajes
              {unreadMessages > 0 && (
                <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                  {unreadMessages}
                </span>
              )}
            </TabsTrigger>
            <TabsTrigger value="financial">Financiero</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="mt-6 space-y-4">
            {/* Progreso */}
            <div className="bg-gray-50 p-4 rounded-lg">
              <div className="flex justify-between items-center mb-3">
                <h3 className="font-medium text-gray-800">Progreso del Proyecto</h3>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => setIsEditing(!isEditing)}
                >
                  <Pencil className="w-4 h-4 mr-2" />
                  {isEditing ? 'Cancelar' : 'Editar'}
                </Button>
              </div>
              
              {isEditing ? (
                <div className="flex items-center gap-3">
                  <Input
                    type="number"
                    min="0"
                    max="100"
                    value={editedProgress}
                    onChange={(e) => setEditedProgress(parseInt(e.target.value) || 0)}
                    className="w-20"
                  />
                  <span className="text-sm text-gray-600">%</span>
                  <Button size="sm" onClick={handleProgressSave}>
                    Guardar
                  </Button>
                </div>
              ) : (
                <>
                  <Progress value={project.progress_percentage || 0} className="h-3 mb-2" />
                  <div className="text-right text-sm font-medium text-gray-700">
                    {project.progress_percentage || 0}% completado
                  </div>
                </>
              )}
            </div>

            {/* Información del Proyecto */}
            <div className="grid md:grid-cols-2 gap-4">
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-gray-700">Fecha de Inicio</label>
                  <p className="text-gray-600">
                    {project.start_date ? format(new Date(project.start_date), 'dd/MM/yyyy', { locale: es }) : 'No definido'}
                  </p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Entrega Estimada</label>
                  <p className="text-gray-600">
                    {project.estimated_completion ? format(new Date(project.estimated_completion), 'dd/MM/yyyy', { locale: es }) : 'No definido'}
                  </p>
                </div>
                
                {project.next_milestone && (
                  <div>
                    <label className="text-sm font-medium text-gray-700">Próximo Hito</label>
                    <p className="text-gray-600">{project.next_milestone}</p>
                  </div>
                )}
              </div>
              
              <div className="space-y-3">
                <div>
                  <label className="text-sm font-medium text-gray-700">Valor Total</label>
                  <p className="text-gray-600 font-medium">${project.total_value?.toLocaleString() || '0'} USD</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Pagado</label>
                  <p className="text-gray-600">${project.paid_amount?.toLocaleString() || '0'} USD</p>
                </div>
                
                <div>
                  <label className="text-sm font-medium text-gray-700">Pendiente</label>
                  <p className="text-gray-600">${((project.total_value || 0) - (project.paid_amount || 0)).toLocaleString()} USD</p>
                </div>
              </div>
            </div>

            {project.description && (
              <div>
                <label className="text-sm font-medium text-gray-700">Descripción</label>
                <p className="text-gray-600 mt-1">{project.description}</p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="milestones" className="mt-6">
            <MilestoneManager milestones={milestones} projectId={project.id} onReload={onReload} />
          </TabsContent>

          <TabsContent value="messages" className="mt-6">
            <MessageManager messages={messages} projectId={project.id} onReload={onReload} />
          </TabsContent>

          <TabsContent value="financial" className="mt-6">
            <FinancialManager project={project} onReload={onReload} />
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}

// Componente para gestión de hitos
function MilestoneManager({ milestones, projectId, onReload }) {
  const [isCreating, setIsCreating] = useState(false);
  const [newMilestone, setNewMilestone] = useState({
    milestone_name: '',
    description: '',
    due_date: '',
    status: 'pending'
  });

  const updateMilestoneStatus = async (milestoneId, newStatus) => {
    try {
      await ProjectMilestone.update(milestoneId, { 
        status: newStatus,
        completed_date: newStatus === 'completed' ? new Date().toISOString().split('T')[0] : null
      });
      onReload();
    } catch (error) {
      console.error('Error updating milestone:', error);
      alert('Error actualizando el hito');
    }
  };

  const createMilestone = async () => {
    if (!newMilestone.milestone_name || !newMilestone.due_date) {
      alert('Por favor completa los campos requeridos');
      return;
    }

    try {
      await ProjectMilestone.create({
        ...newMilestone,
        project_id: projectId,
        order_index: milestones.length + 1
      });
      
      setNewMilestone({
        milestone_name: '',
        description: '',
        due_date: '',
        status: 'pending'
      });
      setIsCreating(false);
      onReload();
    } catch (error) {
      console.error('Error creating milestone:', error);
      alert('Error creando el hito');
    }
  };

  const statusConfig = {
    pending: { label: "Pendiente", color: "bg-gray-100 text-gray-800" },
    in_progress: { label: "En Progreso", color: "bg-blue-100 text-blue-800" },
    completed: { label: "Completado", color: "bg-green-100 text-green-800" },
    blocked: { label: "Bloqueado", color: "bg-red-100 text-red-800" }
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h3 className="font-medium text-gray-800">Hitos del Proyecto</h3>
        <Button
          size="sm"
          onClick={() => setIsCreating(!isCreating)}
          className="bg-emerald-600 hover:bg-emerald-700"
        >
          {isCreating ? 'Cancelar' : 'Agregar Hito'}
        </Button>
      </div>

      {isCreating && (
        <Card className="bg-gray-50">
          <CardContent className="p-4 space-y-3">
            <Input
              placeholder="Nombre del hito"
              value={newMilestone.milestone_name}
              onChange={(e) => setNewMilestone({...newMilestone, milestone_name: e.target.value})}
            />
            <Input
              placeholder="Descripción"
              value={newMilestone.description}
              onChange={(e) => setNewMilestone({...newMilestone, description: e.target.value})}
            />
            <Input
              type="date"
              value={newMilestone.due_date}
              onChange={(e) => setNewMilestone({...newMilestone, due_date: e.target.value})}
            />
            <div className="flex gap-2">
              <Button size="sm" onClick={createMilestone}>
                Crear Hito
              </Button>
              <Button size="sm" variant="outline" onClick={() => setIsCreating(false)}>
                Cancelar
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="space-y-3">
        {milestones.map((milestone) => (
          <div key={milestone.id} className="border rounded-lg p-4">
            <div className="flex justify-between items-start mb-2">
              <div>
                <h4 className="font-medium text-gray-800">{milestone.milestone_name}</h4>
                {milestone.description && (
                  <p className="text-sm text-gray-600 mt-1">{milestone.description}</p>
                )}
              </div>
              <div className="flex items-center gap-2">
                <Badge className={statusConfig[milestone.status]?.color || "bg-gray-100 text-gray-800"}>
                  {statusConfig[milestone.status]?.label || milestone.status}
                </Badge>
                <select
                  value={milestone.status}
                  onChange={(e) => updateMilestoneStatus(milestone.id, e.target.value)}
                  className="text-xs border border-gray-300 rounded px-2 py-1"
                >
                  <option value="pending">Pendiente</option>
                  <option value="in_progress">En Progreso</option>
                  <option value="completed">Completado</option>
                  <option value="blocked">Bloqueado</option>
                </select>
              </div>
            </div>
            
            <div className="flex justify-between text-sm text-gray-500">
              <span>
                Vence: {format(new Date(milestone.due_date), 'dd/MM/yyyy', { locale: es })}
              </span>
              {milestone.completed_date && (
                <span className="text-green-600">
                  Completado: {format(new Date(milestone.completed_date), 'dd/MM/yyyy', { locale: es })}
                </span>
              )}
            </div>
          </div>
        ))}
        
        {milestones.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <Calendar className="w-8 h-8 mx-auto mb-2 text-gray-300" />
            <p>No hay hitos definidos para este proyecto</p>
          </div>
        )}
      </div>
    </div>
  );
}

// Componente para gestión de mensajes
function MessageManager({ messages, projectId, onReload }) {
  const [newMessage, setNewMessage] = useState('');
  const [isSending, setIsSending] = useState(false);

  const sendMessage = async () => {
    if (!newMessage.trim()) return;

    setIsSending(true);
    try {
      await ClientMessage.create({
        project_id: projectId,
        sender_email: 'admin@simiriki.com', // Email del admin
        sender_role: 'admin',
        message: newMessage,
        message_type: 'update'
      });
      
      setNewMessage('');
      onReload();
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Error enviando mensaje');
    }
    setIsSending(false);
  };

  return (
    <div className="space-y-4">
      <div className="max-h-64 overflow-y-auto space-y-3">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`p-3 rounded-lg ${
              message.sender_role === 'admin' 
                ? 'bg-emerald-50 border-l-4 border-emerald-500 ml-8' 
                : 'bg-gray-50 border-l-4 border-gray-300 mr-8'
            }`}
          >
            <div className="flex justify-between items-start mb-1">
              <span className="text-sm font-medium text-gray-700">
                {message.sender_role === 'admin' ? 'Equipo Simiriki' : 'Cliente'}
              </span>
              <span className="text-xs text-gray-500">
                {format(new Date(message.created_date), 'dd/MM/yyyy HH:mm', { locale: es })}
              </span>
            </div>
            <p className="text-gray-600">{message.message}</p>
            
            {message.attachments && message.attachments.length > 0 && (
              <div className="mt-2 space-y-1">
                {message.attachments.map((attachment, index) => (
                  <a
                    key={index}
                    href={attachment}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-sm text-emerald-600 hover:text-emerald-700 flex items-center"
                  >
                    <Paperclip className="w-3 h-3 mr-1" />
                    Archivo adjunto {index + 1}
                  </a>
                ))}
              </div>
            )}
          </div>
        ))}
        
        {messages.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            <MessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-300" />
            <p>No hay mensajes en este proyecto</p>
          </div>
        )}
      </div>

      <div className="border-t pt-4">
        <div className="flex gap-2">
          <Input
            placeholder="Escribir mensaje al cliente..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
            className="flex-1"
          />
          <Button
            onClick={sendMessage}
            disabled={isSending || !newMessage.trim()}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            {isSending ? (
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
            ) : (
              <Send className="w-4 h-4" />
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

// Componente para gestión financiera
function FinancialManager({ project, onReload }) {
  const [isEditing, setIsEditing] = useState(false);
  const [editedProject, setEditedProject] = useState({
    total_value: project.total_value || 0,
    paid_amount: project.paid_amount || 0
  });

  const updateFinancials = async () => {
    try {
      await Project.update(project.id, editedProject);
      setIsEditing(false);
      onReload();
    } catch (error) {
      console.error('Error updating financials:', error);
      alert('Error actualizando la información financiera');
    }
  };

  const paymentPercentage = project.total_value > 0 ? (project.paid_amount / project.total_value) * 100 : 0;
  const remainingAmount = (project.total_value || 0) - (project.paid_amount || 0);

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center">
              <DollarSign className="w-5 h-5 mr-2 text-green-600" />
              Resumen Financiero
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm text-gray-600">Progreso de Pagos</span>
                <span className="text-sm font-medium">{paymentPercentage.toFixed(1)}%</span>
              </div>
              <Progress value={paymentPercentage} className="h-3" />
            </div>
            
            <div className="space-y-2">
              <div className="flex justify-between">
                <span className="text-gray-600">Valor Total:</span>
                <span className="font-medium">${project.total_value?.toLocaleString() || '0'}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Pagado:</span>
                <span className="font-medium text-green-600">${project.paid_amount?.toLocaleString() || '0'}</span>
              </div>
              <div className="flex justify-between border-t pt-2">
                <span className="text-gray-600">Pendiente:</span>
                <span className="font-medium text-orange-600">${remainingAmount.toLocaleString()}</span>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg flex items-center justify-between">
              <span className="flex items-center">
                <Pencil className="w-5 h-5 mr-2 text-blue-600" />
                Editar Financieros
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => setIsEditing(!isEditing)}
              >
                {isEditing ? 'Cancelar' : 'Editar'}
              </Button>
            </CardTitle>
          </CardHeader>
          <CardContent>
            {isEditing ? (
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-gray-700">Valor Total (USD)</label>
                  <Input
                    type="number"
                    value={editedProject.total_value}
                    onChange={(e) => setEditedProject({
                      ...editedProject,
                      total_value: parseFloat(e.target.value) || 0
                    })}
                  />
                </div>
                <div>
                  <label className="text-sm font-medium text-gray-700">Monto Pagado (USD)</label>
                  <Input
                    type="number"
                    value={editedProject.paid_amount}
                    onChange={(e) => setEditedProject({
                      ...editedProject,
                      paid_amount: parseFloat(e.target.value) || 0
                    })}
                  />
                </div>
                <div className="flex gap-2">
                  <Button size="sm" onClick={updateFinancials}>
                    Guardar Cambios
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => setIsEditing(false)}>
                    Cancelar
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <p>Haz clic en "Editar" para modificar los valores financieros</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
