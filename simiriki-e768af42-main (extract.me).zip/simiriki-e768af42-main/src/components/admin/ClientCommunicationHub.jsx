import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  MessageSquare, 
  Send, 
  Users, 
  AlertCircle, 
  CheckCircle,
  Clock,
  Search,
  Filter,
  Mail,
  Phone,
  MessageCircle
} from 'lucide-react';
import { ClientMessage } from '@/api/entities';
import { Project } from '@/api/entities';
import { User } from '@/api/entities';
import { SendEmail } from '@/api/integrations';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function ClientCommunicationHub() {
  const [messages, setMessages] = useState([]);
  const [projects, setProjects] = useState([]);
  const [filteredMessages, setFilteredMessages] = useState([]);
  const [selectedProject, setSelectedProject] = useState('all');
  const [messageFilter, setMessageFilter] = useState('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isLoading, setIsLoading] = useState(true);
  const [replyTo, setReplyTo] = useState(null);
  const [replyMessage, setReplyMessage] = useState('');
  const [isSending, setIsSending] = useState(false);
  const [activeTab, setActiveTab] = useState('inbox');

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterMessages();
  }, [messages, selectedProject, messageFilter, searchTerm]);

  const loadData = async () => {
    try {
      const [fetchedMessages, fetchedProjects] = await Promise.all([
        ClientMessage.list('-created_date', 100),
        Project.list('-created_date', 50)
      ]);
      
      setMessages(fetchedMessages);
      setProjects(fetchedProjects);
    } catch (error) {
      console.error('Error loading data:', error);
    }
    setIsLoading(false);
  };

  const filterMessages = () => {
    let filtered = messages;

    // Filtrar por proyecto
    if (selectedProject !== 'all') {
      filtered = filtered.filter(msg => msg.project_id === selectedProject);
    }

    // Filtrar por tipo de mensaje
    if (messageFilter === 'unread') {
      filtered = filtered.filter(msg => !msg.is_read && msg.sender_role === 'client');
    } else if (messageFilter === 'urgent') {
      filtered = filtered.filter(msg => msg.message_type === 'urgent');
    } else if (messageFilter === 'questions') {
      filtered = filtered.filter(msg => msg.message_type === 'question');
    }

    // Filtrar por búsqueda
    if (searchTerm) {
      filtered = filtered.filter(msg => 
        msg.message.toLowerCase().includes(searchTerm.toLowerCase()) ||
        msg.sender_email.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredMessages(filtered);
  };

  const markAsRead = async (messageId) => {
    try {
      await ClientMessage.update(messageId, { is_read: true });
      setMessages(messages.map(msg => 
        msg.id === messageId ? { ...msg, is_read: true } : msg
      ));
    } catch (error) {
      console.error('Error marking message as read:', error);
    }
  };

  const sendReply = async () => {
    if (!replyMessage.trim() || !replyTo) return;

    setIsSending(true);
    try {
      // Crear mensaje en el sistema
      await ClientMessage.create({
        project_id: replyTo.project_id,
        sender_email: 'admin@simiriki.com',
        sender_role: 'admin',
        message: replyMessage,
        message_type: 'update'
      });

      // Enviar email al cliente
      const project = projects.find(p => p.id === replyTo.project_id);
      await SendEmail({
        to: replyTo.sender_email,
        subject: `Respuesta sobre tu proyecto: ${project?.project_name || 'Proyecto Simiriki'}`,
        body: `
          <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
            <h2 style="color: #10B981;">Respuesta del Equipo Simiriki</h2>
            
            <div style="background-color: #f9f9f9; padding: 15px; border-radius: 8px; margin: 20px 0;">
              <h4 style="margin: 0 0 10px 0; color: #374151;">Tu mensaje:</h4>
              <p style="margin: 0; color: #6B7280; font-style: italic;">"${replyTo.message}"</p>
            </div>
            
            <div style="background-color: #ecfdf5; padding: 15px; border-radius: 8px; border-left: 4px solid #10B981;">
              <h4 style="margin: 0 0 10px 0; color: #374151;">Nuestra respuesta:</h4>
              <p style="margin: 0; color: #374151;">${replyMessage}</p>
            </div>
            
            <p style="margin-top: 20px; color: #6B7280;">
              También puedes ver esta respuesta en tu portal de cliente.
            </p>
            
            <div style="text-align: center; margin-top: 30px;">
              <a href="https://preview--simiriki-e768af42.base44.dev/ClientPortal" 
                 style="background-color: #10B981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                Ver en Mi Portal
              </a>
            </div>
            
            <p style="margin-top: 30px; color: #6B7280; font-size: 14px;">
              Saludos,<br>
              <strong>El Equipo de Simiriki</strong>
            </p>
          </div>
        `,
        from_name: 'Equipo Simiriki'
      });

      setReplyMessage('');
      setReplyTo(null);
      loadData(); // Recargar mensajes
      
    } catch (error) {
      console.error('Error sending reply:', error);
      alert('Error enviando la respuesta');
    }
    setIsSending(false);
  };

  const getMessageTypeConfig = (type) => {
    const configs = {
      general: { label: 'General', color: 'bg-gray-100 text-gray-800', icon: MessageSquare },
      question: { label: 'Pregunta', color: 'bg-blue-100 text-blue-800', icon: MessageCircle },
      update: { label: 'Actualización', color: 'bg-green-100 text-green-800', icon: CheckCircle },
      deliverable: { label: 'Entregable', color: 'bg-purple-100 text-purple-800', icon: CheckCircle },
      urgent: { label: 'Urgente', color: 'bg-red-100 text-red-800', icon: AlertCircle }
    };
    return configs[type] || configs.general;
  };

  const unreadCount = messages.filter(msg => !msg.is_read && msg.sender_role === 'client').length;
  const urgentCount = messages.filter(msg => msg.message_type === 'urgent' && msg.sender_role === 'client').length;
  const questionsCount = messages.filter(msg => msg.message_type === 'question' && msg.sender_role === 'client').length;

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col md:flex-row gap-4 justify-between items-start md:items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Centro de Comunicación</h2>
          <p className="text-gray-600">Gestiona todas las conversaciones con tus clientes</p>
        </div>
        
        {/* Stats Cards */}
        <div className="flex gap-3">
          <Card className="bg-red-50 border-red-200">
            <CardContent className="p-3">
              <div className="flex items-center space-x-2">
                <AlertCircle className="w-4 h-4 text-red-600" />
                <div>
                  <div className="text-sm font-medium text-red-800">{unreadCount}</div>
                  <div className="text-xs text-red-600">Sin leer</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-yellow-50 border-yellow-200">
            <CardContent className="p-3">
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4 text-yellow-600" />
                <div>
                  <div className="text-sm font-medium text-yellow-800">{urgentCount}</div>
                  <div className="text-xs text-yellow-600">Urgentes</div>
                </div>
              </div>
            </CardContent>
          </Card>
          
          <Card className="bg-blue-50 border-blue-200">
            <CardContent className="p-3">
              <div className="flex items-center space-x-2">
                <MessageCircle className="w-4 h-4 text-blue-600" />
                <div>
                  <div className="text-sm font-medium text-blue-800">{questionsCount}</div>
                  <div className="text-xs text-blue-600">Preguntas</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Filtros */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Buscar mensajes..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            
            <select
              value={selectedProject}
              onChange={(e) => setSelectedProject(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">Todos los Proyectos</option>
              {projects.map(project => (
                <option key={project.id} value={project.id}>
                  {project.project_name} - {project.client_email}
                </option>
              ))}
            </select>
            
            <select
              value={messageFilter}
              onChange={(e) => setMessageFilter(e.target.value)}
              className="px-3 py-2 border border-gray-300 rounded-md text-sm"
            >
              <option value="all">Todos los Mensajes</option>
              <option value="unread">Sin Leer ({unreadCount})</option>
              <option value="urgent">Urgentes ({urgentCount})</option>
              <option value="questions">Preguntas ({questionsCount})</option>
            </select>
          </div>
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="inbox" className="relative">
            Bandeja de Entrada
            {unreadCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="compose">Nuevo Mensaje</TabsTrigger>
        </TabsList>

        <TabsContent value="inbox" className="mt-6">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Lista de Mensajes */}
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Mensajes ({filteredMessages.length})</CardTitle>
                </CardHeader>
                <CardContent className="p-0">
                  <div className="max-h-96 overflow-y-auto">
                    {filteredMessages.map((message) => {
                      const typeConfig = getMessageTypeConfig(message.message_type);
                      const project = projects.find(p => p.id === message.project_id);
                      const TypeIcon = typeConfig.icon;
                      
                      return (
                        <div
                          key={message.id}
                          className={`p-4 border-b cursor-pointer hover:bg-gray-50 transition-colors ${
                            !message.is_read && message.sender_role === 'client' 
                              ? 'bg-blue-50 border-l-4 border-l-blue-500' 
                              : ''
                          }`}
                          onClick={() => {
                            if (!message.is_read && message.sender_role === 'client') {
                              markAsRead(message.id);
                            }
                          }}
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex items-center space-x-2">
                              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                                message.sender_role === 'client' ? 'bg-blue-100' : 'bg-emerald-100'
                              }`}>
                                {message.sender_role === 'client' ? (
                                  <Users className="w-4 h-4 text-blue-600" />
                                ) : (
                                  <MessageSquare className="w-4 h-4 text-emerald-600" />
                                )}
                              </div>
                              <div>
                                <div className="font-medium text-gray-800">
                                  {message.sender_role === 'client' ? 'Cliente' : 'Equipo'}
                                </div>
                                <div className="text-sm text-gray-500">{message.sender_email}</div>
                              </div>
                            </div>
                            <div className="text-right">
                              <Badge className={`${typeConfig.color} text-xs mb-1`}>
                                <TypeIcon className="w-3 h-3 mr-1" />
                                {typeConfig.label}
                              </Badge>
                              <div className="text-xs text-gray-500">
                                {format(new Date(message.created_date), 'dd/MM HH:mm', { locale: es })}
                              </div>
                            </div>
                          </div>
                          
                          <div className="mb-2">
                            <div className="text-sm text-gray-600 mb-1">
                              Proyecto: {project?.project_name || 'Sin proyecto'}
                            </div>
                            <p className="text-gray-800 line-clamp-2">{message.message}</p>
                          </div>
                          
                          {message.sender_role === 'client' && (
                            <div className="flex justify-end">
                              <Button
                                size="sm"
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setReplyTo(message);
                                }}
                                className="bg-emerald-600 hover:bg-emerald-700"
                              >
                                <Send className="w-3 h-3 mr-1" />
                                Responder
                              </Button>
                            </div>
                          )}
                        </div>
                      );
                    })}
                    
                    {filteredMessages.length === 0 && (
                      <div className="text-center py-8 text-gray-500">
                        <MessageSquare className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                        <p>No hay mensajes que coincidan con los filtros</p>
                      </div>
                    )}
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Panel de Respuesta */}
            <div className="lg:col-span-1">
              {replyTo ? (
                <Card>
                  <CardHeader>
                    <CardTitle className="text-lg">Responder Mensaje</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="bg-gray-50 p-3 rounded-lg">
                      <div className="text-sm font-medium text-gray-700 mb-1">Mensaje Original:</div>
                      <p className="text-sm text-gray-600">"{replyTo.message}"</p>
                      <div className="text-xs text-gray-500 mt-2">
                        De: {replyTo.sender_email}
                      </div>
                    </div>
                    
                    <div>
                      <label className="text-sm font-medium text-gray-700">Tu Respuesta:</label>
                      <Textarea
                        value={replyMessage}
                        onChange={(e) => setReplyMessage(e.target.value)}
                        placeholder="Escribe tu respuesta aquí..."
                        rows={6}
                        className="mt-2"
                      />
                    </div>
                    
                    <div className="flex gap-2">
                      <Button
                        onClick={sendReply}
                        disabled={isSending || !replyMessage.trim()}
                        className="flex-1 bg-emerald-600 hover:bg-emerald-700"
                      >
                        {isSending ? (
                          <>
                            <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                            Enviando...
                          </>
                        ) : (
                          <>
                            <Send className="w-4 h-4 mr-2" />
                            Enviar
                          </>
                        )}
                      </Button>
                      <Button
                        variant="outline"
                        onClick={() => {
                          setReplyTo(null);
                          setReplyMessage('');
                        }}
                      >
                        Cancelar
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="flex items-center justify-center py-16">
                    <div className="text-center text-gray-500">
                      <MessageSquare className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                      <p>Selecciona un mensaje para responder</p>
                    </div>
                  </CardContent>
                </Card>
              )}
            </div>
          </div>
        </TabsContent>

        <TabsContent value="compose" className="mt-6">
          <BroadcastMessageComposer projects={projects} onSent={loadData} />
        </TabsContent>
      </Tabs>
    </div>
  );
}

// Componente para enviar mensajes masivos
function BroadcastMessageComposer({ projects, onSent }) {
  const [selectedProjects, setSelectedProjects] = useState([]);
  const [messageSubject, setMessageSubject] = useState('');
  const [messageContent, setMessageContent] = useState('');
  const [isSending, setIsSending] = useState(false);

  const handleProjectToggle = (projectId) => {
    setSelectedProjects(prev => 
      prev.includes(projectId) 
        ? prev.filter(id => id !== projectId)
        : [...prev, projectId]
    );
  };

  const selectAllProjects = () => {
    setSelectedProjects(projects.map(p => p.id));
  };

  const clearSelection = () => {
    setSelectedProjects([]);
  };

  const sendBroadcastMessage = async () => {
    if (!messageContent.trim() || selectedProjects.length === 0) {
      alert('Por favor completa el mensaje y selecciona al menos un proyecto');
      return;
    }

    setIsSending(true);
    try {
      for (const projectId of selectedProjects) {
        const project = projects.find(p => p.id === projectId);
        
        // Crear mensaje en el sistema
        await ClientMessage.create({
          project_id: projectId,
          sender_email: 'admin@simiriki.com',
          sender_role: 'admin',
          message: messageContent,
          message_type: 'update'
        });

        // Enviar email
        await SendEmail({
          to: project.client_email,
          subject: messageSubject || `Actualización de tu proyecto: ${project.project_name}`,
          body: `
            <div style="font-family: Arial, sans-serif; max-width: 600px; margin: 0 auto;">
              <h2 style="color: #10B981;">Actualización de tu Proyecto</h2>
              
              <div style="background-color: #f9f9f9; padding: 15px; border-radius: 8px; margin: 20px 0;">
                <h3 style="margin-top: 0; color: #374151;">Proyecto: ${project.project_name}</h3>
                <p style="color: #374151;">${messageContent}</p>
              </div>
              
              <div style="text-align: center; margin-top: 30px;">
                <a href="https://preview--simiriki-e768af42.base44.dev/ClientPortal" 
                   style="background-color: #10B981; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">
                  Ver en Mi Portal
                </a>
              </div>
              
              <p style="margin-top: 30px; color: #6B7280; font-size: 14px;">
                Saludos,<br>
                <strong>El Equipo de Simiriki</strong>
              </p>
            </div>
          `,
          from_name: 'Equipo Simiriki'
        });
      }

      // Limpiar formulario
      setMessageSubject('');
      setMessageContent('');
      setSelectedProjects([]);
      
      alert(`Mensaje enviado exitosamente a ${selectedProjects.length} cliente(s)`);
      onSent();
      
    } catch (error) {
      console.error('Error sending broadcast message:', error);
      alert('Error enviando el mensaje');
    }
    setIsSending(false);
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Enviar Mensaje a Múltiples Clientes</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div>
          <label className="text-sm font-medium text-gray-700">Asunto del Email (opcional)</label>
          <Input
            value={messageSubject}
            onChange={(e) => setMessageSubject(e.target.value)}
            placeholder="Actualización importante de tu proyecto..."
            className="mt-2"
          />
        </div>

        <div>
          <label className="text-sm font-medium text-gray-700">Mensaje</label>
          <Textarea
            value={messageContent}
            onChange={(e) => setMessageContent(e.target.value)}
            placeholder="Escribe tu mensaje aquí..."
            rows={8}
            className="mt-2"
          />
        </div>

        <div>
          <div className="flex justify-between items-center mb-3">
            <label className="text-sm font-medium text-gray-700">
              Seleccionar Proyectos ({selectedProjects.length} seleccionados)
            </label>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={selectAllProjects}>
                Seleccionar Todos
              </Button>
              <Button size="sm" variant="outline" onClick={clearSelection}>
                Limpiar
              </Button>
            </div>
          </div>
          
          <div className="max-h-48 overflow-y-auto border rounded-lg p-3 space-y-2">
            {projects.map((project) => (
              <div key={project.id} className="flex items-center space-x-3">
                <input
                  type="checkbox"
                  id={project.id}
                  checked={selectedProjects.includes(project.id)}
                  onChange={() => handleProjectToggle(project.id)}
                  className="rounded"
                />
                <label htmlFor={project.id} className="flex-1 text-sm cursor-pointer">
                  <div className="font-medium">{project.project_name}</div>
                  <div className="text-gray-500">{project.client_email}</div>
                </label>
              </div>
            ))}
          </div>
        </div>

        <Button
          onClick={sendBroadcastMessage}
          disabled={isSending || !messageContent.trim() || selectedProjects.length === 0}
          className="w-full bg-emerald-600 hover:bg-emerald-700"
        >
          {isSending ? (
            <>
              <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
              Enviando a {selectedProjects.length} cliente(s)...
            </>
          ) : (
            <>
              <Mail className="w-4 h-4 mr-2" />
              Enviar Mensaje a {selectedProjects.length} Cliente(s)
            </>
          )}
        </Button>
      </CardContent>
    </Card>
  );
}