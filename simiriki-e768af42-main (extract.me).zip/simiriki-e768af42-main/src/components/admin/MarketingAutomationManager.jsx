import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  Mail, 
  Users, 
  TrendingUp, 
  Clock,
  Play,
  Pause,
  Eye,
  Settings,
  Zap,
  Target,
  BarChart3,
  Calendar,
  Send,
  CheckCircle,
  AlertCircle,
  Loader
} from 'lucide-react';
import { MarketingSequence } from '@/api/entities';
import { ScheduledEmail } from '@/api/entities';
import { marketingAutomation } from '@/api/functions';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function MarketingAutomationManager() {
  const [sequences, setSequences] = useState([]);
  const [scheduledEmails, setScheduledEmails] = useState([]);
  const [stats, setStats] = useState({
    totalSequences: 0,
    activeSequences: 0,
    emailsSentToday: 0,
    conversionRate: 0
  });
  const [isLoading, setIsLoading] = useState(true);
  const [isRunningAutomation, setIsRunningAutomation] = useState(false);
  const [testEmail, setTestEmail] = useState('');
  const [testName, setTestName] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [fetchedSequences, fetchedEmails] = await Promise.all([
        MarketingSequence.list('-created_date', 100),
        ScheduledEmail.list('-created_date', 50)
      ]);

      setSequences(fetchedSequences);
      setScheduledEmails(fetchedEmails);
      
      // Calcular estadísticas
      const today = new Date().toISOString().split('T')[0];
      const emailsSentToday = fetchedEmails.filter(email => 
        email.sent_date && email.sent_date.startsWith(today)
      ).length;
      
      const activeSequences = fetchedSequences.filter(seq => seq.status === 'active').length;
      const meetingScheduled = fetchedSequences.filter(seq => seq.meeting_scheduled).length;
      const conversionRate = fetchedSequences.length > 0 ? (meetingScheduled / fetchedSequences.length) * 100 : 0;

      setStats({
        totalSequences: fetchedSequences.length,
        activeSequences,
        emailsSentToday,
        conversionRate: Math.round(conversionRate)
      });

    } catch (error) {
      console.error('Error loading marketing data:', error);
    }
    setIsLoading(false);
  };

  const runAutomation = async (triggerType = 'manual') => {
    setIsRunningAutomation(true);
    try {
      const response = await marketingAutomation({ trigger_type: triggerType });
      
      if (response.data.success) {
        alert(`✅ Automatización completada:\n- ${response.data.emails_scheduled} emails programados\n- ${response.data.emails_sent} emails enviados\n- ${response.data.sequences_processed} secuencias procesadas`);
        loadData(); // Recargar datos
      } else {
        alert('❌ Error en la automatización: ' + response.data.error);
      }
    } catch (error) {
      console.error('Error ejecutando automatización:', error);
      alert('❌ Error ejecutando automatización: ' + error.message);
    }
    setIsRunningAutomation(false);
  };

  const createTestSequence = async () => {
    if (!testEmail || !testName) {
      alert('Por favor ingresa email y nombre para la prueba');
      return;
    }

    try {
      const testSequence = await MarketingSequence.create({
        lead_email: testEmail,
        lead_name: testName,
        industry: 'technology',
        biggest_challenge: 'Automatización de procesos',
        sequence_type: 'test',
        status: 'active',
        started_date: new Date().toISOString().split('T')[0],
        current_day: 0,
        is_lead_from_chat: false
      });

      alert(`✅ Secuencia de prueba creada para ${testEmail}`);
      setTestEmail('');
      setTestName('');
      loadData();
      
      // Ejecutar automatización inmediata
      await runAutomation('immediate');
      
    } catch (error) {
      console.error('Error creando secuencia de prueba:', error);
      alert('❌ Error creando secuencia de prueba');
    }
  };

  const pauseSequence = async (sequenceId) => {
    try {
      await MarketingSequence.update(sequenceId, { status: 'paused' });
      loadData();
    } catch (error) {
      console.error('Error pausando secuencia:', error);
    }
  };

  const resumeSequence = async (sequenceId) => {
    try {
      await MarketingSequence.update(sequenceId, { status: 'active' });
      loadData();
    } catch (error) {
      console.error('Error reanudando secuencia:', error);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center py-8">
        <Loader className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header con estadísticas */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="w-5 h-5 text-blue-500" />
              <div>
                <div className="text-2xl font-bold">{stats.totalSequences}</div>
                <div className="text-sm text-gray-500">Total Secuencias</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Target className="w-5 h-5 text-green-500" />
              <div>
                <div className="text-2xl font-bold">{stats.activeSequences}</div>
                <div className="text-sm text-gray-500">Secuencias Activas</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Mail className="w-5 h-5 text-purple-500" />
              <div>
                <div className="text-2xl font-bold">{stats.emailsSentToday}</div>
                <div className="text-sm text-gray-500">Emails Hoy</div>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <TrendingUp className="w-5 h-5 text-orange-500" />
              <div>
                <div className="text-2xl font-bold">{stats.conversionRate}%</div>
                <div className="text-sm text-gray-500">Conversión</div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="automation" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="automation">Automatización</TabsTrigger>
          <TabsTrigger value="sequences">Secuencias</TabsTrigger>
          <TabsTrigger value="emails">Emails</TabsTrigger>
          <TabsTrigger value="testing">Pruebas</TabsTrigger>
        </TabsList>

        {/* Tab: Automatización */}
        <TabsContent value="automation">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Zap className="w-5 h-5 mr-2 text-emerald-600" />
                Control de Automatización
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-4">
                  <h3 className="font-semibold">Ejecutar Automatización</h3>
                  <div className="space-y-3">
                    <Button 
                      onClick={() => runAutomation('manual')}
                      disabled={isRunningAutomation}
                      className="w-full bg-emerald-600 hover:bg-emerald-700"
                    >
                      {isRunningAutomation ? (
                        <>
                          <Loader className="w-4 h-4 mr-2 animate-spin" />
                          Ejecutando...
                        </>
                      ) : (
                        <>
                          <Play className="w-4 h-4 mr-2" />
                          Ejecutar Ahora (Manual)
                        </>
                      )}
                    </Button>
                    
                    <Button 
                      onClick={() => runAutomation('daily_automation')}
                      disabled={isRunningAutomation}
                      variant="outline"
                      className="w-full"
                    >
                      <Calendar className="w-4 h-4 mr-2" />
                      Simular Rutina Diaria
                    </Button>
                  </div>
                </div>

                <div className="space-y-4">
                  <h3 className="font-semibold">Estado del Sistema</h3>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <span>Motor de Automatización</span>
                      <Badge className="bg-green-100 text-green-800">Activo</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <span>Generación de Contenido IA</span>
                      <Badge className="bg-green-100 text-green-800">Funcionando</Badge>
                    </div>
                    <div className="flex justify-between items-center p-3 bg-gray-50 rounded">
                      <span>Envío de Emails</span>
                      <Badge className="bg-green-100 text-green-800">Conectado</Badge>
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t pt-4">
                <h3 className="font-semibold mb-3">Configuración de Secuencias</h3>
                <div className="grid md:grid-cols-2 gap-4 text-sm">
                  <div>
                    <strong>Día 1:</strong> Email de bienvenida y guía personalizada
                  </div>
                  <div>
                    <strong>Día 3:</strong> Contenido educativo sobre automatización
                  </div>
                  <div>
                    <strong>Día 7:</strong> Caso de estudio específico de su industria
                  </div>
                  <div>
                    <strong>Día 14:</strong> Call-to-action final con urgencia
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Secuencias */}
        <TabsContent value="sequences">
          <Card>
            <CardHeader>
              <CardTitle>Secuencias Activas</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {sequences.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Users className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>No hay secuencias activas</p>
                    <p className="text-sm">Las secuencias se crearán automáticamente cuando lleguen leads</p>
                  </div>
                ) : (
                  sequences.map((sequence) => (
                    <div key={sequence.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start mb-3">
                        <div>
                          <div className="font-semibold">{sequence.lead_name}</div>
                          <div className="text-sm text-gray-500">{sequence.lead_email}</div>
                          <div className="text-sm text-gray-600">{sequence.industry} • {sequence.biggest_challenge}</div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge className={sequence.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'}>
                            {sequence.status}
                          </Badge>
                          {sequence.status === 'active' ? (
                            <Button size="sm" variant="outline" onClick={() => pauseSequence(sequence.id)}>
                              <Pause className="w-4 h-4" />
                            </Button>
                          ) : (
                            <Button size="sm" variant="outline" onClick={() => resumeSequence(sequence.id)}>
                              <Play className="w-4 h-4" />
                            </Button>
                          )}
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                        <div>
                          <div className="text-gray-500">Día Actual</div>
                          <div className="font-medium">{sequence.current_day || 0}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Emails Abiertos</div>
                          <div className="font-medium">{sequence.emails_opened || 0}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Enlaces Clickeados</div>
                          <div className="font-medium">{sequence.links_clicked || 0}</div>
                        </div>
                        <div>
                          <div className="text-gray-500">Reunión Agendada</div>
                          <div className="font-medium">
                            {sequence.meeting_scheduled ? (
                              <CheckCircle className="w-4 h-4 text-green-500" />
                            ) : (
                              <AlertCircle className="w-4 h-4 text-gray-400" />
                            )}
                          </div>
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Emails */}
        <TabsContent value="emails">
          <Card>
            <CardHeader>
              <CardTitle>Emails Programados y Enviados</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {scheduledEmails.length === 0 ? (
                  <div className="text-center py-8 text-gray-500">
                    <Mail className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                    <p>No hay emails programados</p>
                  </div>
                ) : (
                  scheduledEmails.map((email) => (
                    <div key={email.id} className="border rounded-lg p-4">
                      <div className="flex justify-between items-start">
                        <div>
                          <div className="font-semibold">{email.lead_name}</div>
                          <div className="text-sm text-gray-500">{email.lead_email}</div>
                          <div className="text-sm text-gray-600">{email.email_subject}</div>
                        </div>
                        <div className="text-right">
                          <Badge className={
                            email.status === 'sent' ? 'bg-green-100 text-green-800' :
                            email.status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
                            'bg-red-100 text-red-800'
                          }>
                            {email.status}
                          </Badge>
                          <div className="text-sm text-gray-500 mt-1">
                            Día {email.sequence_day}
                          </div>
                        </div>
                      </div>
                      
                      <div className="mt-3 text-sm text-gray-600">
                        {email.status === 'sent' && email.sent_date && (
                          <div>Enviado: {format(new Date(email.sent_date), 'dd/MM/yyyy HH:mm', { locale: es })}</div>
                        )}
                        {email.status === 'pending' && (
                          <div>Programado: {format(new Date(email.scheduled_date), 'dd/MM/yyyy HH:mm', { locale: es })}</div>
                        )}
                      </div>
                    </div>
                  ))
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Tab: Pruebas */}
        <TabsContent value="testing">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Settings className="w-5 h-5 mr-2 text-blue-600" />
                Centro de Pruebas
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="border rounded-lg p-4 bg-blue-50">
                <h3 className="font-semibold mb-3">Crear Secuencia de Prueba</h3>
                <p className="text-sm text-gray-600 mb-4">
                  Crea una secuencia de prueba para verificar que el sistema funciona correctamente.
                </p>
                
                <div className="grid md:grid-cols-2 gap-4">
                  <Input
                    placeholder="Email de prueba"
                    value={testEmail}
                    onChange={(e) => setTestEmail(e.target.value)}
                  />
                  <Input
                    placeholder="Nombre de prueba"
                    value={testName}
                    onChange={(e) => setTestName(e.target.value)}
                  />
                </div>
                
                <Button 
                  onClick={createTestSequence}
                  className="mt-4 bg-blue-600 hover:bg-blue-700"
                  disabled={!testEmail || !testName}
                >
                  <Send className="w-4 h-4 mr-2" />
                  Crear y Ejecutar Prueba
                </Button>
              </div>

              <div className="border rounded-lg p-4">
                <h3 className="font-semibold mb-3">Instrucciones de Prueba</h3>
                <ol className="list-decimal list-inside space-y-2 text-sm text-gray-600">
                  <li>Ingresa un email real al que tengas acceso</li>
                  <li>Haz clic en "Crear y Ejecutar Prueba"</li>
                  <li>El sistema creará una secuencia y enviará el primer email inmediatamente</li>
                  <li>Revisa tu bandeja de entrada</li>
                  <li>Ve a la pestaña "Secuencias" para monitorear el progreso</li>
                  <li>Puedes pausar/reanudar la secuencia desde ahí</li>
                </ol>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}