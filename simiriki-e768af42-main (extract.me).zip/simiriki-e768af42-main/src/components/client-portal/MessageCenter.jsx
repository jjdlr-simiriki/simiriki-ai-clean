import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Badge } from "@/components/ui/badge";
import { 
  Send, 
  Paperclip, 
  Download, 
  MessageSquare,
  AlertCircle,
  Clock,
  CheckCircle,
  User,
  Users,
  FileText,
  Image as ImageIcon,
  File
} from 'lucide-react';
import { ClientMessage } from '@/api/entities';
import { User } from '@/api/entities';
import { UploadFile } from '@/api/integrations';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

export default function MessageCenter({ projectId }) {
  const [messages, setMessages] = useState([]);
  const [newMessage, setNewMessage] = useState('');
  const [messageType, setMessageType] = useState('general');
  const [isLoading, setIsLoading] = useState(true);
  const [isSending, setIsSending] = useState(false);
  const [user, setUser] = useState(null);
  const [attachments, setAttachments] = useState([]);
  const [isUploading, setIsUploading] = useState(false);
  const messagesEndRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    loadMessages();
    getCurrentUser();
  }, [projectId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const getCurrentUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Error getting current user:', error);
    }
  };

  const loadMessages = async () => {
    try {
      const fetchedMessages = await ClientMessage.filter(
        { project_id: projectId }, 
        '-created_date', 
        50
      );
      setMessages(fetchedMessages.reverse()); // Más antiguos primero
      
      // Marcar mensajes como leídos si es el cliente
      if (user && user.role !== 'admin') {
        const unreadMessages = fetchedMessages.filter(
          msg => !msg.is_read && msg.sender_role === 'admin'
        );
        
        for (const msg of unreadMessages) {
          await ClientMessage.update(msg.id, { is_read: true });
        }
      }
    } catch (error) {
      console.error('Error loading messages:', error);
    }
    setIsLoading(false);
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleFileUpload = async (event) => {
    const files = Array.from(event.target.files);
    if (files.length === 0) return;

    setIsUploading(true);
    
    try {
      const uploadPromises = files.map(async (file) => {
        const { file_url } = await UploadFile({ file });
        return {
          name: file.name,
          url: file_url,
          size: file.size,
          type: file.type
        };
      });

      const uploadedFiles = await Promise.all(uploadPromises);
      setAttachments([...attachments, ...uploadedFiles]);
    } catch (error) {
      console.error('Error uploading files:', error);
      alert('Error subiendo archivos. Por favor intenta de nuevo.');
    }
    
    setIsUploading(false);
    fileInputRef.current.value = '';
  };

  const removeAttachment = (index) => {
    setAttachments(attachments.filter((_, i) => i !== index));
  };

  const sendMessage = async () => {
    if (!newMessage.trim() && attachments.length === 0) return;

    setIsSending(true);
    
    try {
      const messageData = {
        project_id: projectId,
        sender_email: user.email,
        sender_role: user.role,
        message: newMessage.trim(),
        message_type: messageType,
        attachments: attachments.map(att => att.url)
      };

      await ClientMessage.create(messageData);
      
      setNewMessage('');
      setAttachments([]);
      setMessageType('general');
      
      // Recargar mensajes
      await loadMessages();
      
    } catch (error) {
      console.error('Error sending message:', error);
      alert('Error enviando mensaje. Por favor intenta de nuevo.');
    }
    
    setIsSending(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const getMessageTypeConfig = (type) => {
    const configs = {
      general: { label: 'General', color: 'bg-gray-100 text-gray-800' },
      question: { label: 'Pregunta', color: 'bg-blue-100 text-blue-800' },
      update: { label: 'Actualización', color: 'bg-green-100 text-green-800' },
      deliverable: { label: 'Entregable', color: 'bg-purple-100 text-purple-800' },
      urgent: { label: 'Urgente', color: 'bg-red-100 text-red-800' }
    };
    return configs[type] || configs.general;
  };

  const getFileIcon = (fileType) => {
    if (fileType.startsWith('image/')) return <ImageIcon className="w-4 h-4" />;
    if (fileType.includes('pdf') || fileType.includes('document')) return <FileText className="w-4 h-4" />;
    return <File className="w-4 h-4" />;
  };

  if (isLoading) {
    return (
      <Card>
        <CardContent className="p-8 text-center">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emerald-600 mx-auto"></div>
          <p className="text-gray-500 mt-4">Cargando mensajes...</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center">
          <MessageSquare className="w-5 h-5 mr-2" />
          Centro de Mensajes
        </CardTitle>
        <p className="text-sm text-gray-600">
          Comunícate directamente con el equipo de Simiriki
        </p>
      </CardHeader>
      <CardContent className="p-0">
        {/* Messages List */}
        <div className="h-96 overflow-y-auto p-4 space-y-4 border-b">
          {messages.length === 0 ? (
            <div className="text-center py-8">
              <MessageSquare className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No hay mensajes aún.</p>
              <p className="text-sm text-gray-400">¡Inicia la conversación!</p>
            </div>
          ) : (
            messages.map((message) => (
              <div
                key={message.id}
                className={`flex ${message.sender_role === 'admin' ? 'justify-start' : 'justify-end'}`}
              >
                <div
                  className={`max-w-[80%] rounded-lg p-3 ${
                    message.sender_role === 'admin'
                      ? 'bg-gray-100 text-gray-800'
                      : 'bg-emerald-600 text-white'
                  }`}
                >
                  {/* Message Header */}
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center space-x-2">
                      {message.sender_role === 'admin' ? (
                        <Users className="w-4 h-4" />
                      ) : (
                        <User className="w-4 h-4" />
                      )}
                      <span className="text-sm font-medium">
                        {message.sender_role === 'admin' ? 'Equipo Simiriki' : 'Tú'}
                      </span>
                      {message.message_type !== 'general' && (
                        <Badge className={getMessageTypeConfig(message.message_type).color} size="sm">
                          {getMessageTypeConfig(message.message_type).label}
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Message Content */}
                  <div className="mb-2">
                    <p className="whitespace-pre-wrap">{message.message}</p>
                  </div>

                  {/* Attachments */}
                  {message.attachments && message.attachments.length > 0 && (
                    <div className="space-y-2 mb-2">
                      {message.attachments.map((attachment, index) => (
                        <a
                          key={index}
                          href={attachment}
                          target="_blank"
                          rel="noopener noreferrer"
                          className={`flex items-center space-x-2 p-2 rounded border ${
                            message.sender_role === 'admin'
                              ? 'bg-white border-gray-200 hover:bg-gray-50'
                              : 'bg-emerald-700 border-emerald-500 hover:bg-emerald-700'
                          }`}
                        >
                          {getFileIcon('application/pdf')}
                          <span className="text-sm">Archivo adjunto {index + 1}</span>
                          <Download className="w-3 h-3 ml-auto" />
                        </a>
                      ))}
                    </div>
                  )}

                  {/* Message Timestamp */}
                  <div className={`text-xs ${
                    message.sender_role === 'admin' ? 'text-gray-500' : 'text-emerald-100'
                  }`}>
                    {format(new Date(message.created_date), "dd/MM/yyyy 'a las' HH:mm", { locale: es })}
                  </div>
                </div>
              </div>
            ))
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* Message Input */}
        <div className="p-4 space-y-4">
          {/* Message Type Selector */}
          <div className="flex flex-wrap gap-2">
            {['general', 'question', 'update', 'urgent'].map((type) => (
              <Button
                key={type}
                variant={messageType === type ? "default" : "outline"}
                size="sm"
                onClick={() => setMessageType(type)}
                className="text-xs"
              >
                {getMessageTypeConfig(type).label}
              </Button>
            ))}
          </div>

          {/* Attachments Preview */}
          {attachments.length > 0 && (
            <div className="space-y-2">
              <p className="text-sm font-medium text-gray-700">Archivos adjuntos:</p>
              {attachments.map((file, index) => (
                <div key={index} className="flex items-center justify-between p-2 bg-gray-50 rounded">
                  <div className="flex items-center space-x-2">
                    {getFileIcon(file.type)}
                    <span className="text-sm">{file.name}</span>
                    <span className="text-xs text-gray-500">
                      ({(file.size / 1024).toFixed(1)} KB)
                    </span>
                  </div>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => removeAttachment(index)}
                    className="text-red-600 hover:text-red-800"
                  >
                    ×
                  </Button>
                </div>
              ))}
            </div>
          )}

          {/* Message Input */}
          <div className="flex items-end space-x-2">
            <div className="flex-1">
              <Textarea
                value={newMessage}
                onChange={(e) => setNewMessage(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Escribe tu mensaje..."
                className="min-h-[80px] resize-none"
                disabled={isSending}
              />
            </div>
            <div className="flex flex-col space-y-2">
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
                accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.gif"
              />
              <Button
                variant="outline"
                size="sm"
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="p-2"
              >
                {isUploading ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-emerald-600"></div>
                ) : (
                  <Paperclip className="w-4 h-4" />
                )}
              </Button>
              <Button
                onClick={sendMessage}
                disabled={isSending || (!newMessage.trim() && attachments.length === 0)}
                className="bg-emerald-600 hover:bg-emerald-700 p-2"
              >
                {isSending ? (
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white"></div>
                ) : (
                  <Send className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>

          <p className="text-xs text-gray-500">
            Presiona Enter para enviar, Shift+Enter para nueva línea
          </p>
        </div>
      </CardContent>
    </Card>
  );
}