import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { 
  FolderOpen, 
  Upload, 
  Download, 
  FileText, 
  Image as ImageIcon,
  File,
  Trash2,
  Plus,
  Search,
  Filter
} from 'lucide-react';
import { UploadFile } from '@/api/integrations';
import { User } from '@/api/entities';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

// Mock data structure for files (in a real app, this would come from a database)
export default function FileManager({ projectId }) {
  const [files, setFiles] = useState([]);
  const [folders, setFolders] = useState([
    { id: 1, name: 'Documentos del Proyecto', type: 'project_docs' },
    { id: 2, name: 'Entregables', type: 'deliverables' },
    { id: 3, name: 'Recursos Compartidos', type: 'shared_resources' },
    { id: 4, name: 'Comunicaciones', type: 'communications' }
  ]);
  const [selectedFolder, setSelectedFolder] = useState(null);
  const [isUploading, setIsUploading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [user, setUser] = useState(null);
  const fileInputRef = React.useRef(null);

  useEffect(() => {
    getCurrentUser();
    loadFiles();
  }, [projectId]);

  const getCurrentUser = async () => {
    try {
      const currentUser = await User.me();
      setUser(currentUser);
    } catch (error) {
      console.error('Error getting current user:', error);
    }
  };

  const loadFiles = () => {
    // Mock data - en producción esto vendría de la base de datos
    const mockFiles = [
      {
        id: 1,
        name: 'Propuesta_Inicial.pdf',
        type: 'application/pdf',
        size: 2540000,
        folder_id: 1,
        uploaded_by: 'admin',
        uploaded_date: '2024-01-15T10:30:00Z',
        url: 'https://example.com/file1.pdf'
      },
      {
        id: 2,
        name: 'Wireframes_V1.png',
        type: 'image/png',
        size: 1840000,
        folder_id: 2,
        uploaded_by: 'admin',
        uploaded_date: '2024-01-18T14:22:00Z',
        url: 'https://example.com/file2.png'
      },
      {
        id: 3,
        name: 'Manual_Usuario.docx',
        type: 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        size: 956000,
        folder_id: 2,
        uploaded_by: 'client',
        uploaded_date: '2024-01-20T09:15:00Z',
        url: 'https://example.com/file3.docx'
      }
    ];
    setFiles(mockFiles);
  };

  const handleFileUpload = async (event) => {
    const uploadedFiles = Array.from(event.target.files);
    if (uploadedFiles.length === 0) return;

    setIsUploading(true);
    
    try {
      for (const file of uploadedFiles) {
        const { file_url } = await UploadFile({ file });
        
        const newFile = {
          id: Date.now() + Math.random(),
          name: file.name,
          type: file.type,
          size: file.size,
          folder_id: selectedFolder?.id || 3, // Default to shared resources
          uploaded_by: user?.role || 'client',
          uploaded_date: new Date().toISOString(),
          url: file_url
        };
        
        setFiles(prev => [...prev, newFile]);
      }
    } catch (error) {
      console.error('Error uploading files:', error);
      alert('Error subiendo archivos. Por favor intenta de nuevo.');
    }
    
    setIsUploading(false);
    fileInputRef.current.value = '';
  };

  const getFileIcon = (fileType) => {
    if (fileType.startsWith('image/')) return <ImageIcon className="w-5 h-5 text-blue-500" />;
    if (fileType.includes('pdf')) return <FileText className="w-5 h-5 text-red-500" />;
    if (fileType.includes('document') || fileType.includes('word')) return <FileText className="w-5 h-5 text-blue-600" />;
    return <File className="w-5 h-5 text-gray-500" />;
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const filteredFiles = files.filter(file => {
    const matchesSearch = file.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesFolder = !selectedFolder || file.folder_id === selectedFolder.id;
    return matchesSearch && matchesFolder;
  });

  const getFilesByFolder = (folderId) => {
    return files.filter(file => file.folder_id === folderId);
  };

  return (
    <div className="space-y-6">
      {/* File Manager Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle className="flex items-center">
                <FolderOpen className="w-5 h-5 mr-2" />
                Gestor de Archivos
              </CardTitle>
              <p className="text-sm text-gray-600 mt-1">
                Comparte y organiza todos los archivos del proyecto
              </p>
            </div>
            <div className="flex space-x-2">
              <input
                ref={fileInputRef}
                type="file"
                multiple
                onChange={handleFileUpload}
                className="hidden"
                accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.gif,.zip,.rar"
              />
              <Button
                onClick={() => fileInputRef.current?.click()}
                disabled={isUploading}
                className="bg-emerald-600 hover:bg-emerald-700"
              >
                {isUploading ? (
                  <>
                    <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                    Subiendo...
                  </>
                ) : (
                  <>
                    <Upload className="w-4 h-4 mr-2" />
                    Subir Archivo
                  </>
                )}
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Search and Filter */}
          <div className="flex space-x-4 mb-6">
            <div className="flex-1 relative">
              <Search className="w-4 h-4 absolute left-3 top-3 text-gray-400" />
              <Input
                placeholder="Buscar archivos..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button
              variant="outline"
              onClick={() => setSelectedFolder(null)}
              className={!selectedFolder ? 'bg-emerald-50 border-emerald-200' : ''}
            >
              Todos los archivos
            </Button>
          </div>

          {/* Folders Grid */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
            {folders.map((folder) => {
              const folderFileCount = getFilesByFolder(folder.id).length;
              return (
                <Card
                  key={folder.id}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedFolder?.id === folder.id ? 'ring-2 ring-emerald-500 bg-emerald-50' : ''
                  }`}
                  onClick={() => setSelectedFolder(
                    selectedFolder?.id === folder.id ? null : folder
                  )}
                >
                  <CardContent className="p-4 text-center">
                    <FolderOpen className="w-8 h-8 text-emerald-600 mx-auto mb-2" />
                    <h3 className="font-medium text-sm text-gray-800">{folder.name}</h3>
                    <p className="text-xs text-gray-500 mt-1">
                      {folderFileCount} archivo{folderFileCount !== 1 ? 's' : ''}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Files List */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">
            {selectedFolder ? `Archivos en: ${selectedFolder.name}` : 'Todos los archivos'}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {filteredFiles.length === 0 ? (
            <div className="text-center py-8">
              <FolderOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">
                {searchTerm ? 'No se encontraron archivos' : 'No hay archivos en esta carpeta.'}
              </p>
              <p className="text-sm text-gray-400 mt-1">
                {!selectedFolder && 'Sube tu primer archivo para empezar.'}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              {filteredFiles.map((file) => (
                <div
                  key={file.id}
                  className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-center space-x-3">
                    {getFileIcon(file.type)}
                    <div>
                      <p className="font-medium text-gray-800">{file.name}</p>
                      <div className="flex items-center space-x-4 text-sm text-gray-500">
                        <span>{formatFileSize(file.size)}</span>
                        <span>•</span>
                        <span>
                          {format(new Date(file.uploaded_date), "dd/MM/yyyy", { locale: es })}
                        </span>
                        <span>•</span>
                        <Badge variant="outline" className="text-xs">
                          {file.uploaded_by === 'admin' ? 'Equipo' : 'Cliente'}
                        </Badge>
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => window.open(file.url, '_blank')}
                    >
                      <Download className="w-4 h-4" />
                    </Button>
                    {(user?.role === 'admin' || file.uploaded_by === 'client') && (
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => {
                          if (confirm('¿Estás seguro de que quieres eliminar este archivo?')) {
                            setFiles(prev => prev.filter(f => f.id !== file.id));
                          }
                        }}
                        className="text-red-600 hover:text-red-800"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}