import React, { useState, useEffect } from 'react';
import { ProjectMilestone } from '@/api/entities';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Loader, CheckCircle, Clock, Circle } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';

const statusIcons = {
  completed: <CheckCircle className="w-6 h-6 text-green-500" />,
  in_progress: <Clock className="w-6 h-6 text-blue-500 animate-pulse" />,
  pending: <Circle className="w-6 h-6 text-gray-400" />,
  blocked: <Circle className="w-6 h-6 text-red-500" />,
};

const statusText = {
  completed: "Completado",
  in_progress: "En Progreso",
  pending: "Pendiente",
  blocked: "Bloqueado",
}

export default function MilestoneTracker({ projectId }) {
  const [milestones, setMilestones] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchMilestones = async () => {
      if (!projectId) return;
      setIsLoading(true);
      try {
        const data = await ProjectMilestone.filter({ project_id: projectId }, 'order_index');
        setMilestones(data);
      } catch (error) {
        console.error("Error fetching milestones:", error);
      }
      setIsLoading(false);
    };

    fetchMilestones();
  }, [projectId]);

  return (
    <Card className="bg-white rounded-xl shadow-sm">
      <CardHeader>
        <CardTitle className="text-xl font-bold text-gray-800">Hitos del Proyecto</CardTitle>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="flex justify-center items-center py-8">
            <Loader className="w-8 h-8 animate-spin text-emerald-500" />
          </div>
        ) : milestones.length === 0 ? (
          <p className="text-gray-500 text-center py-8">No hay hitos definidos para este proyecto aún.</p>
        ) : (
          <div className="space-y-6">
            {milestones.map((milestone) => (
              <div key={milestone.id} className="flex items-start space-x-4">
                <div className="mt-1">{statusIcons[milestone.status]}</div>
                <div className="flex-1">
                  <div className="flex justify-between items-center">
                    <h3 className="font-semibold text-gray-800">{milestone.milestone_name}</h3>
                    <span className="text-sm text-gray-500">{statusText[milestone.status]}</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">{milestone.description}</p>
                  <p className="text-xs text-gray-400 mt-2">
                    Fecha Límite: {format(new Date(milestone.due_date), 'd MMM, yyyy', { locale: es })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}