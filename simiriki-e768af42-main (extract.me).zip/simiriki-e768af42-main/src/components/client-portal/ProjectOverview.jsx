
import React, { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Calendar,
  DollarSign,
  TrendingUp,
  AlertTriangle,
  CheckCircle,
  Loader, // Added Loader for processing state
} from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { createStripeCheckout } from '@/api/functions'; // Importar función

export default function ProjectOverview({ project }) {
  const [isPaying, setIsPaying] = useState(false); // New state to manage payment processing status

  const {
    project_name,
    status,
    progress_percentage = 0,
    start_date,
    estimated_completion,
    total_value,
    paid_amount = 0,
    service_type,
    next_milestone,
    description,
    client_email
  } = project;

  const pendingAmount = total_value - paid_amount; // Renamed remaining_balance to pendingAmount for clarity
  const payment_percentage = total_value > 0 ? (paid_amount / total_value) * 100 : 0;

  const statusConfig = {
    discovery: { label: "Descubrimiento", color: "bg-blue-100 text-blue-800" },
    planning: { label: "Planificación", color: "bg-yellow-100 text-yellow-800" },
    development: { label: "Desarrollo", color: "bg-purple-100 text-purple-800" },
    testing: { label: "Pruebas", color: "bg-orange-100 text-orange-800" },
    deployment: { label: "Implementación", color: "bg-indigo-100 text-indigo-800" },
    completed: { label: "Completado", color: "bg-green-100 text-green-800" },
    on_hold: { label: "En Pausa", color: "bg-gray-100 text-gray-800" }
  };

  const serviceTypeLabels = {
    automation: "Automatización de Procesos",
    lead_generation: "Generación de Leads",
    ai_implementation: "Implementación de IA",
    digital_transformation: "Transformación Digital",
    custom: "Proyecto Personalizado"
  };

  const currentStatus = statusConfig[project.status] || statusConfig.on_hold;

  const handlePayment = async () => {
    setIsPaying(true);
    try {
      const response = await createStripeCheckout({
        project_id: project.id, // Parameter name updated to project_id as per outline
        amount: pendingAmount, // Using pendingAmount
        project_name: project.project_name, // Parameter name updated to project_name as per outline
        client_email: project.client_email, // Using project.client_email
      });

      if (response.data && response.data.url) { // Check for response.data.url
        window.location.href = response.data.url; // Redirect to Stripe
      } else {
        alert('Error al iniciar el pago. Por favor, contacta a soporte.');
      }
    } catch (error) {
      console.error('Error creating Stripe checkout session:', error);
      alert('Hubo un error al procesar tu solicitud de pago.');
    } finally {
      setIsPaying(false); // Ensure button is re-enabled regardless of outcome
    }
  };

  return (
    <div className="space-y-6">
      {/* Project Header */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl text-gray-800">{project_name}</CardTitle>
              <p className="text-gray-600 mt-2">{serviceTypeLabels[service_type] || service_type}</p>
              {description && (
                <p className="text-gray-500 text-sm mt-2">{description}</p>
              )}
            </div>
            <Badge className={currentStatus?.color}>
              {currentStatus?.label}
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          <div className="grid md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div className="flex items-center text-gray-600">
                <Calendar className="w-4 h-4 mr-2" />
                <span className="text-sm">
                  Inicio: {start_date ? format(new Date(start_date), 'dd/MM/yyyy', { locale: es }) : 'No definido'}
                </span>
              </div>
              {estimated_completion && (
                <div className="flex items-center text-gray-600">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span className="text-sm">
                    Entrega estimada: {format(new Date(estimated_completion), 'dd/MM/yyyy', { locale: es })}
                  </span>
                </div>
              )}
              {next_milestone && (
                <div className="flex items-center text-blue-600">
                  <TrendingUp className="w-4 h-4 mr-2" />
                  <span className="text-sm font-medium">Próximo: {next_milestone}</span>
                </div>
              )}
            </div>
            <div>
              <div className="text-sm text-gray-600 mb-2">Progreso del Proyecto</div>
              <Progress value={progress_percentage} className="h-3 mb-2" />
              <div className="text-right text-sm font-medium text-gray-700">
                {progress_percentage}% completado
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Refactored Payment Status and Action Section */}
      <div className="grid md:grid-cols-2 gap-6"> {/* Introduced a grid for layout */}
        <div className="col-span-1">
          <Card className="glass-effect h-full">
            <CardHeader>
              <CardTitle className="flex items-center">
                <DollarSign className="w-5 h-5 mr-2 text-emerald-400"/>
                Estado Financiero
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Payment Summary */}
              <div className="grid md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="text-sm text-blue-600 font-medium">Valor Total</div>
                  <div className="text-2xl font-bold text-blue-800">
                    ${total_value.toLocaleString()}
                  </div>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="text-sm text-green-600 font-medium">Pagado</div>
                  <div className="text-2xl font-bold text-green-800">
                    ${paid_amount.toLocaleString()}
                  </div>
                </div>
                <div className={`p-4 rounded-lg ${pendingAmount > 0 ? 'bg-orange-50' : 'bg-green-50'}`}>
                  <div className={`text-sm font-medium ${pendingAmount > 0 ? 'text-orange-600' : 'text-green-600'}`}>
                    {pendingAmount > 0 ? 'Saldo Pendiente' : 'Saldo Pagado'}
                  </div>
                  <div className={`text-2xl font-bold ${pendingAmount > 0 ? 'text-orange-800' : 'text-green-800'}`}>
                    ${pendingAmount.toLocaleString()}
                  </div>
                </div>
              </div>

              {/* Payment Progress */}
              <div>
                <div className="flex justify-between text-sm text-gray-600 mb-2">
                  <span>Progreso de Pagos</span>
                  <span>{payment_percentage.toFixed(1)}%</span>
                </div>
                <Progress value={payment_percentage} className="h-3" />
              </div>

              {/* Conditional display based on payment status */}
              {pendingAmount > 0 ? (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <AlertTriangle className="w-5 h-5 text-yellow-600 mr-3" />
                    <div>
                      <h4 className="font-semibold text-yellow-800">Pago Pendiente</h4>
                      <p className="text-yellow-700 text-sm">
                        Falta por pagar ${pendingAmount.toLocaleString()} USD.
                      </p>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="flex items-center">
                    <CheckCircle className="w-5 h-5 text-green-600 mr-2" />
                    <div>
                      <p className="font-medium text-green-800">¡Proyecto Totalmente Pagado!</p>
                      <p className="text-sm text-green-700">Gracias por tu confianza. Continuamos trabajando en tu proyecto.</p>
                    </div>
                  </div>
                </div>
              )}

              {/* Payment button, conditional on pendingAmount and disabled when processing */}
              {pendingAmount > 0 && (
                <Button
                  className="w-full gradient-bg text-white hover:opacity-90"
                  onClick={handlePayment}
                  disabled={isPaying}
                  data-testid="payment-button" // Added for E2E testing
                >
                  {isPaying ? (
                    <><Loader className="w-4 h-4 mr-2 animate-spin"/> Procesando...</>
                  ) : (
                    `Pagar ${new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(pendingAmount)} Pendientes`
                  )}
                </Button>
              )}
            </CardContent>
          </Card>
        </div>
        {/* The second column is left empty as no content was provided in the outline for it. 
            This creates a two-column layout where the right column is empty. 
            Adjust 'md:grid-cols-2' or add content if needed for a different layout. */}
        <div></div> 
      </div>
    </div>
  );
}
