
import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowRight, Zap, Users, Bot, BrainCircuit, CheckCircle, Calendar } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function DiagnosticResult({ score, answers }) {

  let result = {
    title: "",
    description: "",
    scoreCategory: "",
    color: "green",
    recommendations: []
  };

  if (score >= 20) {
    result = {
      title: "Potencial de Transformación Urgente",
      description: "Tu negocio tiene una oportunidad masiva para crecer y ahorrar costos a través de la automatización. Implementar cambios ahora tendrá un impacto inmediato y significativo.",
      scoreCategory: "Alto",
      color: "red",
      recommendations: [
        { icon: Zap, text: "Automatización de Procesos Críticos para reducir el 80% de tareas manuales.", link: createPageUrl("Services") },
        { icon: Users, text: "Implementar un sistema de Generación de Leads Inteligente para no perder ni una oportunidad.", link: createPageUrl("Services") },
        { icon: Calendar, text: "Agendar una consulta estratégica GRATUITA para crear tu roadmap personalizado.", link: createPageUrl("Contact") }
      ]
    };
  } else if (score >= 10) {
    result = {
      title: "Oportunidad de Crecimiento Acelerado",
      description: "Estás en el camino correcto, pero hay áreas clave que, una vez automatizadas, pueden duplicar tu eficiencia y capacidad de ventas. Es el momento perfecto para escalar.",
      scoreCategory: "Medio",
      color: "yellow",
      recommendations: [
        { icon: Bot, text: "Usar IA para Atención al Cliente y calificar leads automáticamente.", link: createPageUrl("Services") },
        { icon: Users, text: "Optimizar tu seguimiento de leads con secuencias de nurturing.", link: createPageUrl("FreeGuide") },
        { icon: Calendar, text: "Agendar una consulta para identificar las automatizaciones de mayor impacto.", link: createPageUrl("Contact") }
      ]
    };
  } else {
    result = {
      title: "Potencial de Optimización Estratégica",
      description: "Tienes una buena base. Ahora, la clave es optimizar procesos específicos para liberar recursos y enfocarte en el crecimiento a largo plazo. Pequeños ajustes traerán grandes resultados.",
      scoreCategory: "Bajo",
      color: "green",
      recommendations: [
        { icon: BrainCircuit, text: "Explorar la Consultoría en Transformación Digital para un crecimiento sostenible.", link: createPageUrl("Services") },
        { icon: Users, text: "Refinar tu proceso de ventas con un CRM mejor integrado.", link: createPageUrl("FreeGuide") },
        { icon: Calendar, text: "Agendar una consulta para afinar tu estrategia de crecimiento.", link: createPageUrl("Contact") }
      ]
    };
  }

  const scoreColorClass = {
    red: "text-red-400",
    yellow: "text-yellow-400",
    green: "text-green-400"
  };

  return (
    <Card className="bg-gradient-to-br from-green-900/20 via-purple-900/20 to-blue-900/20 border-white/10 text-white">
      <CardHeader className="text-center">
        <div className={`w-24 h-24 bg-gradient-to-br from-${result.color}-400 to-${result.color}-600 rounded-full flex flex-col items-center justify-center mx-auto mb-4 border-4 border-slate-800`} data-testid="diagnostic-score">
          <div className="text-3xl font-bold">{score}</div>
          <div className="text-xs">Puntos</div>
        </div>
        <CardTitle className="text-4xl font-bold">Tu Potencial de Automatización es <span className={scoreColorClass[result.color]}>{result.scoreCategory}</span></CardTitle>
        <CardDescription className="text-xl text-gray-300 mt-2">{result.title}</CardDescription>
      </CardHeader>
      <CardContent>
        <p className="text-center text-gray-300 mb-8 max-w-2xl mx-auto">{result.description}</p>
        
        <div className="max-w-md mx-auto bg-white/5 p-6 rounded-2xl border border-white/10">
          <h3 className="text-xl font-semibold text-center mb-4">Pasos Siguientes Recomendados:</h3>
          <ul className="space-y-4">
            {result.recommendations.map((rec, index) => (
              <li key={index}>
                <Link to={rec.link}>
                  <Button variant="outline" className="w-full justify-start h-auto py-3 text-white border-white/20 hover:bg-white/10 hover:border-green-400">
                    <div className="flex items-center">
                      <div className="w-10 h-10 bg-white/10 rounded-lg flex items-center justify-center mr-4">
                        <rec.icon className={`w-5 h-5 text-${result.color}-400`} />
                      </div>
                      <span className="text-left whitespace-normal">{rec.text}</span>
                    </div>
                  </Button>
                </Link>
              </li>
            ))}
          </ul>
        </div>
        
        <div className="text-center mt-12">
          <p className="text-gray-400 mb-2">Un miembro de nuestro equipo te contactará pronto con más detalles.</p>
          <Link to={createPageUrl("Home")}>
            <Button variant="link" className="text-green-400">
              Volver al Inicio
            </Button>
          </Link>
        </div>
      </CardContent>
    </Card>
  );
}
