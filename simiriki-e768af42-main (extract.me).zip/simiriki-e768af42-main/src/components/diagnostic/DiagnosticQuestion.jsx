
import React from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { ArrowRight, Loader, BrainCircuit, Users } from 'lucide-react';

export default function DiagnosticQuestion({
  step,
  questions,
  handleAnswer,
  handleLeadSubmit,
  leadData,
  setLeadData,
  isSubmitting,
}) {
  const currentQuestion = questions[step];
  const progress = (step / questions.length) * 100;

  if (step === questions.length) {
    return (
      <Card className="bg-white/5 backdrop-blur-sm border-white/10 text-white" data-testid="diagnostic-lead-form">
        <CardHeader className="text-center">
          <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-purple-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-white" />
          </div>
          <CardTitle className="text-3xl font-bold">¡Casi listo!</CardTitle>
          <CardDescription className="text-gray-300 text-lg">
            Tu reporte personalizado está siendo generado. Ingresa tus datos para verlo.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleLeadSubmit} className="space-y-4 max-w-sm mx-auto">
            <div>
              <Label htmlFor="name">Nombre</Label>
              <Input
                id="name"
                type="text"
                placeholder="Tu nombre completo"
                value={leadData.name}
                onChange={(e) => setLeadData(prev => ({ ...prev, name: e.target.value }))}
                required
                className="bg-white/10 border-white/20"
                data-testid="diagnostic-form-name"
              />
            </div>
            <div>
              <Label htmlFor="email">Email de la Empresa</Label>
              <Input
                id="email"
                type="email"
                placeholder="tu@empresa.com"
                value={leadData.email}
                onChange={(e) => setLeadData(prev => ({ ...prev, email: e.target.value }))}
                required
                className="bg-white/10 border-white/20"
                data-testid="diagnostic-form-email"
              />
            </div>
            <Button
              type="submit"
              size="lg"
              className="w-full gradient-bg hover:opacity-90"
              disabled={isSubmitting}
              data-testid="diagnostic-form-submit"
            >
              {isSubmitting ? (
                <>
                  <Loader className="w-5 h-5 mr-2 animate-spin" />
                  Analizando...
                </>
              ) : (
                <>
                  <BrainCircuit className="w-5 h-5 mr-2" />
                  Ver mi Diagnóstico
                </>
              )}
            </Button>
          </form>
          <p className="text-xs text-center text-gray-500 mt-4">🔒 Valoramos tu privacidad. No enviaremos spam.</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="bg-white/5 backdrop-blur-sm border-white/10 text-white" data-testid={`diagnostic-question-${step}`}>
      <CardHeader>
        <div className="mb-4">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm font-medium text-green-400">Diagnóstico Inteligente</span>
            <span className="text-sm text-gray-400">Paso {step + 1} de {questions.length}</span>
          </div>
          <div className="w-full bg-gray-700 rounded-full h-2">
            <div
              className="bg-gradient-to-r from-green-400 to-purple-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${progress}%` }}
            ></div>
          </div>
        </div>
        <CardTitle className="text-3xl font-bold">{currentQuestion.question}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {currentQuestion.options.map((option, index) => (
            <Button
              key={index}
              variant="outline"
              size="lg"
              className="h-auto py-4 text-left justify-start whitespace-normal text-white border-white/20 hover:bg-white/10 hover:border-green-400"
              onClick={() => handleAnswer(option, currentQuestion.property)}
              data-testid={`question-option-${index}`}
            >
              <span className="text-lg">{option.text}</span>
            </Button>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}
