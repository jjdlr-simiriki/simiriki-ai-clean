import React from "react";
import { CheckCircle, Download, Star, Clock } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function GuidePreview() {
  return (
    <Card className="bg-gradient-to-br from-green-500/10 to-purple-500/10 border border-white/10 overflow-hidden">
      <CardHeader className="text-center">
        <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-purple-400 rounded-full flex items-center justify-center mx-auto mb-4">
          <Download className="w-10 h-10 text-white" />
        </div>
        <CardTitle className="text-3xl font-bold text-white mb-2">
          La Guía Definitiva de Automatización para PYMEs
        </CardTitle>
        <p className="text-lg text-green-400 font-semibold">
          5 Pasos para Automatizar tu Negocio y Aumentar Ventas 300%
        </p>
      </CardHeader>
      
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between text-sm text-gray-300">
          <div className="flex items-center space-x-2">
            <Clock className="w-4 h-4" />
            <span>15 min de lectura</span>
          </div>
          <div className="flex items-center space-x-2">
            <Star className="w-4 h-4 text-yellow-400" />
            <span>4.9/5 (5,000+ descargas)</span>
          </div>
        </div>
        
        <div className="space-y-4">
          <h3 className="text-xl font-semibold text-white mb-4">🎯 Lo que aprenderás:</h3>
          <div className="space-y-3">
            {[
              {
                title: "Auditoría de Procesos",
                desc: "Identifica exactamente qué procesos automatizar primero para obtener el mayor ROI"
              },
              {
                title: "Mapa de Automatización",
                desc: "Diseña tu flujo de trabajo personalizado paso a paso, sin complicaciones técnicas"
              },
              {
                title: "Herramientas Esenciales",
                desc: "Las 10 mejores herramientas para PYMEs (incluye comparativa de precios y funciones)"
              },
              {
                title: "Implementación Rápida",
                desc: "Configura tu primer workflow automático en menos de 24 horas"
              },
              {
                title: "KPIs y Métricas",
                desc: "Cómo medir el éxito de tu automatización y optimizar continuamente"
              }
            ].map((item, index) => (
              <div key={index} className="flex items-start space-x-3">
                <CheckCircle className="w-5 h-5 text-green-400 mt-1 flex-shrink-0" />
                <div>
                  <div className="text-white font-medium">{item.title}</div>
                  <div className="text-gray-300 text-sm">{item.desc}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
        
        <div className="bg-white/5 rounded-lg p-4 border border-white/10">
          <h4 className="text-purple-300 font-semibold mb-2">🎁 Bonus Incluidos:</h4>
          <ul className="text-sm text-gray-300 space-y-1">
            <li>• Checklist de implementación imprimible</li>
            <li>• Templates de emails automáticos</li>
            <li>• Calculadora de ROI en Excel</li>
            <li>• Lista de proveedores recomendados</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}