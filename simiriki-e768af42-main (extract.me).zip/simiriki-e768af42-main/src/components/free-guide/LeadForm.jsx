
import React from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CardHeader, CardTitle } from "@/components/ui/card";
import { Download, Shield, Clock } from "lucide-react";

export default function LeadForm({ onFormSubmit, setLeadData, leadData, isSubmitting }) {
  const handleSubmit = async (e) => {
    e.preventDefault();
    
    onFormSubmit(leadData);
  };

  const handleChange = (e) => {
    const { id, value } = e.target;
    setLeadData(prev => ({ ...prev, [id]: value }));
  };

  return (
    <div className="w-full max-w-lg mx-auto">
      <CardHeader className="text-center">
        <CardTitle className="text-2xl font-bold text-white">
          Descarga tu Guía Gratuita
        </CardTitle>
        <p className="text-gray-300">
          Completa el formulario y recibe la guía en tu email en menos de 2 minutos.
        </p>
      </CardHeader>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        {/* Basic Info */}
        <div>
          <Label htmlFor="name" className="text-white">Nombre Completo</Label>
          <Input
            id="name"
            type="text"
            placeholder="Ej. María Rodríguez"
            value={leadData.name}
            onChange={handleChange}
            required
            className="bg-white/10 border-white/20"
            data-testid="lead-form-name"
          />
        </div>
        <div>
          <Label htmlFor="email" className="text-white">Email de la Empresa</Label>
          <Input
            id="email"
            type="email"
            placeholder="tu@empresa.com"
            value={leadData.email}
            onChange={handleChange}
            required
            className="bg-white/10 border-white/20"
            data-testid="lead-form-email"
          />
        </div>

        <Button
          type="submit"
          size="lg"
          className="w-full gradient-bg hover:opacity-90"
          disabled={isSubmitting}
          data-testid="lead-form-submit"
        >
          {isSubmitting ? (
            <>
              <Clock className="w-5 h-5 mr-2 animate-spin" />
              Enviando...
            </>
          ) : (
            <>
              <Download className="w-5 h-5 mr-2" />
              Descargar Guía Ahora
            </>
          )}
        </Button>
      </form>

      <div className="text-center space-y-2 mt-4"> {/* Added mt-4 for spacing since form closes before this div */}
        <div className="flex items-center justify-center space-x-2 text-sm text-gray-400">
          <Shield className="w-4 h-4" />
          <span>Información 100% segura y confidencial</span>
        </div>
        <p className="text-xs text-gray-500">
          Al descargar la guía, aceptas recibir emails con contenido valioso sobre automatización. 
          Puedes cancelar tu suscripción en cualquier momento.
        </p>
      </div>
    </div>
  );
}
