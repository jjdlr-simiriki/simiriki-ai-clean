import React, { useEffect } from 'react';

const MultiStepGuideForm = ({ onFormSubmit }) => {
  useEffect(() => {
    // Cargar el script de Tally si no está ya presente
    if (!document.querySelector('script[src="https://tally.so/widgets/embed.js"]')) {
      const script = document.createElement('script');
      script.src = 'https://tally.so/widgets/embed.js';
      script.async = true;
      script.onload = () => {
        // Inicializar Tally cuando el script se carga
        if (window.Tally) {
          window.Tally.loadEmbeds();
        }
      };
      document.body.appendChild(script);

      // Cleanup function mejorada
      return () => {
        const existingScript = document.querySelector('script[src="https://tally.so/widgets/embed.js"]');
        if (existingScript) {
          document.body.removeChild(existingScript);
        }
      };
    }

    // Listener para detectar cuando se completa el formulario
    const handleTallySubmit = (event) => {
      if (event.data && event.data.type === 'TALLY_FORM_SUBMIT') {
        // Llamar al callback si se proporciona
        if (onFormSubmit) {
          onFormSubmit();
        }
      }
    };

    // Escuchar mensajes del iframe de Tally
    window.addEventListener('message', handleTallySubmit);
    
    return () => {
      window.removeEventListener('message', handleTallySubmit);
    };
  }, [onFormSubmit]);

  return (
    <div className="bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl overflow-hidden">
      <iframe
        data-tally-src="https://tally.simiriki.com/guia?alignLeft=1&hideTitle=1&transparentBackground=1&dynamicHeight=1"
        loading="lazy"
        width="100%"
        height="500"
        frameBorder="0"
        marginHeight="0"
        marginWidth="0"
        title="Simiriki Lead Form"
        style={{
          width: '100%',
          minHeight: '500px',
          border: 'none',
          colorScheme: 'dark'
        }}
      />
    </div>
  );
};

export default MultiStepGuideForm;