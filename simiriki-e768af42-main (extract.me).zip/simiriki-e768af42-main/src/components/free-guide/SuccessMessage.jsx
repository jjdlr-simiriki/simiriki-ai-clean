import React from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { CheckCircle, Calendar, ArrowRight, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

export default function SuccessMessage() {
  return (
    <div className="min-h-screen py-12 flex items-center justify-center">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        <Card className="bg-gradient-to-br from-green-500/10 to-purple-500/10 border border-green-400/30 text-center">
          <CardHeader>
            <div className="w-24 h-24 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-6">
              <CheckCircle className="w-12 h-12 text-white" />
            </div>
            <CardTitle className="text-3xl font-bold text-white mb-2">
              ¡Perfecto! Tu Guía Está en Camino 🚀
            </CardTitle>
            <p className="text-xl text-green-400 font-semibold">
              Revisa tu email en los próximos 2 minutos
            </p>
          </CardHeader>
          
          <CardContent className="space-y-8">
            <div className="bg-white/5 rounded-lg p-6 border border-white/10">
              <h3 className="text-lg font-semibold text-white mb-4">📧 ¿Qué sigue ahora?</h3>
              <div className="space-y-3 text-left">
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-green-400 text-black rounded-full flex items-center justify-center text-sm font-bold mt-1">1</div>
                  <div>
                    <div className="text-white font-medium">Revisa tu email</div>
                    <div className="text-gray-300 text-sm">Te enviamos el link de descarga directa (puede llegar a spam)</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-purple-400 text-black rounded-full flex items-center justify-center text-sm font-bold mt-1">2</div>
                  <div>
                    <div className="text-white font-medium">Descarga y lee la guía</div>
                    <div className="text-gray-300 text-sm">Solo 15 minutos que pueden cambiar tu negocio para siempre</div>
                  </div>
                </div>
                <div className="flex items-start space-x-3">
                  <div className="w-6 h-6 bg-blue-400 text-black rounded-full flex items-center justify-center text-sm font-bold mt-1">3</div>
                  <div>
                    <div className="text-white font-medium">Implementa el primer paso</div>
                    <div className="text-gray-300 text-sm">Empieza con la auditoría de procesos (página 3)</div>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="bg-gradient-to-r from-purple-500/10 to-blue-500/10 rounded-lg p-6 border border-purple-400/20">
              <h3 className="text-white font-semibold mb-3">🚀 ¿Quieres acelerar el proceso?</h3>
              <p className="text-gray-300 mb-4 text-sm">
                Implementar la guía por tu cuenta puede tomar semanas. En una consulta de 30 minutos, 
                puedo ayudarte a diseñar un plan específico para tu empresa y acelerar los resultados.
              </p>
              <a href="https://meetings.hubspot.com/jjdlr/simiriki-consulta" target="_blank" rel="noopener noreferrer">
                <Button className="gradient-bg text-white hover:opacity-90 w-full">
                  <Calendar className="w-5 h-5 mr-2" />
                  Agendar Consulta Gratuita (30 min)
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Button>
              </a>
            </div>
            
            <div className="space-y-4">
              <h3 className="text-white font-semibold">Mientras tanto, puedes:</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <Link to={createPageUrl("Services")}>
                  <Button variant="outline" className="w-full text-purple-300 border-purple-400/80 hover:bg-purple-500/20">
                    Ver Nuestros Servicios
                  </Button>
                </Link>
                <Link to={createPageUrl("CaseStudies")}>
                  <Button variant="outline" className="w-full text-green-300 border-green-400/80 hover:bg-green-500/20">
                    Casos de Éxito
                  </Button>
                </Link>
              </div>
            </div>
            
            <div className="text-center pt-6 border-t border-white/10">
              <p className="text-gray-400 text-sm">
                ¿No recibiste el email? Revisa tu carpeta de spam o <br />
                escríbenos a <a href="mailto:jjdlr@simiriki.com" className="text-green-400 hover:text-green-300">jjdlr@simiriki.com</a>
              </p>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}