import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Loader, CheckCircle } from 'lucide-react';
import { syncToHubspot } from '@/api/functions';

export default function LeadForm({ formSource, onSuccess }) {
  const [formData, setFormData] = useState({ name: '', email: '', company: '' });
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  const [error, setError] = useState('');

  const handleChange = (e) => {
    const { id, value } = e.target;
    setFormData(prev => ({ ...prev, [id]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setError('');

    try {
      await syncToHubspot({
        leadData: {
          email: formData.email,
          name: formData.name,
          company: formData.company,
          source: formSource,
        },
        eventType: 'generic_form_submission'
      });
      setIsSuccess(true);
      if (onSuccess) onSuccess();
    } catch (err) {
      console.error("Form submission error:", err);
      setError("Hubo un error al enviar. Inténtalo de nuevo.");
    } finally {
      setIsLoading(false);
    }
  };

  if (isSuccess) {
    return (
      <div className="text-center py-6 text-white">
        <CheckCircle className="w-12 h-12 text-green-400 mx-auto mb-4" />
        <h3 className="text-xl font-semibold">¡Gracias!</h3>
        <p className="text-gray-300">Hemos recibido tu información. Nos pondremos en contacto pronto.</p>
      </div>
    );
  }

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <Label htmlFor="name" className="text-white">Nombre Completo</Label>
        <Input id="name" type="text" value={formData.name} onChange={handleChange} required className="bg-white/10 border-white/20 text-white placeholder:text-gray-400" placeholder="Ej. María López" />
      </div>
      <div>
        <Label htmlFor="email" className="text-white">Email</Label>
        <Input id="email" type="email" value={formData.email} onChange={handleChange} required className="bg-white/10 border-white/20 text-white placeholder:text-gray-400" placeholder="tu@empresa.com" />
      </div>
      <div>
        <Label htmlFor="company" className="text-white">Empresa (Opcional)</Label>
        <Input id="company" type="text" value={formData.company} onChange={handleChange} className="bg-white/10 border-white/20 text-white placeholder:text-gray-400" placeholder="Tu Empresa S.A. de C.V." />
      </div>
      <Button type="submit" disabled={isLoading} className="w-full gradient-bg hover:opacity-90">
        {isLoading ? <Loader className="animate-spin w-5 h-5 mx-auto" /> : 'Enviar Mensaje'}
      </Button>
      {error && <p className="text-red-400 text-sm text-center">{error}</p>}
    </form>
  );
}