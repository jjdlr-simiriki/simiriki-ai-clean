import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { MessageSquare } from 'lucide-react';
import AIAssistant from '@/components/ai/AIAssistant';

/**
 * FloatingChatWidget - EL ÚNICO CHAT WIDGET DE LA APLICACIÓN
 * Este componente es el ÚNICO punto de entrada para el chat.
 */
export default function FloatingChatWidget() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    // Asegurar que no hay otros chats de HubSpot o terceros
    const removeOtherChats = () => {
      // Remover cualquier chat de HubSpot si existe
      const hubspotWidgets = document.querySelectorAll('[id*="hubspot"], [class*="hubspot"], [id*="hs-"], [class*="hs-"]');
      hubspotWidgets.forEach(widget => {
        if (widget.style && (widget.style.position === 'fixed' || widget.style.zIndex > 1000)) {
          widget.style.display = 'none';
        }
      });

      // Remover otros posibles chats flotantes
      const floatingElements = document.querySelectorAll('[style*="position: fixed"][style*="bottom"]');
      floatingElements.forEach(el => {
        if (el !== document.querySelector('[data-testid="chat-widget-button"]') && 
            el.textContent && el.textContent.includes('chat')) {
          el.style.display = 'none';
        }
      });
    };

    removeOtherChats();
    
    // Revisar cada 2 segundos por si aparecen chats nuevos
    const interval = setInterval(removeOtherChats, 2000);
    
    return () => clearInterval(interval);
  }, []);

  return (
    <>
      {/* EL ÚNICO BOTÓN DE CHAT */}
      <Button
        className="fixed bottom-6 right-6 z-[9999] w-16 h-16 rounded-full bg-gradient-to-br from-purple-600 to-blue-600 text-white shadow-2xl hover:scale-110 transition-transform duration-200"
        onClick={() => setIsOpen(true)}
        aria-label="Abrir chat de ayuda"
        data-testid="chat-widget-button"
      >
        <MessageSquare className="w-8 h-8" />
      </Button>

      {/* Modal de chat */}
      <AIAssistant isOpen={isOpen} onClose={() => setIsOpen(false)} />
    </>
  );
}