import React, { useState, useRef, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Send, Loader, User, Bot } from 'lucide-react';
import { simirikiChat } from '@/api/functions';
import { leadCreateFromChat } from '@/api/functions';

export default function SimirikiChatWidget() {
  const [messages, setMessages] = useState([
    {
      role: 'assistant',
      content: '¡Hola! Soy el asistente de IA de Simiriki. Cuéntame sobre tu negocio y te ayudo a encontrar oportunidades de automatización. ¿En qué industria trabajas?',
      timestamp: new Date()
    }
  ]);
  const [currentMessage, setCurrentMessage] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const analyzeForQualifiedLead = (message, conversation) => {
    const qualifyingIndicators = [
      'mi empresa', 'mi negocio', 'soy dueño', 'tengo una', 'trabajo en',
      'mi email', 'mi teléfono', 'contacto', 'consulta', 'cotización', 'precio',
      'empleados', 'equipo', 'automatizar', 'procesos', 'reportes'
    ];

    const messageText = message.toLowerCase();
    const conversationText = conversation.map(msg => msg.content).join(' ').toLowerCase();

    return qualifyingIndicators.some(indicator => 
      messageText.includes(indicator) || conversationText.includes(indicator)
    );
  };

  const extractLeadData = (message, conversation) => {
    const allText = [message, ...conversation.map(msg => msg.content)].join(' ');
    
    // Basic email extraction
    const emailMatch = allText.match(/[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/);
    
    // Basic phone extraction (Mexican format)
    const phoneMatch = allText.match(/(\+52\s?)?[\d\s\-()]{10,}/);
    
    return {
      email: emailMatch ? emailMatch[0] : null,
      phone: phoneMatch ? phoneMatch[0] : null,
      source: 'chat_assistant',
      conversation_summary: conversation.slice(-5).map(msg => `${msg.role}: ${msg.content}`).join('\n'),
      qualification_score: 'medium' // Based on chat engagement
    };
  };

  const sendMessage = async () => {
    if (!currentMessage.trim() || isLoading) return;

    const userMessage = {
      role: 'user',
      content: currentMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    const messageToSend = currentMessage;
    setCurrentMessage('');
    setIsLoading(true);

    try {
      // Call our backend function
      const { data } = await simirikiChat({
        message: messageToSend,
        conversation: messages
      });

      const aiMessage = {
        role: 'assistant',
        content: data.message,
        timestamp: new Date()
      };

      setMessages(prev => [...prev, aiMessage]);

      // Check if this is a qualified lead
      const isQualifiedLead = analyzeForQualifiedLead(messageToSend, messages);
      
      if (isQualifiedLead && messages.length >= 3) { // Wait for some conversation depth
        const leadData = extractLeadData(messageToSend, messages);
        
        try {
          await leadCreateFromChat({ leadData });
          console.log('Qualified lead captured from chat:', leadData);
        } catch (error) {
          console.error('Error creating lead from chat:', error);
        }
      }

    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage = {
        role: 'assistant',
        content: 'Lo siento, tuve un problema técnico. ¿Podrías contactarnos directamente al +52 813 467 5514?',
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }

    setIsLoading(false);
  };

  const handleKeyPress = (e) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (date) => {
    return date.toLocaleTimeString('es-MX', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  return (
    <div className="flex flex-col h-full bg-transparent">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-4 max-h-80">
        {messages.map((msg, index) => (
          <div key={index} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
            <div className={`flex items-start space-x-2 max-w-xs lg:max-w-md ${msg.role === 'user' ? 'flex-row-reverse space-x-reverse' : ''}`}>
              <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                msg.role === 'user' 
                  ? 'bg-emerald-500' 
                  : 'bg-purple-500'
              }`}>
                {msg.role === 'user' ? 
                  <User className="w-4 h-4 text-white" /> : 
                  <Bot className="w-4 h-4 text-white" />
                }
              </div>
              <div className={`rounded-lg p-3 ${
                msg.role === 'user'
                  ? 'bg-emerald-500 text-white'
                  : 'bg-white/10 text-gray-100'
              }`}>
                <p className="text-sm whitespace-pre-wrap">{msg.content}</p>
                <p className="text-xs opacity-70 mt-1">{formatTime(msg.timestamp)}</p>
              </div>
            </div>
          </div>
        ))}
        
        {isLoading && (
          <div className="flex justify-start">
            <div className="flex items-start space-x-2">
              <div className="w-8 h-8 rounded-full bg-purple-500 flex items-center justify-center">
                <Bot className="w-4 h-4 text-white" />
              </div>
              <div className="bg-white/10 rounded-lg p-3">
                <Loader className="w-4 h-4 animate-spin text-gray-300" />
              </div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input */}
      <div className="p-4 border-t border-white/10">
        <div className="flex space-x-2">
          <Input
            value={currentMessage}
            onChange={(e) => setCurrentMessage(e.target.value)}
            onKeyPress={handleKeyPress}
            placeholder="Escribe tu mensaje..."
            className="flex-1 bg-white/5 border-white/20 text-white placeholder-gray-400"
            disabled={isLoading}
          />
          <Button 
            onClick={sendMessage}
            disabled={isLoading || !currentMessage.trim()}
            className="bg-emerald-500 hover:bg-emerald-600"
          >
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}