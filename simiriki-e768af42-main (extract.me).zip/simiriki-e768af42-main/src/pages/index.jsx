import Layout from "./Layout.jsx";

import Home from "./Home";

import FreeGuide from "./FreeGuide";

import Services from "./Services";

import About from "./About";

import Blog from "./Blog";

import BlogPost from "./BlogPost";

import Contact from "./Contact";

import Testimonials from "./Testimonials";

import DiagnosticTool from "./DiagnosticTool";

import CaseStudies from "./CaseStudies";

import Pricing from "./Pricing";

import AdminDashboard from "./AdminDashboard";

import Status from "./Status";

import ROICalculator from "./ROICalculator";

import FAQ from "./FAQ";

import SimirikiChatAssistant from "./SimirikiChatAssistant";

import ClientPortal from "./ClientPortal";

import { BrowserRouter as Router, Route, Routes, useLocation } from 'react-router-dom';

const PAGES = {
    
    Home: Home,
    
    FreeGuide: FreeGuide,
    
    Services: Services,
    
    About: About,
    
    Blog: Blog,
    
    BlogPost: BlogPost,
    
    Contact: Contact,
    
    Testimonials: Testimonials,
    
    DiagnosticTool: DiagnosticTool,
    
    CaseStudies: CaseStudies,
    
    Pricing: Pricing,
    
    AdminDashboard: AdminDashboard,
    
    Status: Status,
    
    ROICalculator: ROICalculator,
    
    FAQ: FAQ,
    
    SimirikiChatAssistant: SimirikiChatAssistant,
    
    ClientPortal: ClientPortal,
    
}

function _getCurrentPage(url) {
    if (url.endsWith('/')) {
        url = url.slice(0, -1);
    }
    let urlLastPart = url.split('/').pop();
    if (urlLastPart.includes('?')) {
        urlLastPart = urlLastPart.split('?')[0];
    }

    const pageName = Object.keys(PAGES).find(page => page.toLowerCase() === urlLastPart.toLowerCase());
    return pageName || Object.keys(PAGES)[0];
}

// Create a wrapper component that uses useLocation inside the Router context
function PagesContent() {
    const location = useLocation();
    const currentPage = _getCurrentPage(location.pathname);
    
    return (
        <Layout currentPageName={currentPage}>
            <Routes>            
                
                    <Route path="/" element={<Home />} />
                
                
                <Route path="/Home" element={<Home />} />
                
                <Route path="/FreeGuide" element={<FreeGuide />} />
                
                <Route path="/Services" element={<Services />} />
                
                <Route path="/About" element={<About />} />
                
                <Route path="/Blog" element={<Blog />} />
                
                <Route path="/BlogPost" element={<BlogPost />} />
                
                <Route path="/Contact" element={<Contact />} />
                
                <Route path="/Testimonials" element={<Testimonials />} />
                
                <Route path="/DiagnosticTool" element={<DiagnosticTool />} />
                
                <Route path="/CaseStudies" element={<CaseStudies />} />
                
                <Route path="/Pricing" element={<Pricing />} />
                
                <Route path="/AdminDashboard" element={<AdminDashboard />} />
                
                <Route path="/Status" element={<Status />} />
                
                <Route path="/ROICalculator" element={<ROICalculator />} />
                
                <Route path="/FAQ" element={<FAQ />} />
                
                <Route path="/SimirikiChatAssistant" element={<SimirikiChatAssistant />} />
                
                <Route path="/ClientPortal" element={<ClientPortal />} />
                
            </Routes>
        </Layout>
    );
}

export default function Pages() {
    return (
        <Router>
            <PagesContent />
        </Router>
    );
}