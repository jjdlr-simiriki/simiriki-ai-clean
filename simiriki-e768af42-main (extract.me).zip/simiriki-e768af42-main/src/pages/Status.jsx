import React from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, Zap, Clock, Users, Cpu, Milestone, Flag, GitCommit, Bot, Shield, BarChart2, Smartphone, Code2 } from 'lucide-react';

const projectStatus = {
  projectName: "ChatCPT - AI Assistant Project",
  overallProgress: 68,
  keyMetrics: [
    { title: "Modules Completed", value: "5/8", icon: CheckCircle, color: "text-emerald-400" },
    { title: "Active Tasks", value: "3", icon: Zap, color: "text-yellow-400" },
    { title: "Team Members", value: "12", icon: Users, color: "text-blue-400" },
    { title: "Next Milestone", value: "CRM Sync", icon: Milestone, color: "text-purple-400" }
  ],
  components: [
    { id: 1, name: "Core Language Model Integration", owner: "AI Team", progress: 100, status: "Completed", icon: Bot, notes: "GPT-4o Mini integrated and optimized." },
    { id: 2, name: "User Authentication & Security", owner: "Backend Team", progress: 100, status: "Completed", icon: Shield, notes: "OAuth 2.0 and JWT implemented." },
    { id: 3, name: "Real-time Chat Interface", owner: "Frontend Team", progress: 90, status: "In Progress", icon: Cpu, notes: "Implementing final UI tweaks based on feedback." },
    { id: 4, name: "Conversation History & Storage", owner: "Backend Team", progress: 85, status: "In Progress", icon: GitCommit, notes: "Database schema optimized for fast retrieval." },
    { id: 5, name: "HubSpot CRM Synchronization", owner: "Integrations Team", progress: 60, status: "In Progress", icon: Zap, notes: "Working on custom object mapping." },
    { id: 6, name: "Admin Dashboard & Analytics", owner: "Frontend Team", progress: 40, status: "Blocked", icon: BarChart2, notes: "Waiting for data structure from Backend Team." },
    { id: 7, name: "Mobile App (iOS & Android)", owner: "Mobile Team", progress: 15, status: "Planned", icon: Smartphone, notes: "Initial wireframes approved. Awaiting backend APIs." },
    { id: 8, name: "Public API & Webhooks", owner: "Backend Team", progress: 0, status: "Planned", icon: Code2, notes: "API specification in review." }
  ],
  timeline: [
    { date: "2024-05-01", event: "Project Kick-off", status: "completed" },
    { date: "2024-06-15", event: "Core Model Integration Complete", status: "completed" },
    { date: "2024-07-20", event: "Internal Alpha Release", status: "completed" },
    { date: "2024-08-10", event: "Real-time Chat UI Complete", status: "active" },
    { date: "2024-09-01", event: "Public Beta Launch", status: "upcoming" },
    { date: "2024-10-15", event: "Mobile App Development Start", status: "upcoming" },
  ]
};

const getStatusBadge = (status) => {
  switch (status) {
    case 'Completed':
      return 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30';
    case 'In Progress':
      return 'bg-blue-500/20 text-blue-400 border-blue-500/30';
    case 'Blocked':
      return 'bg-red-500/20 text-red-400 border-red-500/30';
    case 'Planned':
      return 'bg-gray-500/20 text-gray-400 border-gray-500/30';
    default:
      return 'bg-gray-700 text-gray-300';
  }
};

const getTimelineStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-emerald-400" />;
      case 'active':
        return <Zap className="w-5 h-5 text-yellow-400 animate-pulse" />;
      case 'upcoming':
        return <Clock className="w-5 h-5 text-gray-400" />;
      default:
        return null;
    }
};

export default function StatusPage() {
  return (
    <div className="py-12 px-4 sm:px-6 lg:px-8 text-white">
      <div className="max-w-7xl mx-auto">
        <header className="mb-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold mb-2">
            Status Report: <span className="gradient-text">{projectStatus.projectName}</span>
          </h1>
          <p className="text-gray-400">
            Live project tracker. Last updated: {new Date().toLocaleString('es-MX')}
          </p>
        </header>

        {/* Overall Progress & Key Metrics */}
        <Card className="bg-white/5 border-white/10 mb-8">
            <CardHeader>
                <CardTitle className="text-xl">Overall Progress</CardTitle>
            </CardHeader>
            <CardContent>
                <div className="flex items-center gap-4">
                    <Progress value={projectStatus.overallProgress} className="w-full h-4" />
                    <span className="text-2xl font-bold text-emerald-400">{projectStatus.overallProgress}%</span>
                </div>
            </CardContent>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            {projectStatus.keyMetrics.map(metric => (
                <Card key={metric.title} className="bg-white/5 border-white/10">
                    <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                    <CardTitle className="text-sm font-medium text-gray-300">{metric.title}</CardTitle>
                    <metric.icon className={`h-4 w-4 ${metric.color}`} />
                    </CardHeader>
                    <CardContent>
                    <div className="text-2xl font-bold">{metric.value}</div>
                    </CardContent>
                </Card>
            ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
            {/* Component Status */}
            <div className="lg:col-span-2">
                <Card className="bg-white/5 border-white/10 h-full">
                    <CardHeader>
                        <CardTitle>Component Status Breakdown</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <Table>
                            <TableHeader>
                                <TableRow className="border-white/10">
                                <TableHead className="text-white">Component</TableHead>
                                <TableHead className="text-white">Owner</TableHead>
                                <TableHead className="text-white">Status</TableHead>
                                <TableHead className="text-white">Progress</TableHead>
                                </TableRow>
                            </TableHeader>
                            <TableBody>
                                {projectStatus.components.map(component => (
                                <TableRow key={component.id} className="border-white/10">
                                    <TableCell>
                                        <div className="flex items-center gap-3">
                                            <component.icon className="w-5 h-5 text-gray-400 flex-shrink-0"/>
                                            <div>
                                                <div className="font-medium text-gray-200">{component.name}</div>
                                                <div className="text-xs text-gray-500">{component.notes}</div>
                                            </div>
                                        </div>
                                    </TableCell>
                                    <TableCell className="text-gray-400">{component.owner}</TableCell>
                                    <TableCell>
                                        <Badge className={`text-xs border ${getStatusBadge(component.status)}`}>{component.status}</Badge>
                                    </TableCell>
                                    <TableCell>
                                        <div className="flex items-center gap-2">
                                            <Progress value={component.progress} className="w-16 h-2" />
                                            <span className="text-xs text-gray-400">{component.progress}%</span>
                                        </div>
                                    </TableCell>
                                </TableRow>
                                ))}
                            </TableBody>
                        </Table>
                    </CardContent>
                </Card>
            </div>

            {/* Timeline */}
            <div className="lg:col-span-1">
                <Card className="bg-white/5 border-white/10 h-full">
                    <CardHeader>
                        <CardTitle>Project Timeline & Milestones</CardTitle>
                    </CardHeader>
                    <CardContent>
                        <div className="space-y-6">
                        {projectStatus.timeline.map((item, index) => (
                            <div key={index} className="flex items-start gap-4">
                                <div>{getTimelineStatusIcon(item.status)}</div>
                                <div className="flex-1">
                                    <p className={`font-medium ${item.status === 'active' ? 'text-yellow-400' : 'text-gray-200'}`}>{item.event}</p>
                                    <p className="text-sm text-gray-400">{item.date}</p>
                                </div>
                            </div>
                        ))}
                        </div>
                    </CardContent>
                </Card>
            </div>
        </div>
      </div>
    </div>
  );
}