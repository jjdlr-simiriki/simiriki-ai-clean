
import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Star, Users, TrendingUp, Clock, Download, CheckCircle } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";

import GuidePreview from "../components/free-guide/GuidePreview";
import HubSpotMeeting from "../components/hubspot/HubSpotMeeting";
import MultiStepGuideForm from "../components/free-guide/MultiStepGuideForm"; // Importar el nuevo componente

// HubSpot configuration with actual Portal ID
const MEETING_URL = "https://meetings.hubspot.com/jjdlr/simiriki-consulta";

export default function FreeGuide() {
  const [showMeetingWidget, setShowMeetingWidget] = useState(false);
  const [formSubmitted, setFormSubmitted] = useState(false);

  return (
    <div className="min-h-screen py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left Column - Guide Preview */}
          <div className="space-y-8">
            <GuidePreview />
            
            {/* Social Proof */}
            <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-white">Lo que dicen quienes la descargaron:</h3>
                <div className="flex items-center space-x-1">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 text-yellow-400 fill-yellow-400" />
                  ))}
                  <span className="text-sm text-gray-300 ml-2">4.9/5</span>
                </div>
              </div>
              
              <div className="space-y-4">
                <div className="border-l-4 border-green-400 pl-4">
                  <p className="text-gray-300 italic">"Implementé solo 2 de las estrategias y ya aumenté mis leads en 150%. ¡Increíble!"</p>
                  <div className="text-sm text-green-400 mt-1">- María López, CEO de TechPro</div>
                </div>
                <div className="border-l-4 border-purple-400 pl-4">
                  <p className="text-gray-300 italic">"La guía es súper práctica. En 2 semanas automaticé mi seguimiento de clientes."</p>
                  <div className="text-sm text-purple-400 mt-1">- Carlos Mendoza, Director de Marketing</div>
                </div>
              </div>
            </div>
            
            {/* Stats */}
            <div className="grid grid-cols-3 gap-4">
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Users className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white">5,000+</div>
                <div className="text-sm text-gray-400">Descargas</div>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center mx-auto mb-2">
                  <TrendingUp className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white">300%</div>
                <div className="text-sm text-gray-400">Aumento Promedio</div>
              </div>
              <div className="text-center">
                <div className="w-12 h-12 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center mx-auto mb-2">
                  <Clock className="w-6 h-6 text-white" />
                </div>
                <div className="text-2xl font-bold text-white">15 min</div>
                <div className="text-sm text-gray-400">Tiempo de lectura</div>
              </div>
            </div>
          </div>
          
          {/* Right Column - HubSpot Form */}
          <div className="lg:sticky lg:top-8 space-y-8">
            <MultiStepGuideForm onFormSubmit={() => setFormSubmitted(true)} />
            
            {/* Meeting CTA */}
            {(formSubmitted || showMeetingWidget) && (
              <Card className="bg-gradient-to-br from-purple-500/10 to-blue-500/10 border-purple-400/20">
                <CardHeader className="text-center">
                  <CardTitle className="text-xl text-white">¿Quieres acelerar el proceso?</CardTitle>
                  <p className="text-gray-300 text-sm">
                    Agenda una consulta de 30 minutos y te ayudamos a diseñar un plan específico para tu empresa.
                  </p>
                </CardHeader>
                <CardContent>
                  {!showMeetingWidget ? (
                    <Button 
                      onClick={() => setShowMeetingWidget(true)}
                      className="w-full gradient-bg text-white hover:opacity-90"
                    >
                      Agendar Consulta Gratuita (30 min)
                    </Button>
                  ) : (
                    <HubSpotMeeting meetingUrl={MEETING_URL} height="500px" />
                  )}
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
