

import React, { useEffect, useState } from "react";
import { Link, useLocation } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Menu, X, Globe, Zap, Users, BookOpen, MessageSquare, Calendar, Shield, TrendingUp, Calculator, Phone, ExternalLink, Settings, LayoutDashboard, ArrowUp, User as UserIcon } from "lucide-react"; // Renombramos el icono
import { Button } from "@/components/ui/button";
import { User } from "@/api/entities"; // Usamos la entidad User directamente
import HubSpotTracking from "@/components/hubspot/HubSpotTracking";
import FloatingChatWidget from "@/components/shared/FloatingChatWidget";

const HUBSPOT_MEETING_URL = "https://meetings.hubspot.com/jjdlr/simiriki-consulta";

const GA4_MEASUREMENT_ID = "{{GA4_MEASUREMENT_ID}}";
const HUBSPOT_PORTAL_ID = "50203416";

// -- CORREGIDO: Navegación simplificada y funcional --
const navigationItems = [
  { title: "Inicio", url: createPageUrl("Home"), icon: Globe },
  { title: "Servicios", url: "#servicios", icon: Zap, scroll: true },
  { title: "Casos de Éxito", url: "#testimonios", icon: TrendingUp, scroll: true },
  { title: "Precios", url: HUBSPOT_MEETING_URL, icon: Calculator, external: true }, // Apunta a la consulta
  { title: "Blog", url: "#blog", icon: BookOpen, scroll: true },
  { title: "Sobre Nosotros", url: "#fundador", icon: Users, scroll: true }, // ID corregido
  // { title: "Agendar Reunión", url: HUBSPOT_MEETING_URL, icon: Calendar, external: true }, // Eliminado por redundancia
];

export default function Layout({ children, currentPageName }) {
  const location = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [user, setUser] = useState(null);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    // --- SEO & META TAGS IMPLEMENTATION ---
    const title = "Simiriki: Automatización Inteligente para PYMEs que Venden 340% Más";
    const description = "Transformamos tu PYME con IA. Generación de leads automática, procesos digitalizados y ROI en 90 días. La plataforma líder en México y Latinoamérica. ¡Consulta gratuita!";
    const imageUrl = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/simiriki_og_image.png"; // Asumiendo una imagen para redes sociales
    const pageUrl = `https://www.simiriki.com${location.pathname}`;

    // Standard Meta Tags
    document.title = title;
    
    const setMetaTag = (name, content) => {
      let element = document.querySelector(`meta[name="${name}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('name', name);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    setMetaTag('description', description);
    setMetaTag('keywords', 'automatización, PYME, IA, leads, CRM, HubSpot, transformación digital, México, Latinoamérica, ventas');

    // Open Graph Tags (for Facebook, LinkedIn, etc.)
    const setOgTag = (property, content) => {
      let element = document.querySelector(`meta[property="${property}"]`);
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute('property', property);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    setOgTag('og:title', title);
    setOgTag('og:description', description);
    setOgTag('og:type', 'website');
    setOgTag('og:url', pageUrl);
    setOgTag('og:image', imageUrl);
    setOgTag('og:site_name', 'Simiriki');

    // Twitter Card Tags
    setMetaTag('twitter:card', 'summary_large_image');
    setMetaTag('twitter:title', title);
    setMetaTag('twitter:description', description);
    setMetaTag('twitter:image', imageUrl);

    // Favicon and Viewport
    const favicon = document.querySelector("link[rel='icon']") || document.createElement('link');
    favicon.rel = 'icon';
    favicon.href = "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d38ee6579_LogoSimple.png";
    document.head.appendChild(favicon);

    const viewport = document.querySelector("meta[name='viewport']") || document.createElement('meta');
    viewport.name = 'viewport';
    viewport.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';
    document.head.appendChild(viewport);
    
    // JSON-LD Structured Data
    const jsonLdScriptId = 'json-ld-structured-data';
    let jsonLdScript = document.getElementById(jsonLdScriptId);
    if (!jsonLdScript) {
        jsonLdScript = document.createElement('script');
        jsonLdScript.id = jsonLdScriptId;
        jsonLdScript.type = 'application/ld+json';
        document.head.appendChild(jsonLdScript);
    }
    jsonLdScript.innerHTML = JSON.stringify({
      "@context": "https://schema.org",
      "@type": "Organization",
      "name": "Simiriki",
      "url": "https://www.simiriki.com",
      "logo": "https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d38ee6579_LogoSimple.png",
      "contactPoint": {
        "@type": "ContactPoint",
        "telephone": "+52-813-467-5514",
        "contactType": "customer service"
      },
      "sameAs": [
        "https://linkedin.com/company/simiriki",
        "https://instagram.com/simiriki"
      ]
    });


    // CRITICAL: Prevent any HubSpot chat widgets from loading
    window.hsConversationsSettings = {
      loadImmediately: false,
      enableWelcomeMessage: false,
      disableAttachment: true
    };

    // Disable HubSpot chat if it tries to load
    if (window.HubSpotConversations) {
      window.HubSpotConversations.widget.remove();
    }

    // --- Global Tracking Function for GA4 ---
    window.trackGAEvent = (eventName, eventParams = {}) => {
      if (typeof window.gtag === 'function') {
        window.gtag('event', eventName, eventParams);
        console.log(`GA Event: ${eventName}`, eventParams);
      } else {
        console.warn('GA4 (gtag.js) not loaded or blocked.');
      }
    };

    // --- Global Tracking Function for HubSpot ---
    window._hsq = window._hsq || [];
    window.hsTrackEvent = (eventName, eventProperties = {}) => {
      window._hsq.push(['trackEvent', {
        id: eventName,
        properties: eventProperties
      }]);
      console.log(`HubSpot Event: ${eventName}`, eventProperties);
    };

    // --- Google Analytics 4 Script ---
    if (GA4_MEASUREMENT_ID && GA4_MEASUREMENT_ID !== "{{GA4_MEASUREMENT_ID}}") {
      if (!document.getElementById('ga4-script')) {
        const script = document.createElement('script');
        script.id = 'ga4-script';
        script.async = true;
        script.src = `https://www.googletagmanager.com/gtag/js?id=${GA4_MEASUREMENT_ID}`;
        document.head.appendChild(script);

        const inlineScript = document.createElement('script');
        inlineScript.id = 'ga4-inline-script';
        inlineScript.innerHTML = `
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
          gtag('config', '${GA4_MEASUREMENT_ID}');
        `;
        document.head.appendChild(inlineScript);
      }
    }

    const getCurrentUser = async () => {
      try {
        const currentUser = await User.me(); // Usamos User.me() directamente
        setUser(currentUser);
      } catch (error) {
        setUser(null);
      }
    };
    getCurrentUser();

    const handleScroll = () => {
      if (window.scrollY > 300) {
        setShowBackToTop(true);
      } else {
        setShowBackToTop(false);
      }
    };

    window.addEventListener('scroll', handleScroll);

    return () => {
      window.removeEventListener('scroll', handleScroll);
    };
  }, [location.pathname]);

  const handleNavClick = (item, e) => {
    if (item.scroll) {
      e.preventDefault();
      const targetId = item.url.replace('#', '');
      const element = document.getElementById(targetId);
      if (element) {
        element.scrollIntoView({ behavior: 'smooth' });
      }
    }
  };

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="bg-slate-950 text-gray-200 font-sans antialiased">
      {/* Subtle Background Elements */}
      <div className="fixed inset-0 z-0">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-500/5 via-transparent to-purple-500/5"></div>
        <div 
          className="absolute inset-0 opacity-10"
          style={{
            backgroundImage: `
              linear-gradient(rgba(148, 163, 184, 0.1) 1px, transparent 1px),
              linear-gradient(90deg, rgba(148, 163, 184, 0.1) 1px, transparent 1px)
            `,
            backgroundSize: '40px 40px'
          }}
        ></div>
        
        {/* Subtle Floating Elements */}
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-emerald-500/5 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 bg-purple-500/5 rounded-full blur-3xl"></div>
      </div>

      <style jsx global>{`
        .gradient-text {
          background: linear-gradient(135deg, #10B981, #8B5CF6);
          -webkit-background-clip: text;
          -webkit-text-fill-color: transparent;
          background-clip: text;
        }
        
        .gradient-bg {
          background: linear-gradient(135deg, #10B981, #8B5CF6);
        }
        
        .glass-effect {
          background: rgba(15, 23, 42, 0.6);
          backdrop-filter: blur(12px);
          border: 1px solid rgba(148, 163, 184, 0.1);
        }
        
        .sophisticated-border {
          border: 1px solid rgba(148, 163, 184, 0.2);
          transition: border-color 0.3s ease;
        }
        
        .sophisticated-border:hover {
          border-color: rgba(16, 185, 129, 0.3);
        }

        /* Remove any list-style dots */
        nav a::before,
        nav a::after,
        .admin-link::before,
        .admin-link::after {
          content: none !important;
          display: none !important;
        }

        /* Mobile-first responsive design improvements */
        @media (max-width: 768px) {
          .hero-title {
            font-size: 2.5rem !important;
            line-height: 1.2 !important;
          }
          
          .hero-subtitle {
            font-size: 1.125rem !important;
          }

          .mobile-padding {
            padding-left: 1rem !important;
            padding-right: 1rem !important;
          }

          .mobile-text-center {
            text-align: center !important;
          }

          .mobile-full-width {
            width: 100% !important;
          }

          .mobile-stack {
            flex-direction: column !important;
            gap: 1rem !important;
          }
        }

        /* Ensure touch targets are adequate on mobile */
        @media (max-width: 768px) {
          button, a {
            min-height: 44px;
            min-width: 44px;
          }
        }
      `}</style>
      
      {/* Header */}
      <header className="fixed top-0 left-0 right-0 z-50 bg-slate-950/80 backdrop-blur-lg border-b border-slate-800/50">
        <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            {/* Logo */}
            <Link to={createPageUrl("Home")} className="flex items-center space-x-3 group">
              <img 
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d38ee6579_LogoSimple.png" 
                alt="Simiriki - Automatización Inteligente para PYMEs" 
                className="w-10 h-10 transition-transform group-hover:scale-110" 
                width="40" 
                height="40"
                loading="eager"
              />
              <span className="text-2xl font-bold gradient-text">simiriki</span>
            </Link>

            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center space-x-8">
              {navigationItems.map((item) => {
                if (item.external) {
                  return (
                    <a
                      key={item.title}
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gray-300 hover:text-emerald-400 text-sm font-medium transition-colors duration-200"
                      aria-label={`${item.title} (se abre en nueva ventana)`}
                    >
                      {item.title}
                    </a>
                  );
                } else if (item.scroll) {
                  return (
                    <a
                      key={item.title}
                      href={item.url}
                      onClick={(e) => handleNavClick(item, e)}
                      className="text-gray-300 hover:text-emerald-400 text-sm font-medium transition-colors duration-200 cursor-pointer"
                    >
                      {item.title}
                    </a>
                  );
                } else {
                  return (
                    <Link
                      key={item.title}
                      to={item.url}
                      className="text-gray-300 hover:text-emerald-400 text-sm font-medium transition-colors duration-200"
                    >
                      {item.title}
                    </Link>
                  );
                }
              })}
              {user && (
                <Link
                  to={createPageUrl("ClientPortal")}
                  className="text-sm font-medium transition-colors duration-200 flex items-center text-gray-300 hover:text-emerald-400"
                >
                  <UserIcon className="w-4 h-4 mr-2" />
                  Mi Portal
                </Link>
              )}
              {user && user.role === 'admin' && (
                <Link
                  to={createPageUrl("AdminDashboard")}
                  className="text-sm font-medium transition-colors duration-200 flex items-center text-gray-300 hover:text-white"
                >
                  <LayoutDashboard className="w-4 h-4 mr-2" />
                  Panel de Control
                </Link>
              )}
              <a 
                href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
                target="_blank"
                rel="noopener noreferrer"
              >
                <Button className="gradient-bg text-white hover:opacity-90 transition-opacity">
                  Reserva tu Consulta Gratuita
                </Button>
              </a>
            </div>

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-white hover:text-emerald-400 transition-colors"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label={isMobileMenuOpen ? "Cerrar menú" : "Abrir menú"}
            >
              {isMobileMenuOpen ? (
                <X className="w-6 h-6" />
              ) : (
                <Menu className="w-6 h-6" />
              )}
            </button>
          </div>
        </nav>

        {/* Mobile Navigation */}
        {isMobileMenuOpen && (
          <div className="md:hidden glass-effect border-t border-gray-700">
            <div className="px-2 pt-2 pb-3 space-y-1">
              {navigationItems.map((item) => {
                if (item.external) {
                  return (
                    <a
                      key={item.title}
                      href={item.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors text-gray-300 hover:text-white hover:bg-white/10"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <item.icon className="w-4 h-4 mr-3" />
                      {item.title}
                    </a>
                  );
                } else if (item.scroll) {
                  return (
                    <a
                      key={item.title}
                      href={item.url}
                      onClick={(e) => {
                        handleNavClick(item, e);
                        setIsMobileMenuOpen(false);
                      }}
                      className="flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors text-gray-300 hover:text-white hover:bg-white/10"
                    >
                      <item.icon className="w-4 h-4 mr-3" />
                      {item.title}
                    </a>
                  );
                } else {
                  return (
                    <Link
                      key={item.title}
                      to={item.url}
                      className="flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors text-gray-300 hover:text-white hover:bg-white/10"
                      onClick={() => setIsMobileMenuOpen(false)}
                    >
                      <item.icon className="w-4 h-4 mr-3" />
                      {item.title}
                    </Link>
                  );
                }
              })}
              {user && (
                <Link
                  to={createPageUrl("ClientPortal")}
                  className="flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors text-gray-300 hover:text-white hover:bg-white/10"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <UserIcon className="w-4 h-4 mr-3" />
                  Mi Portal
                </Link>
              )}
              {user && user.role === 'admin' && (
                <Link
                  to={createPageUrl("AdminDashboard")}
                  className="flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors text-gray-300 hover:text-white hover:bg-white/10"
                  onClick={() => setIsMobileMenuOpen(false)}
                >
                  <LayoutDashboard className="w-4 h-4 mr-3" />
                  Panel de Control
                </Link>
              )}
              <div className="px-3 py-2">
                <a 
                  href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
                  target="_blank"
                  rel="noopener noreferrer"
                >
                  <Button className="w-full gradient-bg text-white hover:opacity-90">
                    Reserva tu Consulta Gruta
                  </Button>
                </a>
              </div>
            </div>
          </div>
        )}
      </header>
      
      {/* Main Content */}
      <main className="pt-16 relative z-10">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-slate-900/80 backdrop-blur-sm border-t border-gray-700 mt-20 relative z-10">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div className="col-span-1 md:col-span-2">
              <div className="flex items-center space-x-3 mb-4">
                <img 
                  src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/d38ee6579_LogoSimple.png" 
                  alt="Simiriki Logo" 
                  className="w-10 h-10" 
                  width="40" 
                  height="40"
                  loading="lazy"
                />
                <span className="text-2xl font-bold gradient-text">simiriki</span>
              </div>
              <p className="text-gray-400 mb-4 max-w-md">
                La plataforma líder de automatización inteligente para PYMEs en América Latina.
              </p>
              <div className="text-lg font-semibold gradient-text mb-6">
                Automatiza. Escala. Transforma.
              </div>
              
              {/* Contact Info */}
              <div className="space-y-2 mb-6">
                <a href="tel:+528134675514" className="flex items-center text-emerald-400 hover:text-emerald-300 transition-colors">
                  <Phone className="w-4 h-4 mr-2" />
                  +52 813 467 5514
                </a>
                <a href="mailto:jjdlr@simiriki.com" className="flex items-center text-gray-300 hover:text-emerald-400 transition-colors">
                  <MessageSquare className="w-4 h-4 mr-2" />
                  jjdlr@simiriki.com
                </a>
              </div>

              <div className="flex items-center space-x-6 text-gray-300">
                  <a href="https://linkedin.com/company/simiriki" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors flex items-center">
                    LinkedIn <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
                  <a href="https://instagram.com/simiriki" target="_blank" rel="noopener noreferrer" className="hover:text-emerald-400 transition-colors flex items-center">
                    Instagram <ExternalLink className="w-3 h-3 ml-1" />
                  </a>
              </div>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Servicios</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to={createPageUrl("Services")} className="hover:text-emerald-400 transition-colors">Automatización</Link></li>
                <li><Link to={createPageUrl("Services")} className="hover:text-emerald-400 transition-colors">Generación de Leads</Link></li>
                <li><Link to={createPageUrl("Services")} className="hover:text-emerald-400 transition-colors">IA para Negocios</Link></li>
                <li><Link to={createPageUrl("Services")} className="hover:text-emerald-400 transition-colors">Transformación Digital</Link></li>
              </ul>
            </div>
            
            <div>
              <h3 className="text-white font-semibold mb-4">Compañía</h3>
              <ul className="space-y-2 text-gray-400">
                <li><Link to={createPageUrl("About")} className="hover:text-emerald-400 transition-colors">Sobre Nosotros</Link></li>
                <li><Link to={createPageUrl("Blog")} className="hover:text-emerald-400 transition-colors">Blog</Link></li>
                <li><Link to={createPageUrl("CaseStudies")} className="hover:text-emerald-400 transition-colors">Casos de Éxito</Link></li>
                <li><Link to={createPageUrl("FAQ")} className="hover:text-emerald-400 transition-colors">FAQ</Link></li>
                <li><Link to={createPageUrl("Contact")} className="hover:text-emerald-400 transition-colors font-bold">Reserva tu Consulta</Link></li>
              </ul>
            </div>
          </div>
          
          <div className="border-t border-gray-700 mt-8 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="text-center md:text-left mb-4 md:mb-0">
                <p className="font-bold text-white mb-2 gradient-text">
                  Simiriki: Convertimos PYMEs tradicionales en máquinas modernas de crecimiento.
                </p>
                <p className="text-gray-400 text-sm">&copy; 2024 Simiriki. Todos los derechos reservados.</p>
              </div>
              
              {/* Trust Badges */}
              <div className="flex items-center space-x-4">
                <div className="text-xs text-gray-500 text-center">
                  <div className="text-emerald-400 font-semibold">HubSpot Partner</div>
                  <div>Certificado</div>
                </div>
                <div className="text-xs text-gray-500 text-center">
                  <div className="text-blue-400 font-semibold">Google Partner</div>
                  <div>Verificado</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </footer>

      {/* Back to Top Button */}
      {showBackToTop && (
        <Button
          onClick={scrollToTop}
          className="fixed bottom-24 right-6 z-50 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 text-white hover:bg-white/20"
          aria-label="Volver arriba"
        >
          <ArrowUp className="w-6 h-6" />
        </Button>
      )}

      {/* SOLO UN CHAT WIDGET - EL NUESTRO */}
      <FloatingChatWidget />
      
      {/* HubSpot Integration - SOLO TRACKING, SIN CHAT */}
      <HubSpotTracking portalId={HUBSPOT_PORTAL_ID} />
    </div>
  );
}

