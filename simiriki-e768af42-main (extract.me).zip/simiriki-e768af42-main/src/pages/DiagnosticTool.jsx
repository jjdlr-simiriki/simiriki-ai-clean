
import React, { useState } from 'react';
import { syncToHubspot } from "@/api/functions";
import DiagnosticQuestion from '../components/diagnostic/DiagnosticQuestion';
import DiagnosticResult from '../components/diagnostic/DiagnosticResult';

const questions = [
  {
    question: "¿Cuál es el mayor desafío en tu proceso de ventas actual?",
    property: "biggest_challenge",
    options: [
      { text: "Generar suficientes leads de calidad", score: 3 },
      { text: "Dar seguimiento efectivo a todos los leads", score: 5 },
      { text: "Cerrar ventas de manera consistente", score: 4 },
      { text: "Proceso de cotización lento y manual", score: 4 }
    ]
  },
  {
    question: "¿Cuántas horas a la semana dedica tu equipo a tareas manuales y repetitivas (ej. copiar-pegar datos, enviar emails uno a uno)?",
    property: "manual_hours",
    options: [
      { text: "Menos de 5 horas", score: 1 },
      { text: "Entre 5 y 10 horas", score: 3 },
      { text: "Entre 10 y 20 horas", score: 5 },
      { text: "Más de 20 horas", score: 5 }
    ]
  },
  {
    question: "¿Cómo calificas tu capacidad para responder a nuevos clientes potenciales?",
    property: "response_time",
    options: [
      { text: "Instantánea (automatizado)", score: 0 },
      { text: "En menos de 1 hora", score: 2 },
      { text: "En el mismo día", score: 4 },
      { text: "Tarda más de 24 horas", score: 5 }
    ]
  },
  {
    question: "¿Qué sistema utilizas para gestionar la información de tus clientes (CRM)?",
    property: "crm_usage",
    options: [
      { text: "Usamos un CRM como HubSpot/Salesforce", score: 1 },
      { text: "Hojas de cálculo (Excel, Google Sheets)", score: 5 },
      { text: "Notas, emails y mi memoria", score: 5 },
      { text: "No usamos ningún sistema", score: 5 }
    ]
  },
    {
    question: "¿Cuál es tu objetivo principal al considerar la automatización?",
    property: "main_goal",
    options: [
      { text: "Aumentar las ventas y los ingresos", score: 4 },
      { text: "Reducir costos y mejorar la eficiencia", score: 3 },
      { text: "Liberar tiempo para enfocarme en la estrategia", score: 5 },
      { text: "Mejorar la experiencia del cliente", score: 3 }
    ]
  }
];

export default function DiagnosticTool() {
  const [step, setStep] = useState(0);
  const [answers, setAnswers] = useState({});
  const [score, setScore] = useState(0);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [resultsReady, setResultsReady] = useState(false);
  const [leadData, setLeadData] = useState({ name: '', email: '' });

  const handleAnswer = (option, property) => {
    setAnswers(prev => ({ ...prev, [property]: option.text }));
    setScore(prev => prev + option.score);
    if (step < questions.length - 1) {
      setStep(prev => prev + 1);
    } else {
      setStep(prev => prev + 1); // Move to the lead capture form
    }
  };

  const handleLeadSubmit = async (e) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    try {
      const fullLeadData = {
        ...leadData,
        ...answers,
        automation_score: score, // <-- CORREGIDO: Enviando el score
        source: "diagnostic_tool"
      };
      
      await syncToHubspot({
        leadData: fullLeadData,
        eventType: 'diagnostic_completion'
      });
      
      window.trackGAEvent('generate_lead', {
        form_name: 'diagnostic_tool',
        lead_source: 'Diagnostic Tool Page',
        automation_score: score
      });
      window.trackGAEvent('page_view', {
        page_title: 'Resultados del Diagnóstico',
        page_location: '/diagnostic-tool/results'
      });
      
      setResultsReady(true);
    } catch (error) {
      console.error("Error submitting diagnostic:", error);
      alert("Hubo un error al enviar tus datos. Por favor, inténtalo de nuevo.");
    }
    
    setIsSubmitting(false);
  };
  
  if (resultsReady) {
    return <DiagnosticResult score={score} answers={answers} />;
  }

  return (
    <div className="min-h-screen py-20">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {step <= questions.length ? (
          <DiagnosticQuestion
            step={step}
            questions={questions}
            handleAnswer={handleAnswer}
            handleLeadSubmit={handleLeadSubmit}
            leadData={leadData}
            setLeadData={setLeadData}
            isSubmitting={isSubmitting}
          />
        ) : (
           <p>Cargando resultados...</p>
        )}
      </div>
    </div>
  );
}
