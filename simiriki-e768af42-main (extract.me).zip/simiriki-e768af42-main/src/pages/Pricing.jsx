import React from 'react';
import { CheckCircle, Zap, TrendingUp, Gem, HelpCircle, ArrowRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const pricingTiers = [
  {
    name: "Esencial",
    price: "$999",
    frequency: "/mes",
    description: "Para PYMES que quieren empezar a automatizar y ver resultados rápidos.",
    features: [
      "Diagnóstico y Roadmap de Automatización",
      "1 Flujo de Trabajo Automatizado (core)",
      "Configuración de CRM (HubSpot Básico)",
      "Dashboard de Métricas Esenciales",
      "Soporte por Email"
    ],
    cta: "Empezar Ahora",
    icon: Zap,
    color: "green",
    featured: false
  },
  {
    name: "Crecimiento",
    price: "$2,499",
    frequency: "/mes",
    description: "El paquete más popular para escalar operaciones y ventas de forma predecible.",
    features: [
      "Todo en Esencial, y además:",
      "3 Flujos de Trabajo Avanzados",
      "Lead Scoring y Nurturing Automático",
      "Chatbot Inteligente para Calificación",
      "Integración de 2 Aplicaciones Clave",
      "Soporte Prioritario por Chat"
    ],
    cta: "Elegir Crecimiento",
    icon: TrendingUp,
    color: "purple",
    featured: true
  },
  {
    name: "Empresarial",
    price: "Personalizado",
    frequency: "",
    description: "Una solución a medida para empresas que buscan una transformación digital completa.",
    features: [
      "Todo en Crecimiento, y además:",
      "Automatización Ilimitada de Workflows",
      "Implementación de IA Predictiva",
      "Integraciones a la Medida (API)",
      "Capacitación de Equipo y Acompañamiento",
      "Consultor Dedicado"
    ],
    cta: "Agendar Consulta",
    icon: Gem,
    color: "blue",
    featured: false
  }
];

const faqs = [
  {
    question: "¿Existe algún costo de implementación inicial?",
    answer: "Nuestros paquetes están diseñados para ser todo incluido. El plan Empresarial puede tener costos de configuración asociados a integraciones complejas, los cuales se detallan en la propuesta personalizada."
  },
  {
    question: "¿Puedo cambiar de plan más adelante?",
    answer: "¡Por supuesto! Puedes mejorar tu plan en cualquier momento a medida que tu negocio crece. Queremos ser tu aliado a largo plazo."
  },
  {
    question: "¿En cuánto tiempo veré resultados?",
    answer: "Aunque varía, la mayoría de nuestros clientes en el plan Crecimiento ven un ROI positivo y una mejora significativa en eficiencia en los primeros 90 días."
  },
  {
    question: "¿Qué pasa si mis necesidades son diferentes?",
    answer: "¡Hablemos! El plan Empresarial es totalmente personalizable. Agendemos una consulta para crear un paquete que se ajuste perfectamente a tus objetivos."
  }
];

export default function Pricing() {
  return (
    <div className="py-20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Planes Flexibles para <span className="gradient-text">Impulsar tu Crecimiento</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Sin contratos a largo plazo, sin costos ocultos. Solo resultados. Elige el plan que se adapta a tu etapa de negocio.
          </p>
        </div>

        {/* Pricing Tiers */}
        <div className="grid lg:grid-cols-3 gap-8 items-start">
          {pricingTiers.map((tier) => (
            <Card 
              key={tier.name} 
              className={`bg-white/5 backdrop-blur-sm border border-white/10 rounded-2xl flex flex-col h-full ${tier.featured ? 'border-purple-400/80 transform scale-105' : 'hover:border-white/30'}`}
            >
              {tier.featured && (
                <div className="text-center py-2 bg-purple-500/80 rounded-t-2xl text-sm font-bold">MÁS POPULAR</div>
              )}
              <CardHeader className="p-6">
                <div className="flex items-center space-x-3 mb-4">
                  <div className={`w-12 h-12 bg-gradient-to-br from-${tier.color}-400 to-${tier.color}-600 rounded-lg flex items-center justify-center`}>
                    <tier.icon className="w-6 h-6 text-white" />
                  </div>
                  <CardTitle className="text-2xl font-bold text-white">{tier.name}</CardTitle>
                </div>
                <CardDescription className="text-gray-300">{tier.description}</CardDescription>
                <div className="pt-4">
                  <span className="text-4xl font-bold text-white">{tier.price}</span>
                  <span className="text-gray-400">{tier.frequency}</span>
                </div>
              </CardHeader>
              <CardContent className="p-6 flex-grow flex flex-col">
                <ul className="space-y-3 mb-8 flex-grow">
                  {tier.features.map((feature, index) => (
                    <li key={index} className="flex items-start">
                      <CheckCircle className={`w-5 h-5 text-${tier.color}-400 mr-3 mt-1 flex-shrink-0`} />
                      <span className="text-gray-300">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Link to={createPageUrl(`Contact?plan=${tier.name}`)} className="w-full">
                  <Button size="lg" className={`w-full ${tier.featured ? 'gradient-bg text-white' : `bg-${tier.color}-500/20 text-white hover:bg-${tier.color}-500/40`}`}>
                    {tier.cta}
                  </Button>
                </Link>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="mt-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white">Preguntas Frecuentes</h2>
            <p className="text-gray-400">Aclarando tus dudas para que tomes la mejor decisión.</p>
          </div>
          <div className="max-w-4xl mx-auto grid md:grid-cols-2 gap-8">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white/5 p-6 rounded-lg">
                <h3 className="font-semibold text-white mb-2 flex items-center">
                  <HelpCircle className="w-5 h-5 text-purple-400 mr-2" />
                  {faq.question}
                </h3>
                <p className="text-gray-400 text-sm">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Final CTA */}
        <Card className="mt-20 bg-gradient-to-br from-green-500/10 to-purple-500/10 p-8 md:p-12 rounded-3xl border border-white/10 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">¿Listo para Empezar a Crecer de Forma Inteligente?</h2>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Tu transformación comienza con una consulta gratuita de 30 minutos. Sin presión, solo soluciones.
          </p>
          <Link to={createPageUrl("Contact")}>
            <Button size="lg" className="gradient-bg text-white hover:opacity-90">
              Agendar mi Consulta Gratuita
              <ArrowRight className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </Card>
      </div>
    </div>
  );
}