import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Search } from 'lucide-react';
import { Card, CardContent } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const allFaqs = [
  // General Questions
  { category: 'General', question: "¿Para qué tipo de empresas son sus servicios?", answer: "Nos especializamos en PYMEs de 10 a 200 empleados en cualquier sector que busque digitalizar y automatizar sus procesos. Desde despachos contables hasta tiendas de retail, clínicas dentales y agencias de marketing." },
  { category: 'General', question: "¿Cuánto tiempo tarda en ver resultados?", answer: "Aunque varía por proyecto, el 85% de nuestros clientes ven mejoras significativas en eficiencia y generación de leads en los primeros 30-60 días. Los resultados completos se materializan en 90 días." },
  { category: 'General', question: "¿La consulta realmente es gratuita?", answer: "Completamente gratuita y sin compromiso. Te daremos valor real en esos 30 minutos, incluyendo 3 ideas específicas para automatizar tu negocio, sin importar si decides trabajar con nosotros o no." },
  { category: 'General', question: "¿Trabajan con empresas fuera de México?", answer: "Sí, atendemos empresas en toda América Latina de forma remota. Nuestro horario se adapta a diferentes zonas horarias para brindar el mejor servicio." },
  
  // Technical Questions
  { category: 'Técnico', question: "¿Necesito conocimientos técnicos para usar las automatizaciones?", answer: "Para nada. Diseñamos todas las automatizaciones para que sean súper fáciles de usar. Te entregamos un sistema 'llave en mano', capacitamos a tu equipo y proporcionamos soporte continuo." },
  { category: 'Técnico', question: "¿Con qué herramientas se integran?", answer: "Nos integramos con cientos de herramientas populares como HubSpot, Salesforce, Mailchimp, QuickBooks, Calendly, Tally, y muchas más. Si usas una herramienta, es casi seguro que podemos conectarla." },
  { category: 'Técnico', question: "¿La información de mi empresa está segura?", answer: "Absolutamente. La seguridad es nuestra máxima prioridad. Utilizamos protocolos de encriptación de nivel bancario y seguimos las mejores prácticas de la industria para garantizar que tus datos y los de tus clientes estén siempre protegidos." },

  // Pricing & Process
  { category: 'Proceso', question: "¿Qué incluye la garantía de 30 días?", answer: "Si después de 30 días no estás satisfecho con el progreso o no ves el valor prometido, te devolvemos el 100% de tu inversión. Sin preguntas, sin letra pequeña. Tu éxito es nuestro éxito." },
  { category: 'Proceso', question: "¿Cómo es el proceso de trabajo con ustedes?", answer: "Nuestro proceso es simple: 1. Consulta y Diagnóstico (gratuito). 2. Diseño de la Estrategia de Automatización. 3. Implementación y Pruebas. 4. Capacitación a tu Equipo. 5. Soporte y Optimización Continua. Siempre estarás informado del progreso." },
  { category: 'Precios', question: "¿Cuánto cuesta la automatización?", answer: "No hay una respuesta única, ya que cada proyecto es un traje a la medida. Sin embargo, nuestros paquetes de implementación inicial suelen oscilar entre $1,500 y $5,000 USD. Siempre buscamos que la inversión se pague sola en menos de 6 meses con los ahorros y el aumento de ingresos." },
];

export default function FAQPage() {
  const [openIndex, setOpenIndex] = useState(null);
  const [searchTerm, setSearchTerm] = useState('');

  const toggleFAQ = (index) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  const filteredFaqs = allFaqs.filter(faq => 
    faq.question.toLowerCase().includes(searchTerm.toLowerCase()) || 
    faq.answer.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <section className="py-20 text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Preguntas Frecuentes
          </h1>
          <p className="text-xl text-gray-300">
            Encuentra respuestas a tus dudas sobre automatización, procesos y precios.
          </p>
        </div>
        
        <div className="relative mb-8 max-w-lg mx-auto">
          <Input
            type="text"
            placeholder="Buscar una pregunta..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-white/10 border-white/20 pl-10"
          />
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
        </div>

        <div className="space-y-4">
          {filteredFaqs.length > 0 ? filteredFaqs.map((faq, index) => (
            <Card key={index} className="bg-white/5 backdrop-blur-sm border-white/10 hover:border-white/20 transition-all duration-300">
              <CardContent className="p-0">
                <button
                  onClick={() => toggleFAQ(index)}
                  className="w-full text-left p-6 flex items-center justify-between"
                >
                  <h3 className="text-lg font-semibold text-white pr-4">
                    {faq.question}
                  </h3>
                  {openIndex === index ? (
                    <ChevronUp className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                  ) : (
                    <ChevronDown className="w-5 h-5 text-gray-400 flex-shrink-0" />
                  )}
                </button>
                {openIndex === index && (
                  <div className="px-6 pb-6">
                    <p className="text-gray-300 leading-relaxed">
                      {faq.answer}
                    </p>
                  </div>
                )}
              </CardContent>
            </Card>
          )) : (
            <p className="text-center text-gray-400">No se encontraron preguntas. Intenta con otra búsqueda.</p>
          )}
        </div>

        <Card className="mt-16 bg-gradient-to-br from-green-500/10 to-purple-500/10 p-8 text-center border-white/10">
            <h3 className="text-2xl font-bold text-white mb-4">¿No encontraste lo que buscabas?</h3>
            <p className="text-gray-300 mb-6">Nuestro equipo de expertos está listo para resolver cualquier duda que tengas.</p>
            <Link to={createPageUrl("Contact")}>
              <Button size="lg" className="gradient-bg text-white hover:opacity-90">
                Contactar a un Especialista
              </Button>
            </Link>
        </Card>
      </div>
    </section>
  );
}