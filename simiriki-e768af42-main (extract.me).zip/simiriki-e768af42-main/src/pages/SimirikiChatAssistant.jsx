import React from 'react';
import { MessageSquare, Bot, Zap, Users, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import SimirikiChatWidget from '../components/SimirikiChatWidget';

export default function SimirikiChatAssistant() {
  return (
    <div className="py-20 text-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <div className="w-20 h-20 bg-gradient-to-br from-emerald-400 to-purple-400 rounded-full flex items-center justify-center mx-auto mb-6">
            <Bot className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Asistente de IA <span className="gradient-text">Simiriki</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Descubre oportunidades de automatización para tu negocio. Nuestro asistente con IA analiza tu situación y te da recomendaciones personalizadas al instante.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 mb-12">
          {/* Benefits */}
          <div className="lg:col-span-1 space-y-6">
            <Card className="bg-white/5 backdrop-blur-sm border-white/10">
              <CardHeader>
                <CardTitle className="flex items-center text-green-400">
                  <Zap className="w-5 h-5 mr-2" />
                  Análisis Inmediato
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">
                  Obtén un diagnóstico de automatización en menos de 3 minutos
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/5 backdrop-blur-sm border-white/10">
              <CardHeader>
                <CardTitle className="flex items-center text-purple-400">
                  <Users className="w-5 h-5 mr-2" />
                  Recomendaciones Personalizadas
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">
                  Cada sugerencia está adaptada a tu industria y tamaño de empresa
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white/5 backdrop-blur-sm border-white/10">
              <CardHeader>
                <CardTitle className="flex items-center text-blue-400">
                  <Clock className="w-5 h-5 mr-2" />
                  Disponible 24/7
                </CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-300">
                  Obtén respuestas cualquier día, a cualquier hora
                </p>
              </CardContent>
            </Card>
          </div>

          {/* Chat Widget */}
          <div className="lg:col-span-2">
            <Card className="bg-white/5 backdrop-blur-sm border-white/10 h-full">
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="w-5 h-5 mr-2 text-emerald-400" />
                  Chatea con nuestro Asistente de IA
                </CardTitle>
              </CardHeader>
              <CardContent className="h-96">
                <SimirikiChatWidget />
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Call to Action */}
        <div className="text-center">
          <div className="bg-gradient-to-br from-emerald-500/10 to-purple-500/10 rounded-2xl p-8 border border-white/10">
            <h3 className="text-2xl font-bold text-white mb-4">
              ¿Necesitas una consulta más personalizada?
            </h3>
            <p className="text-gray-300 mb-6">
              Si el asistente identifica una gran oportunidad para tu negocio, 
              podemos agendar una llamada gratuita de 30 minutos para diseñar un plan específico.
            </p>
            <a 
              href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block bg-gradient-to-r from-emerald-500 to-purple-500 text-white px-8 py-3 rounded-lg font-semibold hover:opacity-90 transition-opacity"
            >
              Agendar Consulta Gratuita
            </a>
          </div>
        </div>
      </div>
    </div>
  );
}