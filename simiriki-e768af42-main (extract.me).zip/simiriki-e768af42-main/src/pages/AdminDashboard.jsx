
import React, { useState, useEffect } from "react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  BarChart2,
  Users,
  TrendingUp,
  MessageCircle, 
  Settings,
  Zap,
  Sparkles,
  Loader,
  Save,
  Plus,
  Play,
  Pencil,
  Trash2,
  FolderKanban,
  TrendingUp as TrendingUpIcon,
  DollarSign,
  Mail, 
  MessageSquare 
} from "lucide-react";
import { User } from "@/api/entities";
import { Project } from "@/api/entities";
import { InvokeLLM } from "@/api/integrations";
import { Testimonial } from "@/api/entities";
import QuickClientActivation from '../components/admin/QuickClientActivation';
import ProjectManager from '../components/admin/ProjectManager';
import { getMetricsData } from "@/api/functions";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from 'recharts';
import MarketingAutomationManager from "../components/admin/MarketingAutomationManager";

export default function AdminDashboard() {
  const [user, setUser] = useState(null);
  const [projects, setProjects] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState("dashboard");

  useEffect(() => {
    const loadData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        if (currentUser.role !== 'admin') {
          window.location.href = '/';
          return;
        }

        const [fetchedProjects, metricsResponse] = await Promise.all([
          Project.list('-created_date', 50),
          getMetricsData()
        ]);
        
        setProjects(fetchedProjects);
        setMetrics(metricsResponse.data);

      } catch (error) {
        console.error("Error loading user:", error);
        window.location.href = '/';
      }
      setIsLoading(false);
    };

    loadData();
  }, []);

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  if (!user || user.role !== 'admin') {
    return (
      <div className="flex items-center justify-center min-h-screen text-gray-800">
        <div>No tienes permisos para acceder a esta página.</div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-100 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-800">Panel de Control Simiriki</h1>
          <p className="text-gray-500 mt-2 text-sm sm:text-base">Gestiona tu plataforma y analiza el rendimiento</p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
          {/* Tabs List - Responsive con scroll horizontal en móvil */}
          <div className="w-full overflow-x-auto pb-2">
            <TabsList className="grid w-full grid-cols-4 lg:grid-cols-8 gap-1 bg-white rounded-lg p-1 min-w-[600px]">
              <TabsTrigger value="dashboard" className="text-xs sm:text-sm">Dashboard</TabsTrigger>
              <TabsTrigger value="metrics" className="text-xs sm:text-sm">Métricas</TabsTrigger>
              <TabsTrigger value="projects" className="text-xs sm:text-sm">Proyectos</TabsTrigger>
              <TabsTrigger value="copilot" className="text-xs sm:text-sm">Co-piloto</TabsTrigger>
              <TabsTrigger value="content" className="text-xs sm:text-sm">Contenido</TabsTrigger>
              <TabsTrigger value="integrations" className="text-xs sm:text-sm">Integr.</TabsTrigger>
              <TabsTrigger value="marketing" className="text-xs sm:text-sm">Marketing</TabsTrigger>
              <TabsTrigger value="config" className="text-xs sm:text-sm">Config</TabsTrigger>
            </TabsList>
          </div>

          {/* Dashboard Tab - Responsive */}
          <TabsContent value="dashboard" className="space-y-6 sm:space-y-8">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-3 sm:gap-6">
              <Card className="bg-white rounded-xl shadow-sm">
                <CardHeader className="pb-2 sm:pb-3">
                  <CardTitle className="flex items-center text-emerald-600 text-sm sm:text-base font-medium">
                    <Users className="w-4 h-4 sm:w-5 sm:h-5 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Leads Generados</span>
                    <span className="sm:hidden">Leads</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="text-xl sm:text-2xl font-bold text-gray-800">
                    {metrics?.kpis?.totalLeads ?? '0'}
                  </div>
                  <p className="text-gray-500 text-xs sm:text-sm">Total histórico</p>
                </CardContent>
              </Card>

              <Card className="bg-white rounded-xl shadow-sm">
                <CardHeader className="pb-2 sm:pb-3">
                  <CardTitle className="flex items-center text-blue-600 text-sm sm:text-base font-medium">
                    <TrendingUp className="w-4 h-4 sm:w-5 sm:h-5 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Leads este mes</span>
                    <span className="sm:hidden">Mes</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="text-xl sm:text-2xl font-bold text-gray-800">
                    {metrics?.kpis?.thisMonthLeads ?? '0'}
                  </div>
                  <p className="text-gray-500 text-xs sm:text-sm">Nuevos prospectos</p>
                </CardContent>
              </Card>

              <Card className="bg-white rounded-xl shadow-sm">
                <CardHeader className="pb-2 sm:pb-3">
                  <CardTitle className="flex items-center text-purple-600 text-sm sm:text-base font-medium">
                    <MessageCircle className="w-4 h-4 sm:w-5 sm:h-5 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Interacciones IA</span>
                    <span className="sm:hidden">IA</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="text-xl sm:text-2xl font-bold text-gray-800">
                    {metrics?.kpis?.totalInteractions ?? '0'}
                  </div>
                  <p className="text-gray-500 text-xs sm:text-sm">Chats completados</p>
                </CardContent>
              </Card>

              <Card className="bg-white rounded-xl shadow-sm">
                <CardHeader className="pb-2 sm:pb-3">
                  <CardTitle className="flex items-center text-yellow-600 text-sm sm:text-base font-medium">
                    <Zap className="w-4 h-4 sm:w-5 sm:h-5 mr-1 sm:mr-2" />
                    <span className="hidden sm:inline">Conversión</span>
                    <span className="sm:hidden">Conv</span>
                  </CardTitle>
                </CardHeader>
                <CardContent className="pt-0">
                  <div className="text-xl sm:text-2xl font-bold text-gray-800">
                    {metrics?.kpis?.chatToLeadConversion ?? '0'}%
                  </div>
                  <p className="text-gray-500 text-xs sm:text-sm">Chat a lead</p>
                </CardContent>
              </Card>
            </div>

            {/* Quick Actions Section (updated to include QuickClientActivation) */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-8 mb-6 sm:mb-8">
              <QuickClientActivation />

              <Card className="bg-white rounded-xl shadow-sm">
                <CardHeader>
                  <CardTitle className="text-gray-800 text-lg sm:text-xl">Acciones Rápidas</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3">
                  <a
                    href="https://app.hubspot.com/contacts/50203416/contacts/list/view/all/"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button className="w-full bg-orange-500 hover:bg-orange-600 text-white text-sm sm:text-base">
                      Ver Contactos en HubSpot
                    </Button>
                  </a>
                  <a
                    href="https://meetings.hubspot.com/jjdlr/simiriki-consulta"
                    target="_blank"
                    rel="noopener noreferrer"
                  >
                    <Button className="w-full bg-blue-500 hover:bg-blue-600 text-white text-sm sm:text-base">
                      Ver Calendario
                    </Button>
                  </a>
                  <Button
                    onClick={() => setActiveTab("copilot")}
                    className="w-full bg-emerald-600 hover:bg-emerald-700 text-white text-sm sm:text-base"
                  >
                    Usar Co-piloto IA
                  </Button>
                </CardContent>
              </Card>
            </div>

            {/* Responsive grid para actividad y estado */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 sm:gap-8">
              <Card className="bg-white rounded-xl shadow-sm">
                <CardHeader>
                  <CardTitle className="text-gray-800 text-lg sm:text-xl">Actividad Reciente</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2 text-sm text-gray-600">
                    <div>• Nuevo lead: maría@empresa.com</div>
                    <div>• Chat completado: carlos@tienda.mx</div>
                    <div>• Consulta agendada: ana@consultores.com</div>
                    <div>• Lead calificado: roberto@tech.mx</div>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-white rounded-xl shadow-sm">
                <CardHeader>
                  <CardTitle className="text-gray-800 text-lg sm:text-xl">Estado del Sistema</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 text-sm sm:text-base">Asistente IA</span>
                      <Badge className="bg-green-100 text-green-800 text-xs sm:text-sm">Activo</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 text-sm sm:text-base">HubSpot Sync</span>
                      <Badge className="bg-green-100 text-green-800 text-xs sm:text-sm">Conectado</Badge>
                    </div>
                    <div className="flex justify-between items-center">
                      <span className="text-gray-600 text-sm sm:text-base">Chat Widget</span>
                      <Badge className="bg-green-100 text-green-800 text-xs sm:text-sm">Funcionando</Badge>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* METRICS TAB */}
          <TabsContent value="metrics" className="space-y-6 sm:space-y-8">
            {metrics ? (
              <>
                {/* KPIs */}
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <KPICard title="Total Leads Generados" value={metrics.kpis.totalLeads} icon={Users} color="blue" />
                  <KPICard title="Conversión (Lead a Cliente)" value={`${metrics.kpis.conversionRate}%`} icon={TrendingUpIcon} color="green" />
                  <KPICard title="Valor Total de Proyectos" value={`$${metrics.kpis.totalProjectValue.toLocaleString()}`} icon={DollarSign} color="emerald" />
                  <KPICard title="Emails Abiertos" value={metrics.kpis.totalEmailsOpened.toLocaleString()} icon={Mail} color="purple" />
                </div>
                
                <div className="grid grid-cols-1 lg:grid-cols-5 gap-6">
                  {/* Leads Over Time Chart */}
                  <Card className="lg:col-span-3 bg-white rounded-xl shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-gray-800">Generación de Leads por Mes</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ResponsiveContainer width="100%" height={300}>
                        <BarChart data={metrics.leadsOverTime}>
                          <CartesianGrid strokeDasharray="3 3" />
                          <XAxis dataKey="name" />
                          <YAxis />
                          <Tooltip />
                          <Legend />
                          <Bar dataKey="leads" fill="#10B981" name="Nuevos Leads" />
                        </BarChart>
                      </ResponsiveContainer>
                    </CardContent>
                  </Card>
                  
                  {/* Conversion Funnel */}
                  <Card className="lg:col-span-2 bg-white rounded-xl shadow-sm">
                    <CardHeader>
                      <CardTitle className="text-gray-800">Embudo de Conversión</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <ConversionFunnel data={metrics.funnel} />
                    </CardContent>
                  </Card>
                </div>
              </>
            ) : (
              <div className="flex items-center justify-center min-h-[300px]">
                <Loader className="w-8 h-8 animate-spin text-blue-500" />
              </div>
            )}
          </TabsContent>

          {/* Projects Tab */}
          <TabsContent value="projects" className="space-y-6 sm:space-y-8">
            <ProjectManager projects={projects} />
          </TabsContent>

          {/* Co-piloto Tab */}
          <TabsContent value="copilot" className="space-y-6 sm:space-y-8">
            <SolutionCopilot />
          </TabsContent>

          {/* Content Management Tab */}
          <TabsContent value="content" className="space-y-6 sm:space-y-8">
            <ContentManager />
          </TabsContent>

          {/* Marketing Automation Tab */}
          <TabsContent value="marketing" className="space-y-6 sm:space-y-8">
            <MarketingAutomationManager />
          </TabsContent>

          {/* Other tabs */}
          <TabsContent value="integrations">
            <Card className="bg-white rounded-xl shadow-sm">
              <CardHeader>
                <CardTitle className="text-gray-800">Integraciones Configuradas</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border">
                    <div>
                      <div className="text-gray-800 font-medium">HubSpot CRM</div>
                      <div className="text-gray-500 text-sm">Portal ID: 50203416</div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Conectado</Badge>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border">
                    <div>
                      <div className="text-gray-800 font-medium">OpenAI GPT-4</div>
                      <div className="text-gray-500 text-sm">Para Asistente IA</div>
                    </div>
                    <Badge className="bg-green-100 text-green-800">Activo</Badge>
                  </div>
                  <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border">
                    <div>
                      <div className="text-gray-800 font-medium">Google Analytics</div>
                      <div className="text-gray-500 text-sm">Tracking y métricas</div>
                    </div>
                    <Badge className="bg-yellow-100 text-yellow-800">Configurando</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="config">
            <Card className="bg-white rounded-xl shadow-sm">
              <CardHeader>
                <CardTitle className="text-gray-800">Configuración General</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div>
                    <Label className="text-gray-700">Nombre de la Empresa</Label>
                    <Input
                      defaultValue="Simiriki"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-700">Teléfono de Contacto</Label>
                    <Input
                      defaultValue="+52 813 467 5514"
                      className="mt-2"
                    />
                  </div>
                  <div>
                    <Label className="text-gray-700">Email de Contacto</Label>
                    <Input
                      defaultValue="jjdlr@simiriki.com"
                      className="mt-2"
                    />
                  </div>
                  <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
                    <Save className="w-4 h-4 mr-2" />
                    Guardar Cambios
                  </Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

// --- SUB-COMPONENTS FOR METRICS ---

function KPICard({ title, value, icon: Icon, color }) {
    const colors = {
        blue: "text-blue-600 bg-blue-100",
        green: "text-green-600 bg-green-100",
        emerald: "text-emerald-600 bg-emerald-100",
        purple: "text-purple-600 bg-purple-100",
    }
    return (
        <Card className="bg-white rounded-xl shadow-sm">
            <CardContent className="p-4">
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${colors[color]}`}>
                    <Icon className="w-6 h-6" />
                </div>
                <p className="text-gray-500 text-sm mb-1">{title}</p>
                <p className="text-2xl font-bold text-gray-800">{value}</p>
            </CardContent>
        </Card>
    );
}

function ConversionFunnel({ data }) {
    const funnelSteps = [
        { name: 'Visitantes', value: data.visitors, color: '#3b82f6' },
        { name: 'Leads', value: data.leads, color: '#8b5cf6' },
        { name: 'Proyectos', value: data.projects, color: '#10b981' },
        { name: 'Completados', value: data.completed_projects, color: '#f59e0b' },
    ];

    const calculateConversion = (from, to) => {
        if (from === 0) return '0%';
        return `${((to / from) * 100).toFixed(1)}%`;
    };

    return (
        <div className="space-y-2">
            {funnelSteps.map((step, index) => (
                <div key={step.name}>
                    <div className="flex justify-between items-center mb-1">
                        <span className="font-medium text-gray-700">{step.name}</span>
                        <span className="font-bold text-gray-800">{step.value.toLocaleString()}</span>
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-4">
                        <div
                            className="h-4 rounded-full"
                            style={{ 
                                width: `${index === 0 ? 100 : (step.value / funnelSteps[index - 1].value) * 100}%`, 
                                backgroundColor: step.color 
                            }}
                        ></div>
                    </div>
                    {index < funnelSteps.length - 1 && (
                        <div className="text-right text-xs text-gray-500 mt-1">
                            Conversión: {calculateConversion(step.value, funnelSteps[index + 1].value)}
                        </div>
                    )}
                </div>
            ))}
        </div>
    );
}


// Co-piloto de Soluciones Component
function SolutionCopilot() {
  const [problemDescription, setProblemDescription] = useState('');
  const [isGenerating, setIsGenerating] = useState(false);
  const [generatedSolution, setGeneratedSolution] = useState(null);
  const [savedSolutions, setSavedSolutions] = useState(() => {
    try {
      const stored = localStorage.getItem('simiriki_saved_solutions');
      return stored ? JSON.parse(stored) : [];
    } catch (e) {
      console.error("Failed to parse saved solutions from localStorage", e);
      return [];
    }
  });

  useEffect(() => {
    localStorage.setItem('simiriki_saved_solutions', JSON.stringify(savedSolutions));
  }, [savedSolutions]);

  const generateSolution = async () => {
    if (!problemDescription.trim()) {
      alert("Por favor, describe el problema para generar una solución.");
      return;
    }

    setIsGenerating(true);
    setGeneratedSolution(null);
    try {
      const response = await InvokeLLM({
        prompt: `Actúas como un arquitecto de software experto en automatización para PYMEs.

        PROBLEMA DEL CLIENTE: "${problemDescription}"

        Tu tarea es crear un PLANO TÉCNICO COMPLETO para resolver este problema usando una aplicación web con las siguientes tecnologías:
        - Base de datos (entidades)
        - Páginas web (interfaz de usuario)
        - Automatizaciones (flujos de trabajo)

        Genera una respuesta en JSON con esta estructura EXACTA:

        - solution_name: Nombre descriptivo de la solución (ej: "Sistema de Seguimiento de Reparaciones")
        - problem_summary: Resumen del problema en 1 línea
        - estimated_impact: Beneficio esperado (ej: "Ahorro de 15 horas/semana")
        - entities: Array de objetos con name, description, y properties
        - pages: Array de objetos con name, description, user_type ("public" o "admin"), y functionality
        - automations: Array de objetos con name, trigger, action, y benefit
        - implementation_time: Tiempo estimado de desarrollo (ej: "2-3 semanas")
        - monthly_value: Valor mensual estimado para el cliente (ej: "$2,500 USD")

        Sé específico, práctico y enfócate en resolver el problema real del cliente.`,
        response_json_schema: {
          type: "object",
          properties: {
            solution_name: { type: "string" },
            problem_summary: { type: "string" },
            estimated_impact: { type: "string" },
            entities: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  description: { type: "string" },
                  properties: { type: "object" }
                }
              }
            },
            pages: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  description: { type: "string" },
                  user_type: { type: "string" },
                  functionality: { type: "string" }
                }
              }
            },
            automations: {
              type: "array",
              items: {
                type: "object",
                properties: {
                  name: { type: "string" },
                  trigger: { type: "string" },
                  action: { type: "string" },
                  benefit: { type: "string" }
                }
              }
            },
            implementation_time: { type: "string" },
            monthly_value: { type: "string" }
          }
        }
      });

      setGeneratedSolution(response);
    } catch (error) {
      console.error("Error generating solution:", error);
      alert("Error al generar la solución. Por favor, inténtalo de nuevo.");
    }
    setIsGenerating(false);
  };

  const saveSolution = () => {
    if (generatedSolution) {
      const newSolution = {
        ...generatedSolution,
        id: Date.now(),
        created_at: new Date().toISOString(),
        original_problem: problemDescription
      };
      setSavedSolutions(prev => [newSolution, ...prev]);
      alert("¡Solución guardada! Ahora puedes implementarla con base44.");
    }
  };

  return (
    <div className="space-y-8">
      <Card className="bg-white border border-gray-200 rounded-xl shadow-sm">
        <CardHeader>
          <CardTitle className="flex items-center text-orange-600">
            <Sparkles className="w-6 h-6 mr-3" />
            Co-piloto de Soluciones IA
          </CardTitle>
          <CardDescription>
            Describe cualquier problema de negocio y obtén un plano técnico completo para solucionarlo.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="problem-description" className="text-gray-700">Describe el problema del cliente:</Label>
            <textarea
              id="problem-description"
              value={problemDescription}
              onChange={(e) => setProblemDescription(e.target.value)}
              placeholder="Ej: Soy dueño de un taller mecánico y pierdo mucho tiempo porque los clientes llaman constantemente para preguntar el estado de su coche..."
              className="w-full h-32 p-4 border border-gray-300 rounded-lg placeholder:text-gray-400 resize-none"
            />
          </div>

          <Button
            onClick={generateSolution}
            disabled={isGenerating || !problemDescription.trim()}
            className="bg-orange-600 hover:bg-orange-700 text-white w-full"
          >
            {isGenerating ? (
              <>
                <Loader className="w-4 h-4 mr-2 animate-spin" />
                Generando Plano Técnico...
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4 mr-2" />
                Generar Solución
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Generated Solution Display */}
      {generatedSolution && (
        <Card className="bg-white border border-gray-200 rounded-xl shadow-sm">
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle className="text-emerald-600">{generatedSolution.solution_name}</CardTitle>
                <CardDescription>{generatedSolution.problem_summary}</CardDescription>
              </div>
              <Button onClick={saveSolution} className="bg-emerald-100 text-emerald-800 hover:bg-emerald-200">
                <Save className="w-4 h-4 mr-2" />
                Guardar Solución
              </Button>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Impact & Value */}
            <div className="grid md:grid-cols-3 gap-4">
              <div className="bg-blue-50 p-4 rounded-lg border border-blue-200">
                <div className="text-blue-600 font-semibold">Impacto Estimado</div>
                <div className="text-gray-800">{generatedSolution.estimated_impact}</div>
              </div>
              <div className="bg-green-50 p-4 rounded-lg border border-green-200">
                <div className="text-green-600 font-semibold">Valor Mensual</div>
                <div className="text-gray-800">{generatedSolution.monthly_value}</div>
              </div>
              <div className="bg-purple-50 p-4 rounded-lg border border-purple-200">
                <div className="text-purple-600 font-semibold">Tiempo de Desarrollo</div>
                <div className="text-gray-800">{generatedSolution.implementation_time}</div>
              </div>
            </div>

            {/* Entities */}
            <div>
              <h3 className="text-gray-800 font-semibold mb-3">📊 Entidades (Base de Datos)</h3>
              <div className="space-y-3">
                {generatedSolution.entities.map((entity, idx) => (
                  <div key={idx} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="text-emerald-700 font-medium">{entity.name}</div>
                    <div className="text-gray-600 text-sm">{entity.description}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Pages */}
            <div>
              <h3 className="text-gray-800 font-semibold mb-3">🖥️ Páginas (Interfaz)</h3>
              <div className="grid md:grid-cols-2 gap-3">
                {generatedSolution.pages.map((page, idx) => (
                  <div key={idx} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-blue-700 font-medium">{page.name}</div>
                      <Badge className={`text-xs ${page.user_type === 'admin' ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}`}>
                        {page.user_type === 'admin' ? 'Admin' : 'Público'}
                      </Badge>
                    </div>
                    <div className="text-gray-600 text-sm">{page.description}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Automations */}
            <div>
              <h3 className="text-gray-800 font-semibold mb-3">⚡ Automatizaciones</h3>
              <div className="space-y-3">
                {generatedSolution.automations.map((auto, idx) => (
                  <div key={idx} className="bg-gray-50 p-4 rounded-lg border">
                    <div className="text-purple-700 font-medium">{auto.name}</div>
                    <div className="text-gray-600 text-sm">
                      <strong>Trigger:</strong> {auto.trigger}
                    </div>
                    <div className="text-gray-600 text-sm">
                      <strong>Acción:</strong> {auto.action}
                    </div>
                    <div className="text-emerald-700 text-sm font-medium">
                      💡 {auto.benefit}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Saved Solutions */}
      {savedSolutions.length > 0 && (
        <Card className="bg-white border border-gray-200 rounded-xl shadow-sm">
          <CardHeader>
            <CardTitle className="text-gray-800">Soluciones Guardadas</CardTitle>
            <CardDescription>Tu biblioteca de planos técnicos</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {savedSolutions.map((solution) => (
                <div key={solution.id} className="bg-gray-50 p-4 rounded-lg border flex justify-between items-center">
                  <div>
                    <div className="text-gray-800 font-medium">{solution.solution_name}</div>
                    <div className="text-gray-500 text-sm">{solution.estimated_impact}</div>
                    <div className="text-xs text-gray-400">{new Date(solution.created_at).toLocaleDateString()}</div>
                  </div>
                  <div className="text-emerald-600 font-bold">{solution.monthly_value}</div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

// Content Manager Component
function ContentManager() {
  const [testimonials, setTestimonials] = useState([]);
  const [editingTestimonial, setEditingTestimonial] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [videoSettings, setVideoSettings] = useState({
    url: '',
    thumbnail: '',
    title: 'Ve cómo María aumentó sus ventas 340%',
    description: 'Video testimonial - 2 minutos'
  });

  useEffect(() => {
    loadTestimonials();
    loadVideoSettings();
  }, []);

  const loadTestimonials = async () => {
    try {
      const data = await Testimonial.list('-created_date', 50);
      setTestimonials(data);
    } catch (error) {
      console.error("Error loading testimonials:", error);
    }
    setIsLoading(false);
  };

  const loadVideoSettings = () => {
    // Load from localStorage or use defaults
    const saved = localStorage.getItem('simiriki_video_settings');
    if (saved) {
      try {
        setVideoSettings(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse video settings");
      }
    }
  };

  const saveVideoSettings = () => {
    localStorage.setItem('simiriki_video_settings', JSON.stringify(videoSettings));
    alert("Configuración de video guardada. Los cambios se verán reflejados en el sitio.");
  };

  const handleSaveTestimonial = async (testimonialData) => {
    try {
      if (editingTestimonial) {
        await Testimonial.update(editingTestimonial.id, testimonialData);
      } else {
        await Testimonial.create(testimonialData);
      }
      loadTestimonials();
      setShowForm(false);
      setEditingTestimonial(null);
    } catch (error) {
      console.error("Error saving testimonial:", error);
      alert("Error al guardar el testimonio");
    }
  };

  const handleDeleteTestimonial = async (id) => {
    if (confirm("¿Estás seguro de que quieres eliminar este testimonio?")) {
      try {
        await Testimonial.delete(id);
        loadTestimonials();
      } catch (error) {
        console.error("Error deleting testimonial:", error);
        alert("Error al eliminar el testimonio");
      }
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center py-8">
        <Loader className="w-8 h-8 animate-spin text-emerald-500" />
      </div>
    );
  }

  return (
    <div className="space-y-8">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold text-gray-800">Gestión de Videos y Testimonios</h2>
          <p className="text-gray-500">Controla todo el contenido que aparece en tu sitio web</p>
        </div>
        <Button
          onClick={() => {
            setEditingTestimonial(null);
            setShowForm(true);
          }}
          className="bg-emerald-600 text-white hover:bg-emerald-700"
        >
          <Plus className="w-4 h-4 mr-2" />
          Agregar Testimonio
        </Button>
      </div>

      {/* Video Section */}
      <Card className="bg-white rounded-xl shadow-sm">
        <CardHeader>
          <CardTitle className="text-gray-800 flex items-center">
            <Play className="w-5 h-5 mr-2 text-blue-600" />
            Video Principal del Hero
          </CardTitle>
          <CardDescription>
            El video que aparece en la página principal junto al testimonio de María Elena
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label className="text-gray-700">URL del Video (YouTube, Vimeo, o archivo directo)</Label>
            <Input
              value={videoSettings.url}
              onChange={(e) => setVideoSettings({...videoSettings, url: e.target.value})}
              placeholder="https://www.youtube.com/watch?v=..."
              className="mt-2"
            />
          </div>
          <div>
            <Label className="text-gray-700">Imagen de Portada (Thumbnail)</Label>
            <Input
              value={videoSettings.thumbnail}
              onChange={(e) => setVideoSettings({...videoSettings, thumbnail: e.target.value})}
              placeholder="https://..."
              className="mt-2"
            />
          </div>
          <div>
            <Label className="text-gray-700">Título del Video</Label>
            <Input
              value={videoSettings.title}
              onChange={(e) => setVideoSettings({...videoSettings, title: e.target.value})}
              className="mt-2"
            />
          </div>
          <div>
            <Label className="text-gray-700">Descripción</Label>
            <Input
              value={videoSettings.description}
              onChange={(e) => setVideoSettings({...videoSettings, description: e.target.value})}
              className="mt-2"
            />
          </div>
          <Button onClick={saveVideoSettings} className="bg-blue-600 hover:bg-blue-700 text-white">
            <Save className="w-4 h-4 mr-2" />
            Actualizar Video
          </Button>
        </CardContent>
      </Card>

      {/* Testimonial Form */}
      {showForm && (
        <Card className="bg-white rounded-xl shadow-sm">
          <CardHeader>
            <CardTitle className="text-gray-800">
              {editingTestimonial ? 'Editar Testimonio' : 'Nuevo Testimonio'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            <TestimonialForm
              testimonial={editingTestimonial}
              onSave={handleSaveTestimonial}
              onCancel={() => {
                setShowForm(false);
                setEditingTestimonial(null);
              }}
            />
          </CardContent>
        </Card>
      )}

      {/* Testimonials List */}
      <Card className="bg-white rounded-xl shadow-sm">
        <CardHeader>
          <CardTitle className="text-gray-800">Testimonios Existentes</CardTitle>
          <CardDescription>
            Gestiona todos los testimonios que aparecen en tu sitio
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {testimonials.length === 0 ? (
              <div className="text-gray-500 text-center py-8">
                <p>No hay testimonios guardados aún.</p>
                <Button
                  onClick={() => setShowForm(true)}
                  className="mt-4 bg-emerald-600 hover:bg-emerald-700 text-white"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Crear Primer Testimonio
                </Button>
              </div>
            ) : (
              testimonials.map((testimonial) => (
                <div key={testimonial.id} className="bg-gray-50 p-4 rounded-lg border">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <div className="text-gray-800 font-semibold">{testimonial.client_name}</div>
                        <Badge className={testimonial.featured ? 'bg-yellow-100 text-yellow-800' : 'bg-gray-100 text-gray-800'}>
                          {testimonial.featured ? 'Destacado' : 'Normal'}
                        </Badge>
                        <Badge className={testimonial.status === 'active' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}>
                          {testimonial.status === 'active' ? 'Activo' : 'Inactivo'}
                        </Badge>
                      </div>
                      <div className="text-gray-500 text-sm mb-1">{testimonial.client_title} - {testimonial.company}</div>
                      <div className="text-gray-600 text-sm mb-2">"{testimonial.testimonial}"</div>
                      {testimonial.results_achieved && (
                        <div className="text-emerald-600 text-sm">📈 {testimonial.results_achieved}</div>
                      )}
                    </div>
                    <div className="flex space-x-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setEditingTestimonial(testimonial);
                          setShowForm(true);
                        }}
                        className="text-blue-600 border-blue-300 hover:bg-blue-50"
                      >
                        <Pencil className="w-4 h-4" />
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleDeleteTestimonial(testimonial.id)}
                        className="text-red-600 border-red-300 hover:bg-red-50"
                      >
                        <Trash2 className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

// Testimonial Form Component
function TestimonialForm({ testimonial, onSave, onCancel }) {
  const [formData, setFormData] = useState({
    client_name: '',
    client_title: '',
    company: '',
    testimonial: '',
    rating: 5,
    avatar_url: '',
    industry: 'services',
    results_achieved: '',
    featured: false,
    status: 'active',
    ...(testimonial || {})
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <Label className="text-gray-700">Nombre del Cliente *</Label>
          <Input
            value={formData.client_name}
            onChange={(e) => setFormData({...formData, client_name: e.target.value})}
            className="mt-2"
            required
          />
        </div>
        <div>
          <Label className="text-gray-700">Cargo/Título</Label>
          <Input
            value={formData.client_title}
            onChange={(e) => setFormData({...formData, client_title: e.target.value})}
            className="mt-2"
          />
        </div>
      </div>

      <div className="grid md:grid-cols-2 gap-4">
        <div>
          <Label className="text-gray-700">Empresa *</Label>
          <Input
            value={formData.company}
            onChange={(e) => setFormData({...formData, company: e.target.value})}
            className="mt-2"
            required
          />
        </div>
        <div>
          <Label className="text-gray-700">Industria</Label>
          <select
            value={formData.industry}
            onChange={(e) => setFormData({...formData, industry: e.target.value})}
            className="w-full p-2 mt-2 border border-gray-300 rounded-md"
          >
            <option value="retail">Retail</option>
            <option value="manufacturing">Manufactura</option>
            <option value="services">Servicios</option>
            <option value="technology">Tecnología</option>
            <option value="healthcare">Salud</option>
            <option value="finance">Finanzas</option>
            <option value="education">Educación</option>
            <option value="other">Otro</option>
          </select>
        </div>
      </div>

      <div>
        <Label className="text-gray-700">Testimonio *</Label>
        <textarea
          value={formData.testimonial}
          onChange={(e) => setFormData({...formData, testimonial: e.target.value})}
          className="w-full h-24 p-3 mt-2 border border-gray-300 rounded-md resize-none"
          required
        />
      </div>

      <div>
        <Label className="text-gray-700">Resultados Específicos (opcional)</Label>
        <Input
          value={formData.results_achieved}
          onChange={(e) => setFormData({...formData, results_achieved: e.target.value})}
          placeholder="Ej: Aumentó ventas 340% en 90 días"
          className="mt-2"
        />
      </div>

      <div className="grid md:grid-cols-3 gap-4">
        <div>
          <Label className="text-gray-700">Rating (1-5 estrellas)</Label>
          <Input
            type="number"
            min="1"
            max="5"
            value={formData.rating}
            onChange={(e) => setFormData({...formData, rating: parseInt(e.target.value)})}
            className="mt-2"
          />
        </div>
        <div className="flex items-center space-x-2 mt-6">
          <input
            type="checkbox"
            id="featured"
            checked={formData.featured}
            onChange={(e) => setFormData({...formData, featured: e.target.checked})}
            className="rounded"
          />
          <Label htmlFor="featured" className="text-gray-700">Testimonio Destacado</Label>
        </div>
        <div className="flex items-center space-x-2 mt-6">
          <input
            type="checkbox"
            id="active"
            checked={formData.status === 'active'}
            onChange={(e) => setFormData({...formData, status: e.target.checked ? 'active' : 'inactive'})}
            className="rounded"
          />
          <Label htmlFor="active" className="text-gray-700">Mostrar en sitio</Label>
        </div>
      </div>

      <div>
        <Label className="text-gray-700">URL de Avatar (opcional)</Label>
        <Input
          value={formData.avatar_url}
          onChange={(e) => setFormData({...formData, avatar_url: e.target.value})}
          placeholder="https://..."
          className="mt-2"
        />
      </div>

      <div className="flex space-x-3 pt-4">
        <Button type="submit" className="bg-emerald-600 hover:bg-emerald-700 text-white">
          <Save className="w-4 h-4 mr-2" />
          {testimonial ? 'Actualizar' : 'Crear'} Testimonio
        </Button>
        <Button type="button" variant="outline" onClick={onCancel}>
          Cancelar
        </Button>
      </div>
    </form>
  );
}

// NEW: Placeholder for Project Management Component
function ProjectManagement() {
  return (
    <Card className="bg-white rounded-xl shadow-sm">
      <CardHeader>
        <CardTitle className="text-gray-800 flex items-center">
          <Settings className="w-5 h-5 mr-2 text-indigo-600" />
          Gestión Avanzada de Proyectos (Próximamente)
        </CardTitle>
        <CardDescription>
          Aquí podrás configurar flujos de trabajo, asignar roles detallados y supervisar el progreso de cada proyecto con mayor granularidad.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="text-gray-600 space-y-2">
          <p>Esta sección estará disponible en futuras actualizaciones.</p>
          <p>Imagina funciones como:</p>
          <ul className="list-disc list-inside ml-4">
            <li>Creación de plantillas de proyectos.</li>
            <li>Gestión de tareas y subtareas.</li>
            <li>Seguimiento de tiempos.</li>
            <li>Generación de informes de rendimiento.</li>
            <li>Integración con herramientas de gestión de código o diseño.</li>
          </ul>
        </div>
        <div className="mt-6">
          <Button disabled className="bg-indigo-500 text-white">
            Más Funcionalidades Próximamente
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}

// NEW: Placeholder for Client Communication Hub Component
function ClientCommunicationHub() {
  const [message, setMessage] = useState('');
  const [history, setHistory] = useState([]);
  const [isSending, setIsSending] = useState(false);

  const sendMessage = async () => {
    if (!message.trim()) return;

    const newMessage = { id: Date.now(), text: message, sender: 'You', type: 'sent' };
    setHistory((prev) => [...prev, newMessage]);
    setMessage('');
    setIsSending(true);

    try {
      // Simulate API call for sending/receiving messages
      await new Promise(resolve => setTimeout(resolve, 1500));
      const aiResponse = { 
        id: Date.now() + 1, 
        text: `Recibido: "${newMessage.text}". Estoy procesando tu consulta y te responderé pronto.`, 
        sender: 'AI Assistant', 
        type: 'received' 
      };
      setHistory((prev) => [...prev, aiResponse]);
    } catch (error) {
      console.error("Error sending message:", error);
      setHistory((prev) => [...prev, { id: Date.now(), text: 'Error al enviar mensaje.', sender: 'System', type: 'error' }]);
    } finally {
      setIsSending(false);
    }
  };

  return (
    <Card className="bg-white rounded-xl shadow-sm">
      <CardHeader>
        <CardTitle className="text-gray-800 flex items-center">
          <MessageSquare className="w-5 h-5 mr-2 text-emerald-600" />
          Centro de Comunicación con Clientes
        </CardTitle>
        <CardDescription>
          Gestiona y automatiza las interacciones con tus clientes desde un solo lugar.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="space-y-6">
          {/* Communication Channels */}
          <div>
            <h3 className="text-gray-800 font-semibold mb-3">Canales de Comunicación</h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-gray-50 p-4 rounded-lg border flex items-center justify-between">
                <div>
                  <div className="font-medium">Correo Electrónico</div>
                  <div className="text-gray-500 text-sm">Notificaciones y campañas</div>
                </div>
                <Badge className="bg-green-100 text-green-800">Conectado</Badge>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg border flex items-center justify-between">
                <div>
                  <div className="font-medium">WhatsApp (Vía API)</div>
                  <div className="text-gray-500 text-sm">Mensajería instantánea</div>
                </div>
                <Badge className="bg-yellow-100 text-yellow-800">Configurando</Badge>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg border flex items-center justify-between">
                <div>
                  <div className="font-medium">Chat Web (Widget)</div>
                  <div className="text-gray-500 text-sm">Soporte en tiempo real</div>
                </div>
                <Badge className="bg-green-100 text-green-800">Activo</Badge>
              </div>
              <div className="bg-gray-50 p-4 rounded-lg border flex items-center justify-between">
                <div>
                  <div className="font-medium">SMS</div>
                  <div className="text-gray-500 text-sm">Recordatorios y alertas</div>
                </div>
                <Badge className="bg-gray-100 text-gray-800">No Activo</Badge>
              </div>
            </div>
          </div>

          {/* AI Assistant for Communication */}
          <div>
            <h3 className="text-gray-800 font-semibold mb-3 flex items-center">
              <Sparkles className="w-5 h-5 mr-2 text-orange-600" />
              Asistente de Comunicación IA
            </h3>
            <CardDescription className="mb-4">
              Responde automáticamente preguntas frecuentes, califica leads y gestiona tickets de soporte.
            </CardDescription>
            <div className="border rounded-lg p-4 bg-gray-50 h-64 overflow-y-auto flex flex-col-reverse">
                {history.slice().reverse().map((msg) => (
                    <div key={msg.id} className={`flex ${msg.type === 'sent' ? 'justify-end' : 'justify-start'} mb-2`}>
                        <div className={`p-2 rounded-lg max-w-[70%] ${msg.type === 'sent' ? 'bg-blue-500 text-white' : 'bg-gray-200 text-gray-800'}`}>
                            <strong>{msg.sender}:</strong> {msg.text}
                        </div>
                    </div>
                ))}
                {history.length === 0 && (
                    <div className="text-gray-500 text-center flex-grow flex items-center justify-center">
                        Inicia una conversación con el asistente.
                    </div>
                )}
            </div>
            <div className="flex mt-4 space-x-2">
              <Input
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                placeholder="Escribe un mensaje para el asistente..."
                className="flex-grow"
                onKeyPress={(e) => {
                    if (e.key === 'Enter' && !isSending) {
                        sendMessage();
                    }
                }}
              />
              <Button onClick={sendMessage} disabled={isSending || !message.trim()} className="bg-emerald-600 hover:bg-emerald-700 text-white">
                {isSending ? (
                  <Loader className="w-4 h-4 animate-spin" />
                ) : (
                  <MessageSquare className="w-4 h-4" />
                )}
              </Button>
            </div>
            <p className="text-xs text-gray-500 mt-2">
              Este chat es una simulación del asistente IA. El asistente real se integra directamente con tus canales.
            </p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
