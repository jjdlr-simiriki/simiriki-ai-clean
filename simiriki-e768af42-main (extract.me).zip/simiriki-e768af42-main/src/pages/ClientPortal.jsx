
import React, { useState, useEffect } from 'react';
import { User } from '@/api/entities';
import { Project } from '@/api/entities';
import { 
  Loader, 
  AlertTriangle, 
  ArrowLeft, 
  CheckCircle, 
  XCircle, 
  MessageSquare, // Added for messages tab
  FolderOpen,    // Added for files tab
  LayoutDashboard, // Added for overview tab icon
  GanttChart     // Added for milestones tab icon
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { createStripeCheckout } from '@/api/functions';
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"; // Added Tabs components

import ProjectOverview from '../components/client-portal/ProjectOverview';
import MilestoneTracker from '../components/client-portal/MilestoneTracker';
import MessageCenter from '../components/client-portal/MessageCenter';
import FileManager from '../components/client-portal/FileManager';

export default function ClientPortal() {
  const [user, setUser] = useState(null);
  const [project, setProject] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState(null);
  const [isProcessingPayment, setIsProcessingPayment] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState(null);
  // New state to manage active tab, default to 'overview'
  const [activeTab, setActiveTab] = useState('overview'); 

  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    const fetchPortalData = async () => {
      try {
        const currentUser = await User.me();
        setUser(currentUser);

        // Buscar el proyecto asociado al email del cliente
        const userProjects = await Project.filter({ client_email: currentUser.email }, '-created_date', 1);
        
        if (userProjects.length > 0) {
          setProject(userProjects[0]);
        } else {
          setError("No se encontró un proyecto activo para tu cuenta. Si crees que esto es un error, por favor contacta a soporte.");
        }
      } catch (e) {
        // Error if user is not logged in, redirect to Home
        window.location.href = createPageUrl('Home');
        return;
      }
      setIsLoading(false);
    };

    fetchPortalData();

    // Check for payment status from URL
    const urlParams = new URLSearchParams(location.search);
    if (urlParams.get('payment') === 'success') {
      setPaymentStatus({ type: 'success', message: '¡Pago completado exitosamente! Tu proyecto ha sido actualizado.' });
      // If payment was successful, navigate to the overview tab
      setActiveTab('overview');
      // Clean URL
      navigate(location.pathname, { replace: true });
    } else if (urlParams.get('payment') === 'cancelled') {
      setPaymentStatus({ type: 'cancelled', message: 'El proceso de pago fue cancelado.' });
      // If payment was cancelled, navigate to the overview tab
      setActiveTab('overview');
      // Clean URL
      navigate(location.pathname, { replace: true });
    }
  }, [location, navigate]);

  const handlePayment = async (amount) => {
    setIsProcessingPayment(true);
    try {
      const response = await createStripeCheckout({
        projectId: project.id, // Use the existing 'project' state variable
        amountToPay: amount
      });
      
      if (response.data.url) {
        // Redirigir a Stripe Checkout
        window.location.href = response.data.url;
      } else {
        throw new Error('No se pudo crear la sesión de pago');
      }
    } catch (error) {
      console.error('Error al procesar el pago:', error);
      alert('Error al procesar el pago. Por favor, inténtalo de nuevo.');
    } finally {
      setIsProcessingPayment(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gray-100">
        <Loader className="w-12 h-12 animate-spin text-emerald-500" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="container mx-auto px-4 max-w-6xl"> {/* This container holds header, alerts, and general errors */}
        <header className="mb-8 pt-8"> {/* Added pt-8 for top padding */}
          <div className="flex justify-between items-center">
            <div>
              <h1 className="text-3xl font-bold text-gray-800">Portal del Cliente</h1>
              <p className="text-gray-500">Bienvenido de vuelta, {user?.full_name?.split(' ')[0] || ''}.</p>
            </div>
             <Button asChild variant="outline">
              <Link to={createPageUrl('Home')}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Volver al Inicio
              </Link>
            </Button>
          </div>
        </header>

        {paymentStatus && (
          <Alert className={`mb-6 ${paymentStatus.type === 'success' ? 'border-green-500' : 'border-yellow-500'}`}>
            {paymentStatus.type === 'success' 
              ? <CheckCircle className="h-4 w-4 text-green-500" /> 
              : <XCircle className="h-4 w-4 text-yellow-500" />
            }
            <AlertTitle className={`${paymentStatus.type === 'success' ? 'text-green-700' : 'text-yellow-700'}`}>
              {paymentStatus.type === 'success' ? 'Pago Exitoso' : 'Pago Cancelado'}
            </AlertTitle>
            <AlertDescription>
              {paymentStatus.message}
            </AlertDescription>
          </Alert>
        )}

        {error && ( // Display critical errors outside of the tab system
          <div className="bg-yellow-50 border-l-4 border-yellow-400 p-4 rounded-r-lg mb-8"> {/* Added mb-8 for spacing */}
            <div className="flex">
              <div className="py-1"><AlertTriangle className="h-6 w-6 text-yellow-500 mr-3" /></div>
              <div>
                <p className="font-bold text-yellow-800">Proyecto no encontrado</p>
                <p className="text-sm text-yellow-700">{error}</p>
              </div>
            </div>
          </div>
        )}
      </div> {/* End of header/alert/error container */}

      {/* Render tabs only if a project is found and there's no general error */}
      {project && !error ? (
        <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8"> {/* Main content area for tabs, with new max-width */}
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-8">
            <TabsList className="grid w-full grid-cols-2 lg:grid-cols-4"> {/* Adjusted grid-cols for 4 tabs */}
              <TabsTrigger value="overview">
                <LayoutDashboard className="w-4 h-4 mr-2" />
                General
              </TabsTrigger>
              <TabsTrigger value="milestones">
                <GanttChart className="w-4 h-4 mr-2" />
                Hitos
              </TabsTrigger>
              <TabsTrigger value="messages">
                <MessageSquare className="w-4 h-4 mr-2" />
                Mensajes
              </TabsTrigger>
              <TabsTrigger value="files">
                <FolderOpen className="w-4 h-4 mr-2" />
                Archivos
              </TabsTrigger>
            </TabsList>

            <TabsContent value="overview">
              <ProjectOverview 
                project={project} 
                onPayment={handlePayment} 
                isProcessingPayment={isProcessingPayment} 
              />
            </TabsContent>

            <TabsContent value="milestones">
              <MilestoneTracker projectId={project.id} />
            </TabsContent>

            <TabsContent value="messages">
              <MessageCenter projectId={project.id} />
            </TabsContent>

            <TabsContent value="files">
              <FileManager projectId={project.id} />
            </TabsContent>
          </Tabs>
        </main>
      ) : null} {/* If no project or error, render null for the main content */}
    </div>
  );
}
