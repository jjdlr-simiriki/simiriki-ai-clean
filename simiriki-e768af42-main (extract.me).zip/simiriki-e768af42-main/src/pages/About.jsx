import React from 'react';
import { Users, Rocket, Globe, BrainCircuit, Target, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const teamMembers = [
  { name: 'Jesús de la Riva', role: 'CEO & Founder', avatar: 'https://i.pravatar.cc/150?u=jjdlr' },
  { name: 'Elena Vega', role: 'CTO & AI Specialist', avatar: 'https://i.pravatar.cc/150?u=elena' },
  { name: 'Carlos Rojas', role: 'Head of Automation', avatar: 'https://i.pravatar.cc/150?u=carlos' },
  { name: 'Sofia Torres', role: 'Lead Generation Expert', avatar: 'https://i.pravatar.cc/150?u=sofia' },
];

export default function About() {
  return (
    <div className="py-20 text-white">
      {/* Hero Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center mb-20">
        <div className="inline-flex items-center px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-medium mb-6">
          <Target className="w-4 h-4 mr-2" />
          Nuestra Misión
        </div>
        
        <h1 className="text-4xl md:text-6xl font-bold mb-6">
          <span className="gradient-text">Automatiza. Escala. Transforma.</span>
        </h1>
        
        <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed">
          Somos la plataforma líder de automatización inteligente para PYMEs en América Latina, 
          transformando negocios tradicionales en máquinas modernas de crecimiento.
        </p>
      </div>

      {/* Objective Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="bg-gradient-to-br from-green-500/10 to-purple-500/10 rounded-3xl p-8 md:p-12 border border-white/10">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Nuestro Objetivo
            </h2>
            <p className="text-xl text-gray-300 max-w-3xl mx-auto">
              Convertir a Simiriki en la plataforma líder de automatización inteligente para PYMEs en América Latina
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div>
              <h3 className="text-2xl font-bold text-white mb-4">
                Transformamos visitas en ventas, tareas en flujos automáticos
              </h3>
              <p className="text-gray-300 mb-6 leading-relaxed">
                Nuestro objetivo no es solo digitalizar. Es hacer que tu negocio trabaje por ti, 
                incluso cuando tú no estás. Lo hacemos integrando IA, automatización de procesos 
                y herramientas simples pero poderosas.
              </p>
              
              <div className="space-y-3 mb-6">
                {[
                  "🎯 Captar más clientes automáticamente",
                  "💬 Contestar mensajes sin estar pegado al celular",
                  "📈 Vender más sin contratar más",
                  "📊 Tener control total desde un panel inteligente"
                ].map((benefit, index) => (
                  <div key={index} className="flex items-center text-gray-300">
                    <div className="text-lg mr-3">{benefit.split(' ')[0]}</div>
                    <div>{benefit.substring(3)}</div>
                  </div>
                ))}
              </div>
              
              <Link to={createPageUrl("Contact")}>
                <Button size="lg" className="gradient-bg text-white hover:opacity-90">
                  <Zap className="w-5 h-5 mr-2" />
                  Comenzar mi Transformación
                </Button>
              </Link>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1552664730-d307ca884978?q=80&w=2574&auto=format&fit=crop"
                alt="Equipo Simiriki trabajando"
                className="w-full h-full object-cover rounded-2xl"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-purple-900/60 to-transparent rounded-2xl"></div>
              <div className="absolute bottom-6 left-6 right-6">
                <blockquote className="text-white italic text-lg">
                  "Fundé Simiriki porque vi cómo las grandes corporaciones usaban automatización para crecer exponencialmente, 
                  mientras las PYMEs se quedaban atrás. Nuestro propósito es nivelar el campo de juego."
                </blockquote>
                <p className="text-right mt-3 font-semibold text-green-400">
                  - Jesús de la Riva, Fundador & CEO
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Mission & Vision Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 mb-20">
        <div className="grid md:grid-cols-3 gap-8">
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-green-400 to-green-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Rocket className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Automatiza</h3>
            <p className="text-gray-300">
              Eliminamos las tareas repetitivas que consumen tu tiempo, 
              creando flujos inteligentes que operan 24/7.
            </p>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-purple-400 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <Globe className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Escala</h3>
            <p className="text-gray-300">
              Tu negocio crece sin límites. Más clientes, más ventas, 
              más resultados, sin necesidad de contratar más personal.
            </p>
          </div>
          
          <div className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 text-center">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-400 to-blue-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
              <BrainCircuit className="w-8 h-8 text-white" />
            </div>
            <h3 className="text-xl font-bold text-white mb-4">Transforma</h3>
            <p className="text-gray-300">
              Convertimos negocios tradicionales en empresas modernas, 
              eficientes y preparadas para el futuro.
            </p>
          </div>
        </div>
      </div>
      
      {/* Team Section */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold mb-4">
            El Equipo que <span className="gradient-text">Hace Posible la Magia</span>
          </h2>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto">
            Expertos en automatización, IA y crecimiento empresarial, trabajando para transformar tu negocio.
          </p>
        </div>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
          {teamMembers.map((member, index) => (
            <div key={member.name} className="text-center group">
              <div className="relative w-32 h-32 md:w-40 md:h-40 mx-auto mb-4">
                <img 
                  src={member.avatar} 
                  alt={member.name} 
                  className="rounded-full w-full h-full object-cover border-4 border-transparent group-hover:border-green-400 transition-all" 
                />
                <div className="absolute inset-0 rounded-full bg-gradient-to-br from-green-500/50 to-purple-500/50 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
              </div>
              <h3 className="text-lg font-semibold text-white">{member.name}</h3>
              <p className="text-green-400">{member.role}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}