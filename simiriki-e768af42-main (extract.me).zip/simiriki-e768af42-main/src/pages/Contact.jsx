
import React, { useState } from 'react';
import { Mail, Phone, MapPin, Calendar, CheckCircle, MessageSquare, Clock, Star, Users, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import HubSpotFormWrapper from '@/components/hubspot/HubSpotFormWrapper';
import HubSpotMeeting from '../components/hubspot/HubSpotMeeting';

// HubSpot configuration with actual Portal ID
const HUBSPOT_MEETING_URL = "https://meetings.hubspot.com/jjdlr/simiriki-consulta";

export default function Contact() {
  const [showMeetingWidget, setShowMeetingWidget] = useState(false);

  const handleScheduleClick = () => {
    window.trackGAEvent('select_content', {
      content_type: 'cta_button',
      item_id: 'schedule_consultation_contact_page'
    });
    
    // Track in HubSpot
    if (window.hsTrackEvent) {
      window.hsTrackEvent('consultation_button_clicked', {
        page: 'contact',
        source: 'main_cta'
      });
    }
  };

  const handleWhatsAppClick = () => {
    const message = encodeURIComponent("Hola! Me interesa conocer más sobre los servicios de automatización de Simiriki. ¿Podríamos agendar una consulta?");
    window.open(`https://wa.me/528134675514?text=${message}`, '_blank');
    
    // Track WhatsApp click
    window.trackGAEvent('select_content', {
      content_type: 'whatsapp_button',
      item_id: 'whatsapp_contact_page'
    });

    if (window.hsTrackEvent) {
      window.hsTrackEvent('whatsapp_contact_clicked', {
        page: 'contact',
        source: 'contact_info'
      });
    }
  };

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden py-20 lg:py-32">
        {/* Background Elements */}
        <div className="absolute inset-0 bg-gradient-to-br from-purple-900/20 via-transparent to-green-900/20"></div>
        <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-green-500/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-purple-500/10 rounded-full blur-3xl"></div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <div className="inline-flex items-center px-4 py-2 rounded-full bg-green-500/10 border border-green-500/20 text-green-400 text-sm font-medium mb-6">
              <MessageSquare className="w-4 h-4 mr-2" />
              Respuesta garantizada en 24 horas
            </div>
            
            <h1 className="text-4xl md:text-6xl font-bold text-white mb-6 leading-tight">
              Hablemos de tu <span className="gradient-text">Futuro</span>
            </h1>
            
            <p className="text-xl text-gray-300 max-w-4xl mx-auto leading-relaxed mb-8">
              ¿Listo para dejar de trabajar EN tu negocio y empezar a trabajar SOBRE tu negocio? 
              Agenda una consulta gratuita de 30 minutos. Te daremos 3 ideas específicas para automatizar tu operación, sin compromiso.
            </p>

            {/* Botones de contacto rápido */}
            <div className="flex flex-col sm:flex-row gap-4 justify-center max-w-2xl mx-auto mb-8">
              <a href="tel:+528134675514" className="block">
                <Button size="lg" className="gradient-bg text-white hover:opacity-90 transition-opacity w-full sm:w-auto">
                  <Phone className="w-5 h-5 mr-2" />
                  Llamar: +52 813 467 5514
                </Button>
              </a>
              
              <Button 
                size="lg" 
                onClick={handleWhatsAppClick}
                className="bg-green-600 hover:bg-green-700 text-white w-full sm:w-auto"
              >
                <MessageCircle className="w-5 h-5 mr-2" />
                WhatsApp Directo
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Main Content */}
      <section className="py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12">
            
            {/* Left Column - HubSpot Meeting Booking */}
            <div className="space-y-8">
              {/* Main CTA Card */}
              <Card className="bg-gradient-to-br from-green-500/10 to-purple-500/10 border-green-500/20 overflow-hidden">
                <CardHeader className="text-center pb-6">
                  <div className="w-20 h-20 bg-gradient-to-br from-green-400 to-purple-400 rounded-full flex items-center justify-center mx-auto mb-4">
                    <Calendar className="w-10 h-10 text-white" />
                  </div>
                  
                  <CardTitle className="text-3xl font-bold text-white mb-2">
                    Consulta Estratégica Gratuita
                  </CardTitle>
                  
                  <p className="text-gray-300 text-lg">
                    30 minutos que pueden cambiar tu negocio para siempre
                  </p>
                </CardHeader>
                
                <CardContent className="text-center space-y-6">
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 text-sm">
                    <div className="flex items-center justify-center space-x-2 text-green-400">
                      <CheckCircle className="w-4 h-4" />
                      <span>100% Gratuita</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2 text-purple-400">
                      <Clock className="w-4 h-4" />
                      <span>Sin Compromiso</span>
                    </div>
                    <div className="flex items-center justify-center space-x-2 text-blue-400">
                      <Star className="w-4 h-4" />
                      <span>Valor Inmediato</span>
                    </div>
                  </div>
                  
                  {!showMeetingWidget ? (
                    <Button 
                      size="lg" 
                      className="gradient-bg text-white hover:opacity-90 w-full max-w-sm group text-lg py-3"
                      onClick={() => {
                        setShowMeetingWidget(true);
                        handleScheduleClick();
                      }}
                    >
                      <Calendar className="w-5 h-5 mr-2" />
                      Agendar mi Consulta Ahora
                    </Button>
                  ) : (
                    <div className="mt-6">
                      <HubSpotMeeting meetingUrl={HUBSPOT_MEETING_URL} height="600px" />
                    </div>
                  )}
                  
                  <div className="flex items-center justify-center mt-4 text-sm text-green-400">
                    <CheckCircle className="w-4 h-4 mr-2" />
                    Potenciado por HubSpot Meetings
                  </div>
                </CardContent>
              </Card>

              {/* What to Expect */}
              <Card className="bg-white/5 backdrop-blur-sm border-white/10">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-white">¿Qué puedes esperar?</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  {[
                    {
                      icon: "🔍",
                      title: "Diagnóstico Express",
                      desc: "Analizamos tu operación actual en 5 minutos"
                    },
                    {
                      icon: "💡",
                      title: "3 Ideas Específicas",
                      desc: "Estrategias concretas que puedes implementar inmediatamente"
                    },
                    {
                      icon: "📊",
                      title: "ROI Proyectado",
                      desc: "Calculamos cuánto podrías ahorrar y ganar"
                    },
                    {
                      icon: "🛣️",
                      title: "Roadmap Personalizado",
                      desc: "Plan paso a paso para tu transformación digital"
                    }
                  ].map((item, index) => (
                    <div key={index} className="flex items-start space-x-3">
                      <div className="text-2xl" role="img" aria-label="icon">{item.icon}</div>
                      <div>
                        <div className="text-white font-medium">{item.title}</div>
                        <div className="text-gray-300 text-sm">{item.desc}</div>
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>

              {/* Social Proof */}
              <Card className="bg-white/5 backdrop-blur-sm border-white/10">
                <CardContent className="pt-6">
                  <div className="text-center space-y-4">
                    <div className="flex items-center justify-center space-x-2">
                      <Users className="w-5 h-5 text-green-400" />
                      <span className="text-white font-medium">+200 empresas han transformado su negocio</span>
                    </div>
                    
                    <div className="grid grid-cols-3 gap-4 text-center">
                      <div>
                        <div className="text-2xl font-bold text-green-400">300%</div>
                        <div className="text-xs text-gray-400">Aumento promedio en leads</div>
                      </div>
                      <div>
                        <div className="2xl font-bold text-purple-400">80%</div>
                        <div className="text-xs text-gray-400">Reducción en trabajo manual</div>
                      </div>
                      <div>
                        <div className="2xl font-bold text-blue-400">90 días</div>
                        <div className="text-xs text-gray-400">Para ver resultados</div>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            
            {/* Right Column - Tally Form */}
            <div className="space-y-8">
              <Card className="bg-white/5 backdrop-blur-sm border-white/10">
                <CardHeader>
                  <CardTitle className="text-2xl font-bold text-white">Envía un Mensaje Directo</CardTitle>
                  <p className="text-gray-300">Cuéntanos sobre tu proyecto y te contactaremos en 24 horas.</p>
                </CardHeader>
                <CardContent>
                      <HubSpotFormWrapper portalId="50203146" formId="11136151-e63d4073-a62e-f25df954f1ef" />
                </CardContent>
              </Card>

              {/* Contact Info */}
              <Card className="bg-white/5 backdrop-blur-sm border-white/10">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-white">Información de Contacto</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-4 text-gray-300">
                    <div className="flex items-center space-x-4 p-3 rounded-lg bg-white/5">
                      <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-green-600 rounded-full flex items-center justify-center">
                        <Mail className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="text-white font-medium">Email</div>
                        <a href="mailto:jjdlr@simiriki.com" className="text-green-400 hover:text-green-300 transition-colors">
                          jjdlr@simiriki.com
                        </a>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4 p-3 rounded-lg bg-white/5">
                      <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-purple-600 rounded-full flex items-center justify-center">
                        <Phone className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="text-white font-medium">Teléfono</div>
                        <a href="tel:+528134675514" className="text-purple-300 hover:text-purple-200 transition-colors">
                          +52 813 467 5514
                        </a>
                      </div>
                    </div>

                    {/* WhatsApp Contact Option */}
                    <div 
                      className="flex items-center space-x-4 p-3 rounded-lg bg-green-500/10 border border-green-500/20 cursor-pointer hover:bg-green-500/20 transition-colors"
                      onClick={handleWhatsAppClick}
                    >
                      <div className="w-10 h-10 bg-gradient-to-br from-green-500 to-green-600 rounded-full flex items-center justify-center">
                        <MessageCircle className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="text-white font-medium">WhatsApp</div>
                        <div className="text-green-400 text-sm">Respuesta inmediata garantizada</div>
                      </div>
                    </div>
                    
                    <div className="flex items-center space-x-4 p-3 rounded-lg bg-white/5">
                      <div className="w-10 h-10 bg-gradient-to-br from-blue-400 to-blue-600 rounded-full flex items-center justify-center">
                        <MapPin className="w-5 h-5 text-white" />
                      </div>
                      <div>
                        <div className="text-white font-medium">Cobertura</div>
                        <span className="text-gray-300">Atención remota para toda Latinoamérica</span>
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
              
              {/* FAQ */}
              <Card className="bg-white/5 backdrop-blur-sm border-white/10">
                <CardHeader>
                  <CardTitle className="text-xl font-bold text-white">Preguntas Frecuentes</CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div>
                    <h3 className="font-semibold text-white mb-2">¿Para qué tipo de empresas son sus servicios?</h3>
                    <p className="text-sm text-gray-400">Nos especializamos en PYMES de 10 a 200 empleados en cualquier sector que busque digitalizar y automatizar sus procesos.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-2">¿Cuánto tiempo tarda en ver resultados?</h3>
                    <p className="text-sm text-gray-400">Aunque varía por proyecto, muchos de nuestros clientes ven mejoras significativas en eficiencia y generación de leads en los primeros 90 días.</p>
                  </div>
                  <div>
                    <h3 className="font-semibold text-white mb-2">¿La consulta realmente es gratuita?</h3>
                    <p className="text-sm text-gray-400">Completamente gratuita y sin compromiso. Te daremos valor real en esos 30 minutos, sin importar si decides trabajar con nosotros o no.</p>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
