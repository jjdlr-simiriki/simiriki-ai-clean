
import React from 'react';
import { Cog, Users, Bot, BrainCircuit, ArrowRight } from "lucide-react";
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';

const services = [
  {
    icon: Cog,
    title: "Automatización de Procesos (RPA & Workflows)",
    description: "Liberamos el potencial de tu equipo eliminando tareas repetitivas. Diseñamos e implementamos flujos de trabajo inteligentes que operan 24/7, reduciendo errores y aumentando la productividad.",
    case_study: "Despacho Contable 'Números Exactos' redujo la generación de reportes de días a minutos.",
    details: ["Auditoría de procesos actuales", "Integración de CRM y ERP", "Automatización de marketing y ventas", "Reportes automáticos"],
    color: "from-green-400 to-green-600"
  },
  {
    icon: Users,
    title: "Generación de Leads Inteligente",
    description: "Construimos máquinas de generación de prospectos que atraen, califican y nutren a tus clientes ideales de forma automática, entregando leads listos para la venta a tu equipo comercial.",
    case_study: "Inmobiliaria 'Hogar Ideal' cerró 40% más ventas con la mitad del equipo usando nuestro lead scoring.",
    details: ["Landing pages de alta conversión", "Chatbots calificadores de leads", "Secuencias de email nurturing", "Lead scoring predictivo"],
    color: "from-purple-400 to-purple-600"
  },
  {
    icon: Bot,
    title: "Inteligencia Artificial para Negocios",
    description: "Integramos soluciones de IA para potenciar tu atención al cliente, personalizar la experiencia de usuario y tomar decisiones basadas en datos predictivos, no solo históricos.",
    case_study: "Tienda de ropa 'Estilo Verde' aumentó ventas 340% con cross-selling inteligente y automatizado.",
    details: ["Asistentes virtuales y chatbots con IA", "Sistemas de recomendación de productos", "Análisis de sentimiento del cliente", "Modelos predictivos de ventas"],
    color: "from-blue-400 to-blue-600"
  },
  {
    icon: BrainCircuit,
    title: "Consultoría en Transformación Digital",
    description: "Te guiamos en cada paso de tu viaje digital. Desde la estrategia y el roadmap tecnológico hasta la implementación y capacitación de tu equipo, asegurando una transición exitosa y sostenible.",
    case_study: "Clínica Dental 'Sonrisas Plus' eliminó su lista de espera y mejoró la satisfacción del paciente en un 95%.",
    details: ["Diagnóstico de madurez digital", "Roadmap tecnológico personalizado", "Gestión del cambio y capacitación", "Medición de KPIs y ROI"],
    color: "from-orange-400 to-orange-600"
  }
];

export default function Services() {
  return (
    <div className="py-20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Servicios de <span className="gradient-text">Automatización Inteligente para PYMEs</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Descubre nuestro ecosistema de servicios de automatización, generación de leads con IA y transformación digital, diseñados para potenciar el crecimiento de tu negocio en Latinoamérica.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-8 mb-16">
          {services.map((service, index) => (
            <Card key={index} className="group bg-white/5 backdrop-blur-sm rounded-3xl p-8 border border-white/10 hover:border-white/20 transition-all duration-300 transform hover:-translate-y-1">
              <CardContent className="p-0 flex flex-col h-full">
                <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform`}>
                  <service.icon className="w-8 h-8 text-white" />
                </div>
                
                <h2 className="text-2xl font-bold text-white mb-4">{service.title}</h2>
                <p className="text-gray-300 mb-4 leading-relaxed">{service.description}</p>
                <p className="text-green-400 italic mb-6 text-sm">"{service.case_study}"</p>
                
                <div className="border-t border-white/10 pt-6 mt-auto">
                  <h3 className="font-semibold text-purple-300 mb-3">Servicios clave:</h3>
                  <ul className="grid grid-cols-1 sm:grid-cols-2 gap-x-6 gap-y-2 mb-6">
                    {service.details.map((detail, idx) => (
                      <li key={idx} className="flex items-center text-gray-300 text-sm">
                        <ArrowRight className="w-3 h-3 text-green-400 mr-2 flex-shrink-0" />
                        {detail}
                      </li>
                    ))}
                  </ul>
                  <Link to={createPageUrl(`Contact?service=${encodeURIComponent(service.title)}`)}>
                    <Button variant="outline" className="text-purple-300 border-purple-400/80 hover:bg-purple-500/20 hover:border-purple-400 hover:text-white transition-colors group">
                      Quiero saber más
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
        
        <Card className="bg-gradient-to-br from-green-500/10 to-purple-500/10 p-8 md:p-12 rounded-3xl border border-white/10 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">¿No estás seguro por dónde empezar?</h2>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Nuestro diagnóstico gratuito de 2 minutos te dirá exactamente qué servicio generará el mayor impacto en tu negocio.
          </p>
          <Link to={createPageUrl("DiagnosticTool")}>
            <Button size="lg" className="gradient-bg text-white hover:opacity-90">
              Quiero mi Diagnóstico Gratuito Ahora
              <BrainCircuit className="w-5 h-5 ml-2" />
            </Button>
          </Link>
        </Card>
      </div>
    </div>
  );
}
