
import React, { useState } from 'react';
import { TrendingUp, Users, Clock, ArrowRight, Building, Star, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

const caseStudies = [
  {
    id: 1,
    client: "Despacho Contable 'Números Exactos'",
    industry: "Servicios Profesionales",
    employees: "15-25",
    location: "Ciudad de México",
    logo: "https://images.unsplash.com/photo-1554224155-6726b3ff858f?w=100&h=100&fit=crop&crop=center",
    problem: {
      title: "Generación Manual de Reportes Consumía 3 Días por Semana",
      description: "El equipo dedicaba 24 horas semanales creando reportes financieros manualmente, generando errores frecuentes y retrasos en la entrega a clientes. Los contadores no podían enfocarse en análisis estratégico."
    },
    solution: {
      title: "Automatización Completa del Flujo de Reportes",
      description: "Implementamos un sistema que integra datos de múltiples fuentes, genera reportes automáticamente y los envía por email a cada cliente según su calendario personalizado.",
      features: [
        "Integración automática con 5 sistemas contables",
        "Generación de reportes personalizados por cliente",
        "Envío automático programado",
        "Dashboard de seguimiento en tiempo real"
      ]
    },
    results: {
      timeReduction: "85%",
      costSavings: "$4,500 USD/mes",
      clientSatisfaction: "98%",
      roiPeriod: "45 días",
      details: [
        "Reducción de 24 horas a 3.5 horas por semana en reportes",
        "Eliminación del 100% de errores humanos",
        "Capacidad para atender 40% más clientes sin contratar",
        "Los contadores ahora se enfocan en consultoría estratégica"
      ]
    },
    testimonial: {
      quote: "Simiriki transformó completamente nuestra operación. Ahora somos una firma de consultoría estratégica, no solo 'hacedores de reportes'. Nuestros clientes están impresionados con la velocidad y precisión.",
      author: "Lic. María Elena Vásquez",
      position: "Socia Fundadora, Números Exactos"
    },
    featured: true
  },
  {
    id: 2,
    client: "Inmobiliaria 'Hogar Ideal'",
    industry: "Bienes Raíces",
    employees: "8-12",
    location: "Guadalajara",
    logo: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=100&h=100&fit=crop&crop=center",
    problem: {
      title: "Leads de Baja Calidad y Seguimiento Manual Ineficiente",
      description: "Recibían 200+ leads mensuales pero solo 15% eran realmente calificados. El equipo perdía tiempo contactando prospectos no serios, y muchos leads calificados se 'enfriaban' por falta de seguimiento oportuno."
    },
    solution: {
      title: "Sistema de Lead Scoring y Automatización de Seguimiento",
      description: "Desarrollamos un chatbot inteligente que califica leads automáticamente y un sistema de seguimiento que nutre prospectos con contenido personalizado según su perfil de compra.",
      features: [
        "Chatbot calificador con IA conversacional",
        "Lead scoring automático (1-100 puntos)",
        "Secuencias de email nurturing personalizadas",
        "CRM integrado con dashboards de conversión"
      ]
    },
    results: {
      leadQuality: "+340%",
      conversionRate: "24%",
      teamEfficiency: "+60%",
      roiPeriod: "30 días",
      details: [
        "De 30 leads calificados/mes a 102 leads calificados/mes",
        "Tasa de conversión lead-a-cita subió de 8% a 24%",
        "El equipo de ventas ahora solo habla con prospectos serios",
        "40% más ventas con el mismo equipo"
      ]
    },
    testimonial: {
      quote: "Antes perseguíamos cualquier lead. Ahora los prospectos llegan pre-calificados y listos para comprar. Es como tener un equipo de 10 personas trabajando 24/7 calificando leads por nosotros.",
      author: "Arq. Roberto Sánchez",
      position: "Director Comercial, Hogar Ideal"
    },
    featured: true
  },
  {
    id: 3,
    client: "Tienda de Ropa 'Estilo Verde'",
    industry: "Retail",
    employees: "5-8",
    location: "Mérida",
    logo: "https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=100&h=100&fit=crop&crop=center",
    problem: {
      title: "Ventas Estancadas y Atención al Cliente Limitada",
      description: "Tienda física con presencia online básica. Los clientes hacían las mismas preguntas repetitivas por WhatsApp, y no había sistema para recomendar productos complementarios. Las ventas se estancaron en $45,000 MXN/mes."
    },
    solution: {
      title: "Chatbot de Ventas con IA y Sistema de Recomendaciones",
      description: "Implementamos un asistente virtual que maneja consultas, recomienda outfits completos basados en las preferencias del cliente, y automatiza el proceso de venta hasta el pago.",
      features: [
        "Chatbot con catálogo integrado y recomendaciones",
        "Sistema de cross-selling inteligente",
        "Automatización de pedidos y pagos",
        "Follow-up automático post-venta"
      ]
    },
    results: {
      salesIncrease: "+340%",
      avgOrderValue: "+180%",
      customerSupport: "24/7",
      roiPeriod: "60 días",
      details: [
        "Ventas mensuales subieron de $45,000 a $198,000 MXN",
        "Ticket promedio aumentó de $850 a $2,380 MXN",
        "80% de consultas resueltas automáticamente",
        "Atención al cliente disponible las 24 horas"
      ]
    },
    testimonial: {
      quote: "No puedo creer que ahora estoy vendiendo mientras duermo. El chatbot conoce mi inventario mejor que yo misma, y los clientes están encantados con las recomendaciones personalizadas.",
      author: "Sofía Herrera",
      position: "Propietaria, Estilo Verde"
    },
    featured: false
  }
];

export default function CaseStudies() {
  const [selectedCase, setSelectedCase] = useState(null);

  return (
    <div className="py-20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Casos de Éxito en <span className="gradient-text">Automatización para PYMEs</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Explora cómo empresas reales en México y LATAM han multiplicado sus ventas y eficiencia con nuestras soluciones de automatización inteligente. Resultados comprobados.
          </p>
        </div>

        {/* Featured Case Studies */}
        <div className="grid lg:grid-cols-2 gap-8 mb-16">
          {caseStudies.filter(cs => cs.featured).map((caseStudy) => (
            <Card key={caseStudy.id} className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 hover:border-green-400/30 transition-all duration-300">
              <CardHeader>
                <div className="flex items-center space-x-4 mb-4">
                  <img src={caseStudy.logo} alt={caseStudy.client} className="w-16 h-16 rounded-lg object-cover" />
                  <div>
                    <h3 className="text-xl font-bold text-white">{caseStudy.client}</h3>
                    <div className="flex items-center space-x-2 text-sm text-gray-400">
                      <Badge variant="outline" className="text-green-400 border-green-400/50">{caseStudy.industry}</Badge>
                      <span>•</span>
                      <span>{caseStudy.employees} empleados</span>
                      <span>•</span>
                      <span>{caseStudy.location}</span>
                    </div>
                  </div>
                </div>
                
                <div className="bg-gradient-to-r from-red-500/10 to-red-500/5 rounded-lg p-4 border-l-4 border-red-400 mb-4">
                  <h4 className="text-red-400 font-semibold mb-2">Problema:</h4>
                  <p className="text-gray-300 text-sm">{caseStudy.problem.description}</p>
                </div>
                
                <div className="bg-gradient-to-r from-blue-500/10 to-blue-500/5 rounded-lg p-4 border-l-4 border-blue-400 mb-4">
                  <h4 className="text-blue-400 font-semibold mb-2">Solución Simiriki:</h4>
                  <p className="text-gray-300 text-sm mb-3">{caseStudy.solution.description}</p>
                  <ul className="space-y-1">
                    {caseStudy.solution.features.map((feature, index) => (
                      <li key={index} className="flex items-center text-xs text-gray-400">
                        <CheckCircle className="w-3 h-3 text-blue-400 mr-2 flex-shrink-0" />
                        {feature}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardHeader>
              
              <CardContent>
                <div className="bg-gradient-to-r from-green-500/10 to-green-500/5 rounded-lg p-4 border-l-4 border-green-400 mb-6">
                  <h4 className="text-green-400 font-semibold mb-3">Resultados Tangibles:</h4>
                  <div className="grid grid-cols-2 gap-4 mb-3">
                    {Object.entries(caseStudy.results).slice(0, 4).map(([key, value]) => {
                      if (key === 'details') return null;
                      const labels = {
                        timeReduction: 'Reducción de Tiempo',
                        costSavings: 'Ahorro Mensual', 
                        clientSatisfaction: 'Satisfacción Cliente',
                        roiPeriod: 'ROI Recuperado en',
                        leadQuality: 'Mejora Lead Quality',
                        conversionRate: 'Tasa Conversión',
                        teamEfficiency: 'Eficiencia Equipo',
                        salesIncrease: 'Aumento Ventas',
                        avgOrderValue: 'Ticket Promedio',
                        customerSupport: 'Soporte Cliente'
                      };
                      return (
                        <div key={key} className="text-center">
                          <div className="text-lg font-bold text-green-400">{value}</div>
                          <div className="text-xs text-gray-400">{labels[key]}</div>
                        </div>
                      );
                    })}
                  </div>
                </div>
                
                <blockquote className="bg-white/5 rounded-lg p-4 border border-white/10 mb-4">
                  <p className="text-gray-300 italic mb-3">"{caseStudy.testimonial.quote}"</p>
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-gradient-to-br from-green-400 to-purple-400 rounded-full flex items-center justify-center text-sm font-bold text-white">
                      {caseStudy.testimonial.author.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div>
                      <div className="text-white font-medium text-sm">{caseStudy.testimonial.author}</div>
                      <div className="text-gray-400 text-xs">{caseStudy.testimonial.position}</div>
                    </div>
                  </div>
                </blockquote>
                
                <Button 
                  variant="outline" 
                  className="w-full text-purple-300 border-purple-400/80 hover:bg-purple-500/20 hover:border-purple-400 hover:text-white transition-colors"
                  onClick={() => setSelectedCase(caseStudy)}
                >
                  Ver Caso Completo
                  <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Additional Case Study */}
        <div className="mb-16">
          <h2 className="text-2xl font-bold text-white mb-8 text-center">Más Casos de Transformación</h2>
          <div className="max-w-4xl mx-auto">
            {caseStudies.filter(cs => !cs.featured).map((caseStudy) => (
              <Card key={caseStudy.id} className="bg-white/5 backdrop-blur-sm rounded-2xl p-6 border border-white/10 mb-6">
                <div className="grid md:grid-cols-3 gap-6">
                  <div className="flex items-center space-x-4">
                    <img src={caseStudy.logo} alt={caseStudy.client} className="w-12 h-12 rounded-lg object-cover" />
                    <div>
                      <h3 className="font-bold text-white">{caseStudy.client}</h3>
                      <p className="text-sm text-gray-400">{caseStudy.industry}</p>
                    </div>
                  </div>
                  <div className="text-center">
                    <div className="text-2xl font-bold text-green-400">{caseStudy.results.salesIncrease}</div>
                    <div className="text-sm text-gray-400">Aumento en Ventas</div>
                  </div>
                  <div className="flex items-center">
                    <Button 
                      variant="outline" 
                      size="sm"
                      className="text-purple-300 border-purple-400/80 hover:bg-purple-500/20"
                      onClick={() => setSelectedCase(caseStudy)}
                    >
                      Ver Detalles
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        </div>

        {/* CTA Section */}
        <Card className="bg-gradient-to-br from-green-500/10 to-purple-500/10 p-8 md:p-12 rounded-3xl border border-white/10 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">¿Tu Empresa Será la Próxima Historia de Éxito?</h2>
          <p className="text-gray-300 mb-6 max-w-2xl mx-auto">
            Únete a las empresas que ya están automatizando sus procesos y multiplicando sus resultados. 
            Tu transformación comienza con una consulta gratuita de 30 minutos.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to={createPageUrl("Contact")}>
              <Button size="lg" className="gradient-bg text-white hover:opacity-90">
                Quiero mi Consulta Gratuita
                <ArrowRight className="w-5 h-5 ml-2" />
              </Button>
            </Link>
            <Link to={createPageUrl("Services")}>
              <Button size="lg" variant="outline" className="text-purple-300 border-purple-400/80 hover:bg-purple-500/20">
                Ver Nuestros Servicios
              </Button>
            </Link>
          </div>
        </Card>
      </div>
    </div>
  );
}
