import React, { useState, useEffect } from 'react';
import { BlogPost as BlogPostEntity } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import ReactMarkdown from 'react-markdown';
import { Calendar, Clock, Tag, Share2 } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Button } from '@/components/ui/button';

export default function BlogPost() {
  const [post, setPost] = useState(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchPost = async () => {
      setIsLoading(true);
      try {
        // Get slug from URL parameters
        const urlParams = new URLSearchParams(window.location.search);
        const slug = urlParams.get('slug');
        
        if (slug) {
          const posts = await BlogPostEntity.filter({ slug: slug, status: 'published' });
          if (posts.length > 0) {
            setPost(posts[0]);
          }
        }
      } catch (error) {
        console.error("Error fetching blog post:", error);
      }
      setIsLoading(false);
    };
    fetchPost();
  }, []);

  if (isLoading) {
    return (
      <div className="py-20 text-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="h-10 bg-white/10 rounded w-3/4 mb-4"></div>
            <div className="h-6 bg-white/10 rounded w-1/2 mb-8"></div>
            <div className="h-64 bg-white/10 rounded-lg mb-8"></div>
            <div className="space-y-4">
              <div className="h-4 bg-white/10 rounded"></div>
              <div className="h-4 bg-white/10 rounded w-5/6"></div>
              <div className="h-4 bg-white/10 rounded w-3/4"></div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (!post) {
    return (
      <div className="py-20 text-center text-white">
        <h1 className="text-4xl font-bold">Post no encontrado</h1>
        <p className="mt-4">El post que buscas no existe o ha sido movido.</p>
        <Link to={createPageUrl("Blog")}>
          <Button className="mt-8">Volver al Blog</Button>
        </Link>
      </div>
    );
  }

  return (
    <div className="py-20 text-white">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <article className="prose prose-invert lg:prose-xl prose-h1:gradient-text prose-h2:text-green-400 prose-a:text-purple-400 hover:prose-a:text-purple-300 prose-strong:text-white">
          <header className="mb-12">
            <div className="flex items-center space-x-2 text-sm text-green-400 mb-4">
              <Tag className="w-4 h-4" />
              <span>{post.category.replace(/_/g, ' ')}</span>
            </div>
            <h1>{post.title}</h1>
            <div className="flex items-center space-x-6 text-sm text-gray-400 mt-4">
              <div className="flex items-center space-x-2">
                <Calendar className="w-4 h-4" />
                <span>{format(new Date(post.published_date), "d 'de' MMMM 'de' yyyy", { locale: es })}</span>
              </div>
              <div className="flex items-center space-x-2">
                <Clock className="w-4 h-4" />
                <span>{post.read_time} min de lectura</span>
              </div>
            </div>
          </header>
          
          {post.featured_image && (
            <img src={post.featured_image} alt={post.title} className="rounded-2xl mb-12" />
          )}

          <ReactMarkdown>{post.content}</ReactMarkdown>
        </article>

        <footer className="mt-16 border-t border-white/10 pt-8">
            <div className="flex justify-between items-center">
                <div className="flex space-x-2">
                    {post.tags?.map(tag => (
                        <span key={tag} className="bg-white/10 px-3 py-1 rounded-full text-xs text-gray-300">{tag}</span>
                    ))}
                </div>
                <Button variant="outline" className="text-purple-300 border-purple-400/80 hover:bg-purple-500/20 hover:border-purple-400 hover:text-white transition-colors">
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartir
                </Button>
            </div>
        </footer>
      </div>
    </div>
  );
}