import React, { useState, useMemo } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { TrendingUp, Clock, DollarSign, Calendar, Users, ArrowRight } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';

export default function ROICalculator() {
  const [inputs, setInputs] = useState({
    employees: 5,
    hoursPerWeek: 10,
    avgSalary: 25000,
    monthlyRevenue: 200000,
  });

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setInputs(prev => ({ ...prev, [name]: Number(value) }));
  };
  
  const handleSliderChange = (name, value) => {
    setInputs(prev => ({ ...prev, [name]: value[0] }));
  };

  const results = useMemo(() => {
    const { employees, hoursPerWeek, avgSalary, monthlyRevenue } = inputs;

    const hourlyRate = avgSalary / 4 / 40; // Salario mensual / 4 semanas / 40 horas
    const hoursSavedPerMonth = employees * hoursPerWeek * 4;
    const moneySavedPerMonth = hoursSavedPerMonth * hourlyRate;

    // Supuestos conservadores de mejora
    const efficiencyGain = 0.15; // 15%
    const leadGenIncrease = 0.20; // 20%
    const conversionIncrease = 0.10; // 10%

    const revenueFromEfficiency = (moneySavedPerMonth / avgSalary) * monthlyRevenue * efficiencyGain;
    const revenueFromLeadGen = monthlyRevenue * leadGenIncrease;
    const revenueFromConversion = (monthlyRevenue * (1 + leadGenIncrease)) * conversionIncrease;
    
    const potentialRevenueIncrease = revenueFromEfficiency + revenueFromLeadGen + revenueFromConversion;
    const totalMonthlyGain = moneySavedPerMonth + potentialRevenueIncrease;
    const annualROI = (totalMonthlyGain * 12);

    return {
      hoursSavedPerMonth,
      moneySavedPerMonth,
      potentialRevenueIncrease,
      annualROI
    };
  }, [inputs]);

  const formatCurrency = (value) => {
    return new Intl.NumberFormat('es-MX', { style: 'currency', currency: 'MXN' }).format(value);
  };

  return (
    <div className="py-20 text-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Calculadora de Retorno de Inversión (ROI)
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Descubre en 60 segundos cuánto tiempo y dinero podrías estar ahorrando con la automatización.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Input Section */}
          <Card className="bg-white/5 backdrop-blur-sm border-white/10">
            <CardHeader>
              <CardTitle>Ingresa los datos de tu empresa</CardTitle>
              <CardDescription>Usa los sliders o escribe los valores para ajustar.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-8">
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="employees">Número de empleados en tareas administrativas/ventas</Label>
                  <span className="text-green-400 font-bold">{inputs.employees}</span>
                </div>
                <Slider name="employees" value={[inputs.employees]} onValueChange={(val) => handleSliderChange('employees', val)} min={1} max={100} step={1} />
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="hoursPerWeek">Horas semanales por empleado en tareas repetitivas</Label>
                  <span className="text-green-400 font-bold">{inputs.hoursPerWeek}</span>
                </div>
                <Slider name="hoursPerWeek" value={[inputs.hoursPerWeek]} onValueChange={(val) => handleSliderChange('hoursPerWeek', val)} min={1} max={40} step={1} />
              </div>

              <div className="space-y-2">
                <Label htmlFor="avgSalary">Salario mensual promedio (MXN)</Label>
                <Input type="number" name="avgSalary" value={inputs.avgSalary} onChange={handleInputChange} className="bg-white/10 border-white/20"/>
              </div>

              <div className="space-y-2">
                <Label htmlFor="monthlyRevenue">Ingreso mensual promedio (MXN)</Label>
                <Input type="number" name="monthlyRevenue" value={inputs.monthlyRevenue} onChange={handleInputChange} className="bg-white/10 border-white/20"/>
              </div>
            </CardContent>
          </Card>

          {/* Results Section */}
          <Card className="bg-gradient-to-br from-green-500/10 to-purple-500/10 border-green-400/20 sticky top-24">
            <CardHeader className="text-center">
              <CardTitle className="text-3xl font-bold">Tu Potencial de Crecimiento</CardTitle>
              <CardDescription>Resultados estimados basados en tus datos.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-2 gap-6">
                <div className="bg-white/5 p-4 rounded-lg text-center">
                  <Clock className="w-8 h-8 text-purple-400 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">{Math.round(results.hoursSavedPerMonth)}</div>
                  <div className="text-sm text-gray-400">Horas Ahorradas/Mes</div>
                </div>
                <div className="bg-white/5 p-4 rounded-lg text-center">
                  <DollarSign className="w-8 h-8 text-green-400 mx-auto mb-2" />
                  <div className="text-2xl font-bold text-white">{formatCurrency(results.moneySavedPerMonth)}</div>
                  <div className="text-sm text-gray-400">Ahorro Directo/Mes</div>
                </div>
              </div>
              
              <div className="bg-white/5 p-6 rounded-lg text-center">
                <TrendingUp className="w-10 h-10 text-yellow-400 mx-auto mb-2" />
                <div className="text-3xl font-bold text-white">{formatCurrency(results.potentialRevenueIncrease)}</div>
                <div className="text-sm text-gray-400">Incremento Potencial en Ingresos/Mes</div>
              </div>

              <div className="bg-gradient-to-r from-green-400 to-purple-500 p-6 rounded-lg text-center text-white">
                <div className="text-lg font-semibold">Retorno de Inversión Anual Estimado</div>
                <div className="text-5xl font-bold my-2">{formatCurrency(results.annualROI)}</div>
                <div className="text-xs opacity-80">(Ahorros + Nuevos Ingresos)</div>
              </div>
              
              <div className="pt-6 border-t border-white/10 text-center">
                  <h3 className="text-xl font-semibold text-white mb-3">¿Listo para hacer estos números una realidad?</h3>
                  <p className="text-gray-300 mb-4">Agenda una consulta gratuita y te creamos un plan de automatización personalizado.</p>
                  <Link to={createPageUrl("Contact")}>
                      <Button size="lg" className="gradient-bg text-white hover:opacity-90">
                          Agendar mi Consulta Estratégica
                          <ArrowRight className="w-5 h-5 ml-2" />
                      </Button>
                  </Link>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}