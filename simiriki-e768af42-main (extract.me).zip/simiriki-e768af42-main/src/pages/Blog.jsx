
import React, { useState, useEffect } from 'react';
import { BlogPost } from '@/api/entities';
import { Link } from 'react-router-dom';
import { createPageUrl } from '@/utils';
import { Calendar, Clock, Tag, TrendingUp, Users, Download } from 'lucide-react';
import { format } from 'date-fns';
import { es } from 'date-fns/locale';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { syncToHubspot } from '@/api/functions';

export default function Blog() {
  const [posts, setPosts] = useState([]);
  const [isLoading, setIsLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [newsletterEmail, setNewsletterEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [newsletterSubmitted, setNewsletterSubmitted] = useState(false);

  useEffect(() => {
    const fetchPosts = async () => {
      setIsLoading(true);
      try {
        const publishedPosts = await BlogPost.filter({ status: 'published' }, '-published_date');
        setPosts(publishedPosts);
      } catch (error) {
        console.error("Error fetching blog posts:", error);
      }
      setIsLoading(false);
    };
    fetchPosts();
  }, []);

  const handleNewsletterSubmit = async (e) => {
    e.preventDefault();
    if (!newsletterEmail) return;

    setIsSubmitting(true);
    try {
      await syncToHubspot({
        leadData: { email: newsletterEmail, source: 'newsletter_blog' },
        eventType: 'newsletter_subscription'
      });

      window.trackGAEvent('subscribe', {
        form_name: 'newsletter_blog',
        lead_source: 'Blog Page'
      });

      setNewsletterSubmitted(true);
    } catch(error) {
      console.error("Newsletter submission error:", error);
      alert("Hubo un error al suscribirte. Inténtalo de nuevo.");
    }
    setIsSubmitting(false);
  };

  const filteredPosts = posts.filter(post => {
    const matchesSearch = post.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         post.excerpt.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || post.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  const categories = [
    { id: 'all', name: 'Todos los Artículos', icon: TrendingUp },
    { id: 'automation', name: 'Automatización', icon: TrendingUp },
    { id: 'lead_generation', name: 'Generación de Leads', icon: Users },
    { id: 'ai_tools', name: 'Herramientas IA', icon: TrendingUp },
    { id: 'case_studies', name: 'Casos de Éxito', icon: Users },
    { id: 'industry_insights', name: 'Tendencias', icon: TrendingUp }
  ];

  return (
    <div className="py-20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Tu Biblioteca de <span className="gradient-text">Crecimiento Inteligente</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto mb-8">
            Estrategias probadas, casos reales y guías paso a paso para automatizar tu negocio.
            Contenido creado por expertos, pensado para dueños de PYMES ocupados.
          </p>

          {/* Search and Filter */}
          <div className="max-w-2xl mx-auto space-y-4">
            <Input
              type="text"
              placeholder="Buscar artículos..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="bg-white/10 border-white/20 text-white placeholder:text-gray-400"
            />

            <div className="flex flex-wrap justify-center gap-2">
              {categories.map(category => (
                <Button
                  key={category.id}
                  variant={selectedCategory === category.id ? "default" : "outline"}
                  size="sm"
                  onClick={() => setSelectedCategory(category.id)}
                  className={selectedCategory === category.id
                    ? "gradient-bg text-white"
                    : "text-gray-300 border-gray-600 hover:bg-white/10"
                  }
                >
                  <category.icon className="w-4 h-4 mr-2" />
                  {category.name}
                </Button>
              ))}
            </div>
          </div>
        </div>

        {/* Featured Post */}
        {filteredPosts.length > 0 && (
          <div className="mb-16">
            <Card className="bg-gradient-to-br from-green-500/10 to-purple-500/10 border border-white/10 overflow-hidden">
              <div className="grid md:grid-cols-2 gap-8 p-8">
                <div>
                  <div className="flex items-center space-x-2 text-xs text-green-400 mb-3">
                    <Tag className="w-3 h-3" />
                    <span>Artículo Destacado</span>
                  </div>
                  <h2 className="text-3xl font-bold text-white mb-4">{filteredPosts[0].title}</h2>
                  <p className="text-gray-300 mb-6 leading-relaxed">{filteredPosts[0].excerpt}</p>
                  <div className="flex items-center justify-between text-sm text-gray-400 mb-6">
                    <div className="flex items-center space-x-4">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-4 h-4" />
                        <span>{format(new Date(filteredPosts[0].published_date), "d MMMM, yyyy", { locale: es })}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-4 h-4" />
                        <span>{filteredPosts[0].read_time} min de lectura</span>
                      </div>
                    </div>
                  </div>
                  <Link to={createPageUrl(`BlogPost?slug=${filteredPosts[0].slug}`)}>
                    <Button className="gradient-bg text-white hover:opacity-90">
                      Leer Artículo Completo
                    </Button>
                  </Link>
                </div>
                {filteredPosts[0].featured_image && (
                  <div className="aspect-video rounded-lg overflow-hidden">
                    <img
                      src={filteredPosts[0].featured_image}
                      alt={filteredPosts[0].title}
                      className="w-full h-full object-cover"
                    />
                  </div>
                )}
              </div>
            </Card>
          </div>
        )}

        {/* Blog Posts Grid */}
        {isLoading ? (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {[...Array(6)].map((_, i) => (
              <Card key={i} className="bg-white/5 border-white/10 animate-pulse">
                <CardContent className="p-6">
                  <div className="h-40 bg-white/10 rounded-lg mb-4"></div>
                  <div className="h-4 bg-white/10 rounded w-3/4 mb-2"></div>
                  <div className="h-4 bg-white/10 rounded w-1/2"></div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredPosts.slice(1).map(post => (
              <Link to={createPageUrl(`BlogPost?slug=${post.slug}`)} key={post.id} className="block group">
                <Card className="bg-white/5 backdrop-blur-sm rounded-2xl border border-white/10 hover:border-green-400/30 transition-all duration-300 h-full flex flex-col overflow-hidden">
                  {post.featured_image && (
                    <div className="aspect-video overflow-hidden">
                      <img
                        src={post.featured_image}
                        alt={post.title}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    </div>
                  )}
                  <CardContent className="p-6 flex-grow flex flex-col">
                    <div className="flex items-center space-x-2 text-xs text-green-400 mb-2">
                      <Tag className="w-3 h-3" />
                      <span>{post.category.replace(/_/g, ' ')}</span>
                    </div>
                    <h2 className="text-xl font-bold text-white mb-2 flex-grow">{post.title}</h2>
                    <p className="text-gray-300 text-sm mb-4 line-clamp-3">{post.excerpt}</p>
                    <div className="flex justify-between items-center text-xs text-gray-400 mt-auto pt-4 border-t border-white/10">
                      <div className="flex items-center space-x-2">
                        <Calendar className="w-3 h-3" />
                        <span>{format(new Date(post.published_date), "d MMM, yyyy", { locale: es })}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Clock className="w-3 h-3" />
                        <span>{post.read_time} min de lectura</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        )}

        {/* Newsletter Signup */}
        <Card className="mt-20 bg-gradient-to-br from-green-500/10 to-purple-500/10 rounded-2xl p-8 md:p-12 border border-white/10 text-center">
          <h2 className="text-3xl font-bold text-white mb-4">Recibe Estrategias Exclusivas Cada Semana</h2>
          <p className="text-gray-300 mb-6 max-w-xl mx-auto">
            Suscríbete a nuestro newsletter y obtén acceso exclusivo a tácticas de automatización
            que no compartimos en ningún otro lugar.
          </p>
          {newsletterSubmitted ? (
            <p className="text-green-400 font-semibold">¡Gracias por suscribirte! Revisa tu bandeja de entrada.</p>
          ) : (
            <form onSubmit={handleNewsletterSubmit} className="flex flex-col sm:flex-row gap-4 max-w-md mx-auto">
              <Input
                type="email"
                placeholder="tu@email.com"
                value={newsletterEmail}
                onChange={(e) => setNewsletterEmail(e.target.value)}
                className="bg-white/10 border-white/20 text-white placeholder:text-gray-400 flex-grow"
                required
              />
              <Button type="submit" className="gradient-bg text-white hover:opacity-90" disabled={isSubmitting}>
                {isSubmitting ? 'Enviando...' : (
                  <>
                    <Download className="w-4 h-4 mr-2" />
                    Suscribirme
                  </>
                )}
              </Button>
            </form>
          )}
          <p className="text-xs text-gray-500 mt-4">Sin spam. Solo valor. Cancela cuando quieras.</p>
        </Card>
      </div>
    </div>
  );
}
