
import React, { useState } from "react";
import { Link } from "react-router-dom";
import { createPageUrl } from "@/utils";
import { Button } from "@/components/ui/button";
import { ArrowRight, Zap, Users, TrendingUp, Bot, Rocket, Star, CheckCircle } from "lucide-react";

import HubSpotTracking from "../components/hubspot/HubSpotTracking";
import HeroSection from "../components/home/HeroSection";
import ServicesPreview from "../components/home/ServicesPreview";
import StatsSection from "../components/home/StatsSection";
import TestimonialsCarousel from "../components/home/TestimonialsCarousel";
import CTASection from "../components/home/CTASection";
import FeaturesGrid from "../components/home/FeaturesGrid";
import SocialProofSection from "../components/home/SocialProofSection";
import SocialProofNotifications from "../components/home/SocialProofNotifications";
import FAQ from "../components/home/FAQ";
import FounderIntro from "../components/home/FounderIntro";
import BlogPreview from "../components/home/BlogPreview";

// HubSpot configuration
const HUBSPOT_PORTAL_ID = "50203416";

export default function Home() {
  return (
    <div className="min-h-screen">
      {/* Page tracking - NO CHAT ADICIONAL */}
      <HubSpotTracking portalId={HUBSPOT_PORTAL_ID} />
      
      <HeroSection />
      <SocialProofSection />
      <FeaturesGrid />
      <FounderIntro />
      <ServicesPreview />
      
      {/* Repeating CTA Section for better conversion */}
      <CTASection /> 
      
      <StatsSection />
      <TestimonialsCarousel />
      <BlogPreview />
      <FAQ />
      
      {/* Social proof notifications - no more popups */}
      <SocialProofNotifications />

      {/* NO más componentes de chat aquí - solo el del Layout */}
    </div>
  );
}
