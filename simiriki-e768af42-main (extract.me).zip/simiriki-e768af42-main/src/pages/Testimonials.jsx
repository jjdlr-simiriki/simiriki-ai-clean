import React, { useState, useEffect } from 'react';
import { Testimonial } from '@/api/entities';
import { Star, Quote, Building } from 'lucide-react';

export default function Testimonials() {
  const [testimonials, setTestimonials] = useState([]);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    const fetchTestimonials = async () => {
      setIsLoading(true);
      try {
        const data = await Testimonial.filter({ status: 'active' }, '-created_date');
        setTestimonials(data);
      } catch (error) {
        console.error("Error fetching testimonials:", error);
      }
      setIsLoading(false);
    };
    fetchTestimonials();
  }, []);

  return (
    <div className="py-20 text-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Historias de Éxito de <span className="gradient-text">Nuestros Clientes</span>
          </h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Empresas reales, resultados reales. Vea cómo hemos ayudado a PYMES como la suya a alcanzar nuevos niveles de crecimiento.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {(isLoading ? [...Array(6)] : testimonials).map((testimonial, index) => (
            <div key={testimonial?.id || index} className="bg-white/5 backdrop-blur-sm rounded-2xl p-8 border border-white/10 flex flex-col">
              {isLoading ? (
                <div className="animate-pulse flex flex-col h-full">
                  <div className="h-4 bg-white/10 rounded w-20 mb-4"></div>
                  <div className="h-6 bg-white/10 rounded w-full mb-4"></div>
                  <div className="flex-grow space-y-2">
                    <div className="h-4 bg-white/10 rounded w-full"></div>
                    <div className="h-4 bg-white/10 rounded w-5/6"></div>
                  </div>
                  <div className="mt-6 pt-6 border-t border-white/10">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-white/10 rounded-full"></div>
                      <div className="flex-grow space-y-2">
                        <div className="h-4 bg-white/10 rounded w-1/2"></div>
                        <div className="h-4 bg-white/10 rounded w-3/4"></div>
                      </div>
                    </div>
                  </div>
                </div>
              ) : (
                <>
                  <Quote className="w-10 h-10 text-green-400/30 mb-4" />
                  <div className="flex-grow">
                    <p className="text-gray-300 italic mb-4">"{testimonial.testimonial}"</p>
                    {testimonial.results_achieved && (
                       <div className="bg-green-500/10 rounded-lg p-3 my-4 border-l-4 border-green-500">
                          <p className="text-sm text-white font-semibold">{testimonial.results_achieved}</p>
                       </div>
                    )}
                  </div>
                  <div className="mt-6 pt-6 border-t border-white/10">
                    <div className="flex items-center space-x-4">
                       <div className="w-12 h-12 bg-gradient-to-br from-green-400 to-purple-400 rounded-full flex items-center justify-center text-xl font-bold">
                         {testimonial.client_name.charAt(0)}
                       </div>
                       <div className="flex-grow">
                         <div className="font-bold text-white">{testimonial.client_name}</div>
                         <div className="text-sm text-gray-400">{testimonial.client_title}</div>
                         <div className="text-sm text-green-400 font-medium flex items-center">
                            <Building className="w-3 h-3 mr-1.5"/>
                            {testimonial.company}
                         </div>
                       </div>
                       <div className="flex items-center text-yellow-400">
                         <Star className="w-4 h-4 mr-1" />
                         <span>{testimonial.rating}</span>
                       </div>
                    </div>
                  </div>
                </>
              )}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}